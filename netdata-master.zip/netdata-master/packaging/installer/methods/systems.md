# Install on specific environments

This category contains specific instructions for some popular environments. 
If you have a standard environment that is not yet listed here, just use the 
[one line installer kickstart.sh](/packaging/installer/methods/kickstart.md)

If your environment is somewhat old or unusual, check our 
[platform support policy](/docs/netdata-agent/versions-and-platforms.md).

