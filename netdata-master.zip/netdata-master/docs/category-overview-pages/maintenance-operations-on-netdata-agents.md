# Netdata Agent Maintenance Operations Overview

This section provides information on various actions to maintain a Netdata Agent:

- [Service Control](/docs/netdata-agent/start-stop-restart.md)
- [Update](/packaging/installer/UPDATE.md)
- [Uninstall](/packaging/installer/UNINSTALL.md)
