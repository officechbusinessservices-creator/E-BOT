# Build the Netdata Agent yourself

This section contains documentation on all the ways that you can build the Netdata Agent.
