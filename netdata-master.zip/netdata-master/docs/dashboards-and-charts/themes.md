# Choose your Netdata UI theme

The Dark theme is the default in the Netdata UI.

To change your theme across the Netdata UI, click on your profile picture, click on the **Settings**
tab, and then choose your preferred theme: **Light** or **Dark**.

**Dark**:

![Dark theme](https://github.com/netdata/netdata/assets/70198089/81addd13-28a4-425f-ae39-0f9de5199496)

**Light**:

![Light theme](https://github.com/netdata/netdata/assets/70198089/eb0fb8c1-5695-450a-8ba8-a185874e8496)
