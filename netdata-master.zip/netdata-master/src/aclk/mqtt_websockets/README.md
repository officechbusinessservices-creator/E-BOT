# mqtt_websockets

Library to connect MQTT client over Websockets Secure (WSS).

## License

The Project is released under GPL v3 license. See [License](/LICENSE)
