// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef COMMON_INTERNAL_H
#define COMMON_INTERNAL_H

#include "endian_compat.h"

#ifndef MQTT_WSS_FRAG_MEMALIGN
#define MQTT_WSS_FRAG_MEMALIGN (8)
#endif

#endif /* COMMON_INTERNAL_H */
