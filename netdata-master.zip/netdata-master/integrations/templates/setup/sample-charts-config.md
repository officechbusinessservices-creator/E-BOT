The file format is POSIX shell script. Generally, the structure is:

```sh
OPTION_1="some value"
OPTION_2="some other value"
```
