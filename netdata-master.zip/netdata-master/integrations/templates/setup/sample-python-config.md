The file format is YAML. Generally, the structure is:

```yaml
update_every: 1
autodetection_retry: 0

job_name:
  job_option1: some_value
  job_option2: some_other_vlaue
```
