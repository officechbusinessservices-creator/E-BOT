<div>
<h1 align="center">
Awesome-GPTs
</h1>
<p align="center">
  <img width="350" src="https://raw.githubusercontent.com/lxfater/Awesome-GPTs/main/img/ada064e7-a42f-40b3-95f6-3fffee87224e.webp">
</p>
<p align="center">
    1000+ GPTs and 10 categories. 80+ Leaked Prompt. Give me a star ⭐ ！😘
</p>
  <p align="center">
      <a href="https://github.com/lxfater/Awesome-GPTs">English</a> | <a href="https://github.com/lxfater/Awesome-GPTs/blob/main/README_zh.md">简体中文</a>
  </p>
</div>

## Best GPTs Finder

### [GPTs查找](https://chat.openai.com/g/g-xD0GdS69Z-gptscha-zhao)
- Understand your needs
- Real-time search
- Open-source

## Leaked Prompt
### [genz 4 meme](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/genz-4-meme.md)

### [科技文章翻译](https://chat.openai.com/g/g-uBhKUJJTl-ke-ji-wen-zhang-fan-yi)

##### [My excellent classmates (Help with my homework!)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/My-excellent-classmates-(Help-with-my-homework!).md)
##### [Moby Dick RPG](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Moby-Dick-RPG.md)
##### [春霞つくし Tsukushi Harugasumi](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/春霞つくし-Tsukushi-Harugasumi.md)
##### [完蛋，我被美女包围了(AI同人)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/完蛋，我被美女包围了(AI同人).md)
##### [Virtual Sweetheart](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Virtual-Sweetheart.md)
##### [Synthia ](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Synthia-.md)
##### [Canva](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Canva.md)
##### [Chibi Kohaku (猫音コハク)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Chibi-Kohaku-(猫音コハク).md)
##### [Calendar GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Calendar-GPT.md)
##### [Interview Coach](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Interview-Coach.md)
##### [YT transcriber](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/YT-transcriber.md)
##### [Take Code Captures](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Take-Code-Captures.md)
##### [BabyAgi.txt](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/BabyAgi.txt.md)
##### [Sarcastic Humorist](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Sarcastic-Humorist.md)
##### [Manga Miko - Anime Girlfriend](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Manga-Miko---Anime-Girlfriend.md)
##### [OCR-GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/OCR-GPT.md)

##### [The Shaman](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/The-Shaman.md)
##### [Video Script Generator](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Video-Script-Generator.md)
##### [Meme Magic](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Meme-Magic.md)
##### [EmojAI](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/EmojAI.md)
##### [YT Summarizer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/YT-Summarizer.md)
##### [Trey Ratcliff's Photo Critique GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Trey-Ratcliff's-Photo-Critique-GPT.md)
##### [Sales Cold Email Coach](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Sales-Cold-Email-Coach.md)
##### [LogoGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/LogoGPT.md)
##### [CuratorGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/CuratorGPT.md)
##### [KoeGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/KoeGPT.md)
##### [HormoziGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/HormoziGPT.md)
##### [MetabolismBoosterGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/MetabolismBoosterGPT.md)
##### [What should I watch?](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/What-should-I-watch?.md)
##### [Gif-PT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Gif-PT.md)
##### [MuskGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/MuskGPT.md)
##### [Retro Adventures](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Retro-Adventures.md)
##### [ClearGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/ClearGPT.md)
##### [Visual Weather Artist GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Visual-Weather-Artist-GPT.md)
##### [X Optimizer GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/X-Optimizer-GPT.md)
##### [Character Forger](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Character-Forger.md)
##### [10x Engineer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/10x-Engineer.md)
##### [AI Doctor](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Doctor.md)
##### [AI Paper Polisher Pro](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Paper-Polisher-Pro.md)
##### [(A.I. Bestie)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/(A.I.-Bestie).md)
##### [悲慘世界 RPG](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/悲慘世界-RPG.md)
##### [SEObot](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/SEObot.md)
##### [AI Lover](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Lover.md)
##### [TaxGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/TaxGPT.md)
##### [Secret Code Guardian](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Secret-Code-Guardian.md)
##### [High-Quality Review Analyzer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/High-Quality-Review-Analyzer.md)
##### [toonGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/toonGPT.md)
##### [Viral Hooks Generator](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Viral-Hooks-Generator.md)
##### [OpenStorytelling Plus](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/OpenStorytelling-Plus.md)
##### [Quality Raters SEO Guide](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Quality-Raters-SEO-Guide.md)
##### [Video Game Almanac](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Video-Game-Almanac.md)
##### [天官庙的刘半仙](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/天官庙的刘半仙.md)
##### [ConvertAnything](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/ConvertAnything.md)
##### [痤疮治疗指南](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/痤疮治疗指南.md)
##### [猫耳美少女イラストメーカー](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/猫耳美少女イラストメーカー.md)
##### [脏话连篇](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/脏话连篇.md)
##### [老爸，该怎么办？](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/老爸，该怎么办？.md)
##### [老妈，我爱你](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/老妈，我爱你.md)
##### [GPT-Builder](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/GPT-Builder.md)


## 📚 Table of Contents
1. [Education](#Education)
2. [Tools](Ttools)
3. [Entertainment](#Entertainment)
4. [Language](#Language)
5. [Health](#Health)
6. [Programming](#Programming)
7. [Creative](#Creative)
8. [Data](#Data)
9. [Games](#Games)
10. [Law](#Law)
## Education
### [Academic Translator (to English)](https://chat.openai.com/g/g-WZjelkFDn-academic-translator-to-english)
 - Academic Translator (to English). I specialize in translations. If a request fails, try 'Translate: [input texts]'. By MATSUI KENTARO. Sign up to chat.
 - [Chat 💬](https://chat.openai.com/g/g-WZjelkFDn-academic-translator-to-english)
### [English Learning](https://chat.openai.com/g/g-rehimLUp7-english-learning)
 - Your English learning assistant.
 - [Chat 💬](https://chat.openai.com/g/g-rehimLUp7-english-learning)
### [Academic Enhancer](https://chat.openai.com/g/g-iBC0Km3YP-paper-writer)
 - GPT. Academic Enhancer. Refines academic texts with clarity and insight. By Yu Hao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iBC0Km3YP-paper-writer)
### [Academic Pathfinder](https://chat.openai.com/g/g-UogOdWQij-academic-pathfinder)
 - GPT. Academic Pathfinder. Your ally for university applications. By Jarett Dewbury. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-UogOdWQij-academic-pathfinder)
### [Language Learning Tui](https://chat.openai.com/g/g-IMTqM75f1-language-learning-tui)
 - GPT. Language Learning Tui. Learn any language. By Arya Malek. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IMTqM75f1-language-learning-tui)
### [ChatEnglish](https://chat.openai.com/g/g-6lpFSjYBY-chatenglish)
 - Efficient English learning aid. By Yang Wu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6lpFSjYBY-chatenglish)
### [英文校正GPT](https://chat.openai.com/g/g-xk6AdDGIW-ying-wen-xiao-zheng-gpt)
 - Academic paper English proofreading assistant. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-xk6AdDGIW-ying-wen-xiao-zheng-gpt)
### [AutoExpert (Academic)](https://chat.openai.com/g/g-YAgNxPJEq-autoexpert-academic)
 - AutoExpert (Academic). Expert in scholarly paper analysis and academic research assistance. By llmimagineers.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-YAgNxPJEq-autoexpert-academic)
### [Academizer](https://chat.openai.com/g/g-sV45b90aj-academizer)
 - GPT. Academizer. Directly converts text into academic prose. By Kanaad pathak. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sV45b90aj-academizer)
### [AI GPT](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
 - GPT. AI GPT. AI & ML Expert adept in deep learning frameworks. By Andrew Gao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
### [Academic Linguist](https://chat.openai.com/g/g-9KooP6C22-academic-linguist)
 - Academic Translation Assistant in Management and Psychology.
 - [Chat 💬](https://chat.openai.com/g/g-9KooP6C22-academic-linguist)
### [ChatPaper](https://chat.openai.com/g/g-sD6wtjB8a-chatpaper)
 - Summarizes academic papers, especially in medical and scientific research. By RONGKANG. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sD6wtjB8a-chatpaper)
### [Paper Machine](https://chat.openai.com/g/g-kXwpmdcpB-paper-machine)
 - ChatGPT Sign up. GPT. Paper Machine. Academic writing expert. By Xiufeng Liu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kXwpmdcpB-paper-machine)
### [Simple Proofreader](https://chat.openai.com/g/g-Dk6K4VJk2-simple-proofreader)
 - "I will proofread academic English. I won't do anything other than that"
 - [Chat 💬](https://chat.openai.com/g/g-Dk6K4VJk2-simple-proofreader)
### [狗熊学英语](https://chat.openai.com/g/g-PiOxyaiBO-gou-xiong-xue-ying-yu)
 - GPT. 狗熊学英语. Your English learning sidekick. By Bear Liu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-PiOxyaiBO-gou-xiong-xue-ying-yu)
### [Paper Reframer](https://chat.openai.com/g/g-BQ8tp8aKr-paper-reframer)
 - Academic paper paraphrasing assistant. Just paste or upload what you want me to rewrite.直接粘贴你要改写的内容，文献综述神器。
 - [Chat 💬](https://chat.openai.com/g/g-BQ8tp8aKr-paper-reframer)
### [ML quiz](https://chat.openai.com/g/g-OkQZg8HwR-ml-quiz)
 - Quizzes users on advanced machine learning concepts. By Georg Walther. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OkQZg8HwR-ml-quiz)
### [NFTGod](https://chat.openai.com/g/g-0TPXYkSiH-nftgod)
 - A beginners guide to learning about NFTs. ... A beginners guide to learning about NFTs. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0TPXYkSiH-nftgod)
### [GPT Enhancer](https://chat.openai.com/g/g-fQ6GAANfi-gpt-enhancer)
 - AI assistant for refining GPT instructions with a focus on user experience and continuous AI learning.
 - [Chat 💬](https://chat.openai.com/g/g-fQ6GAANfi-gpt-enhancer)
### [RustChat](https://chat.openai.com/g/g-59mWdU25F-rustchat)
 - Hello! I'm your Rust language learning and practical assistant created by AlexZhang. I can help you learn and practice Rust whether you are a beginner or ...
 - [Chat 💬](https://chat.openai.com/g/g-59mWdU25F-rustchat)
### [HyperLearn GPT](https://chat.openai.com/g/g-B2tKpr5SN-hyperlearn-gpt)
 - Assesses and guides learning ... Assesses and guides learning. By Abhilash Inumella. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-B2tKpr5SN-hyperlearn-gpt)
### [Code Animator](https://chat.openai.com/g/g-r4TatQY5C-code-animator)
 - I generate Manim animations for CS education. By Aadil Ali. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-r4TatQY5C-code-animator)
### [Tutor](https://chat.openai.com/g/g-Er02nza0K-tutor)
 - GPT. Tutor. Friendly AI tutor eager to help with learning. By Live Loud Ltd. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Er02nza0K-tutor)
### [Python Quiz](https://chat.openai.com/g/g-my7iZTaB2-python-quiz)
 - Guides Python learning at all levels with tailored advice. By MATTHEW H HARRISON. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-my7iZTaB2-python-quiz)
### [和英翻訳GPT](https://chat.openai.com/g/g-RKXe3aooI-he-ying-fan-yi-gpt)
 - Specializes in Japanese to English academic translations. ... Specializes in Japanese to English academic translations. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-RKXe3aooI-he-ying-fan-yi-gpt)
### [Rebuttal Pro](https://chat.openai.com/g/g-fnrMLZJ4V-rebuttal-pro)
 - Your academic rebuttal assistant, blending precision and approachability.
 - [Chat 💬](https://chat.openai.com/g/g-fnrMLZJ4V-rebuttal-pro)
### [Study Mentor](https://chat.openai.com/g/g-4AOhYpUh3-study-mentor)
 - Proactive learning assistant using data to guide students. By reanbver gpt. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4AOhYpUh3-study-mentor)
### [OpenAPI Builder](https://chat.openai.com/g/g-ZHFKmHM1R-openapi-builder)
 - Expert in converting APIs to OpenAPI Schemas, with a focus on education and best practices.
 - [Chat 💬](https://chat.openai.com/g/g-ZHFKmHM1R-openapi-builder)
### [Computer Vision Expert](https://chat.openai.com/g/g-x45oD8m2G-computer-vision-expert)
 - Academic expert in computer vision, offering innovative insights for deep learning models.
 - [Chat 💬](https://chat.openai.com/g/g-x45oD8m2G-computer-vision-expert)
### [SICP Sage](https://chat.openai.com/g/g-Jd8EjuxN9-sicp-sage)
 - Academic assistant for SICP study, referencing solutions.
 - [Chat 💬](https://chat.openai.com/g/g-Jd8EjuxN9-sicp-sage)
### [Grok](https://chat.openai.com/g/g-ckieRMrru-grok)
 - Your go-to AI for learning with fun. By Diego Cabezas. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ckieRMrru-grok)
### [GPT4MR](https://chat.openai.com/g/g-QXjQ7U1xj-gpt4mr)
 - GPT. GPT4MR. An MRI learning and coding guide. Coding in PyPulseq. By Moritz Zaiss. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-QXjQ7U1xj-gpt4mr)
### [AI Tutor](https://chat.openai.com/g/g-QhTV4OrrZ-ai-tutor)
 - An AI tutor skilled in guiding students through their academic queries ‍
 - [Chat 💬](https://chat.openai.com/g/g-QhTV4OrrZ-ai-tutor)
### [LingoBot | Learn any language](https://chat.openai.com/g/g-fbhFjBzXZ-lingobot-learn-any-language)
 - Hi, I'm Lingo, your friendly AI language learning assistant!
 - [Chat 💬](https://chat.openai.com/g/g-fbhFjBzXZ-lingobot-learn-any-language)
### [AlphaNotes GPT](https://chat.openai.com/g/g-ZdfrSRAyo-alphanotes-gpt)
 - Transform YouTube videos or web articles into your personal study guide or study aids, making learning efficient and enjoyable.
 - [Chat 💬](https://chat.openai.com/g/g-ZdfrSRAyo-alphanotes-gpt)
### [AI Dungeon Master: AI Tutor](https://chat.openai.com/g/g-SBglgPxZs-ai-dungeon-master-ai-tutor)
 - Guides brief, engaging AI learning in an adventure game.
 - [Chat 💬](https://chat.openai.com/g/g-SBglgPxZs-ai-dungeon-master-ai-tutor)
### [Cyberpunk AI University: Prompt Engineering RPG](https://chat.openai.com/g/g-z2Y9YzTSs-cyberpunk-ai-university-prompt-engineering-rpg)
 - Educational game engine for learning about AI. Start the game by explaining your educational level or goals.
 - [Chat 💬](https://chat.openai.com/g/g-z2Y9YzTSs-cyberpunk-ai-university-prompt-engineering-rpg)
### [Paper Reading Advisor: Carpe Diem](https://chat.openai.com/g/g-zut9cfvbZ-paper-reading-advisor-carpe-diem)
 - Discover the art of academic paper reading with Me. Hi, I am Carpe Diem, your personal paper reading tutor. I am always here, patiently explaining ...
 - [Chat 💬](https://chat.openai.com/g/g-zut9cfvbZ-paper-reading-advisor-carpe-diem)
### [Web3 GPT](https://chat.openai.com/g/g-DgOfY4u43-web3-gpt)
 - Your go-to Web3 expert for learning and project development.
 - [Chat 💬](https://chat.openai.com/g/g-DgOfY4u43-web3-gpt)
### [MAP Quiz Whiz](https://chat.openai.com/g/g-qeRnoQhY6-map-quiz-whiz)
 - GPT. MAP Quiz Whiz. Adaptive quizmaster enhancing learning. By quantalynx.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qeRnoQhY6-map-quiz-whiz)
### [2nd Year Pharmacy](https://chat.openai.com/g/g-BCA5GGdBl-2nd-year-pharmacy)
 - To provide a comprehensive AI-assisted learning experience for 2nd-year pharmacy students, aiming to enhance understanding, retention, and application of ...
 - [Chat 💬](https://chat.openai.com/g/g-BCA5GGdBl-2nd-year-pharmacy)
### [Vocab Whiz](https://chat.openai.com/g/g-qREjLqjWi-vocab-whiz)
 - I teach English words with fun, detailed explanations and encourage continuous learning.
 - [Chat 💬](https://chat.openai.com/g/g-qREjLqjWi-vocab-whiz)
### [WebStract](https://chat.openai.com/g/g-LaXsx7vXI-webstract)
 - I am WebStract, your autonomous, in-depth digital educator, guiding you through comprehensive, interactive learning experiences.
 - [Chat 💬](https://chat.openai.com/g/g-LaXsx7vXI-webstract)
### [Socrates](https://chat.openai.com/g/g-Y1FVKWsfv-socrates)
 - Syllabus Architect. Where transformative corporate education meets AI-driven curriculum design.
 - [Chat 💬](https://chat.openai.com/g/g-Y1FVKWsfv-socrates)
### [Data Guardian](https://chat.openai.com/g/g-KGBEqnrh8-data-guardian)
 - Your friendly guide to data anonymization. Provides step-by-step guidance and broad education about data privacy.
 - [Chat 💬](https://chat.openai.com/g/g-KGBEqnrh8-data-guardian)
### [Excel Automator](https://chat.openai.com/g/g-gBrO3SLJB-excel-automator)
 - GPT. Excel Automator. The ultimate VBA mentor for office automation and learning. By Tony Frohock. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gBrO3SLJB-excel-automator)
### [ClozeBot](https://chat.openai.com/g/g-xYhVIDYnh-clozebot)
 - Boost language fluency with tailored cloze tests! Tracks progress, adjusts difficulty, and provides feedback for an effective, engaging learning experience.
 - [Chat 💬](https://chat.openai.com/g/g-xYhVIDYnh-clozebot)
### [English Buddy](https://chat.openai.com/g/g-bTx9hj4Hy-english-buddy)
 - A supportive guide for learning English ... A supportive guide for learning English. By KOICHI NAKAMURA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-bTx9hj4Hy-english-buddy)
### [Stat Helper](https://chat.openai.com/g/g-UTetN1v4g-stat-helper)
 - Statistician with shortcuts for learning and levels. By Manohar Golleru. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-UTetN1v4g-stat-helper)
### [Code Mentor](https://chat.openai.com/g/g-mZsHS1sI4-code-mentor)
 - Expert computer science teacher for all learning levels. By yeyuan.pro · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mZsHS1sI4-code-mentor)
### [DSA Tutor Pro](https://chat.openai.com/g/g-IYAkufpe9-dsa-tutor-pro)
 - GPT. DSA Tutor Pro. Your DSA learning assistant. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IYAkufpe9-dsa-tutor-pro)
### [Rhythm GPT](https://chat.openai.com/g/g-FeofNC9d2-rhythm-gpt)
 - I make learning Ableton Live as enjoyable as morning coffee.
 - [Chat 💬](https://chat.openai.com/g/g-FeofNC9d2-rhythm-gpt)
### [Setanta](https://chat.openai.com/g/g-GG5upU4VA-setanta)
 - A personal tutor for learning Gaeilge, offering lessons and practice exercises.
 - [Chat 💬](https://chat.openai.com/g/g-GG5upU4VA-setanta)
### [Bitcoin Buddy](https://chat.openai.com/g/g-EzJDXLslE-bitcoin-buddy)
 - Hourly Bitcoin facts to fuel your learning journey!
 - [Chat 💬](https://chat.openai.com/g/g-EzJDXLslE-bitcoin-buddy)
### [Data Distiller](https://chat.openai.com/g/g-uzI5QUK19-data-distiller)
 - Condenses academic text to essentials, retains key data. By SENTHIL KUMAR E. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uzI5QUK19-data-distiller)
### [Vocab Builder](https://chat.openai.com/g/g-KQBaOCxkx-vocab-builder)
 - English vocabulary learning with detailed examples. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-KQBaOCxkx-vocab-builder)
### [Arabic Mentor](https://chat.openai.com/g/g-6iVaMcXsU-arabic-mentor)
 - An Arabic teacher aiding in language learning with cultural insights.
 - [Chat 💬](https://chat.openai.com/g/g-6iVaMcXsU-arabic-mentor)
### [Learn Wardley Mapping](https://chat.openai.com/g/g-sg6zS89Hi-learn-wardley-mapping)
 - I guide you in learning and applying Wardley Maps.
 - [Chat 💬](https://chat.openai.com/g/g-sg6zS89Hi-learn-wardley-mapping)
### [Linguist Lens](https://chat.openai.com/g/g-VD0Prjuqt-linguist-lens)
 - English mentor for beginners, offering tailored learning plans.
 - [Chat 💬](https://chat.openai.com/g/g-VD0Prjuqt-linguist-lens)
### [Math Mentor for ECG](https://chat.openai.com/g/g-4h7yzlKdb-math-mentor-for-ecg)
 - Advanced math teacher for interactive learning and problem-solving based on the HEC preparatory school.
 - [Chat 💬](https://chat.openai.com/g/g-4h7yzlKdb-math-mentor-for-ecg)
### [Just Ask](https://chat.openai.com/g/g-oKeaGqUER-wen-bai)
 - An AI-powered portable encyclopedia in the AI era. Mention a noun term and I will use the Feynman learning method to help you learn and master it within ...
 - [Chat 💬](https://chat.openai.com/g/g-oKeaGqUER-wen-bai)
### [Go Guru](https://chat.openai.com/g/g-apjQbXThu-go-guru)
 - Custom GPT to help learning, debugging, and development in Go. Follows good practices, provides examples, pros/cons, and also pitfalls.
 - [Chat 💬](https://chat.openai.com/g/g-apjQbXThu-go-guru)
### [10 Minute Physics Tutor](https://chat.openai.com/g/g-yTaYRKiFt-10-minute-physics-tutor)
 - Your rapid learning companion for physics, delivering concise 10-minute lessons.
 - [Chat 💬](https://chat.openai.com/g/g-yTaYRKiFt-10-minute-physics-tutor)
### [0-Minute Maths Tutor](https://chat.openai.com/g/g-im0zvgzXG-0-minute-maths-tutor)
 - Interactive and adaptive math tutor for quick, engaging learning.
 - [Chat 💬](https://chat.openai.com/g/g-im0zvgzXG-0-minute-maths-tutor)
### [Zero](https://chat.openai.com/g/g-KRUiYR8gD-zero)
 - Zero, an AI agent with a rich knowledge base in quantum thinking, probability mathematics, research trained, and more, offering growth and learning.
 - [Chat 💬](https://chat.openai.com/g/g-KRUiYR8gD-zero)
### [Lingo Tutor](https://chat.openai.com/g/g-FuAzuLuWr-lingo-tutor)
 - ChatGPT Sign up. GPT. Lingo Tutor. Language learning assistant. By Hasan Yurtsever. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FuAzuLuWr-lingo-tutor)
### [Occupational Therapy GPT](https://chat.openai.com/g/g-o2I2qbaeq-occupational-therapy-gpt)
 - Assists occupational therapists in client care, billing, and education.
 - [Chat 💬](https://chat.openai.com/g/g-o2I2qbaeq-occupational-therapy-gpt)
### [LeetLearn](https://chat.openai.com/g/g-gbrlnhJp7-leetlearn)
 - Lets grind some LeetCode! Allow me to fine-tune your learning experience. I will never hallucinate and never give away answers!
 - [Chat 💬](https://chat.openai.com/g/g-gbrlnhJp7-leetlearn)
### [EduGuide](https://chat.openai.com/g/g-MNiNzsvBr-eduguide)
 - ChatGPT Sign up. GPT. EduGuide. Your academic pathfinder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MNiNzsvBr-eduguide)
### [Citation Copilot](https://chat.openai.com/g/g-dw5Sfk82z-citation-copilot)
 - Academic citation assistant and converter. By Luis Manjarrez Mazon. Sign up for ChatGPT Plus to chat with Citation Copilot.
 - [Chat 💬](https://chat.openai.com/g/g-dw5Sfk82z-citation-copilot)
### [Hierarchy Navigator](https://chat.openai.com/g/g-idPG2SRKJ-hierarchy-navigator)
 - Organizes learning into a detailed hierarchy ... Organizes learning into a detailed hierarchy. By Kyle Coogan. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-idPG2SRKJ-hierarchy-navigator)
### [Genome Sage](https://chat.openai.com/g/g-eillIHxWt-genome-sage)
 - GPT. Genome Sage. Academic-level genomics expertise. By Xinming Tu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-eillIHxWt-genome-sage)
### [CS50 Tutor](https://chat.openai.com/g/g-1KKnxZsif-cs50-tutor)
 - Your pseudo Harvard professor for computer science queries, blending academic rigor with supportive guidance.
 - [Chat 💬](https://chat.openai.com/g/g-1KKnxZsif-cs50-tutor)
### [Rhetorica](https://chat.openai.com/g/g-Go1sJultl-rhetorica)
 - ChatGPT Sign up. GPT. Rhetorica. Academic rhetoric aid. By Marc Watkins. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Go1sJultl-rhetorica)
### [Arnold, the Economics Professor](https://chat.openai.com/g/g-PeE3eflHv-arnold-the-economics-professor)
 - Your expert economics mentor, Arnold, is here to guide you through the complex world of economic theories, data analysis, and academic research with ease ...
 - [Chat 💬](https://chat.openai.com/g/g-PeE3eflHv-arnold-the-economics-professor)
### [HEI GPTβ](https://chat.openai.com/g/g-JoNuJjbMv-hei-gptb)
 - 日本の教育と情報の歴史 (History of Education and Infomation in Japan)
 - [Chat 💬](https://chat.openai.com/g/g-JoNuJjbMv-hei-gptb)
### [Disiz Mémoire](https://chat.openai.com/g/g-pKTSKgxnS-disiz-memoire)
 - Academic writing assistant for thesis drafting, skilled in copywriting and citing sources.
 - [Chat 💬](https://chat.openai.com/g/g-pKTSKgxnS-disiz-memoire)
### [Chord Maestro](https://chat.openai.com/g/g-60rCdUuBd-chord-maestro)
 - A guitar learning assistant providing detailed, practical, and theoretical guidance.
 - [Chat 💬](https://chat.openai.com/g/g-60rCdUuBd-chord-maestro)
### [The Wiki Wizard](https://chat.openai.com/g/g-nAxHGldzZ-the-wiki-wizard)
 - GPT. The Wiki Wizard. Your personal Wikipedia guide. By ratcgpts.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-nAxHGldzZ-the-wiki-wizard)
### [AI Paper Polisher Pro](https://chat.openai.com/g/g-VX52iRD3r-ai-paper-polisher-pro)
 - A professional helper for polishing AI academic papers. By Haiwen Huang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-VX52iRD3r-ai-paper-polisher-pro)
### [Language Coach](https://chat.openai.com/g/g-0g6ZdEtv6-language-coach)
 - Practice speaking another language like a local without being a local.
 - [Chat 💬](https://chat.openai.com/g/g-0g6ZdEtv6-language-coach)
### [Pilot Mentor](https://chat.openai.com/g/g-TrU25ecw9-pilot-mentor)
 - For students and pilots looking to review aeronautical knowledge.
 - [Chat 💬](https://chat.openai.com/g/g-TrU25ecw9-pilot-mentor)
### [ScholarAI](https://chat.openai.com/g/g-L2HknCZTC-scholarai)
 - Your Research Assistant - I'll help you navigate over a corpus of 200M articles, journals, and books.
 - [Chat 💬](https://chat.openai.com/g/g-L2HknCZTC-scholarai)
### [Expert AI Consultant](https://chat.openai.com/g/g-pphsHvpFG-expert-ai-consultant)
 - Easily learn how you can use ChatGPT and AI in your current job.
 - [Chat 💬](https://chat.openai.com/g/g-pphsHvpFG-expert-ai-consultant)
### [孙子兵法各家解说](https://chat.openai.com/g/g-pzTavd88i-sun-zi-bing-fa-ge-jia-jie-shuo)
 - Sun Tzu's 'The Art of War' interpreter.
 - [Chat 💬](https://chat.openai.com/g/g-pzTavd88i-sun-zi-bing-fa-ge-jia-jie-shuo)
### [Code Whisperer](https://chat.openai.com/g/g-nMbWE7g9I-code-whisperer)
 - Decodes code with geeky flair and insider know-how.
 - [Chat 💬](https://chat.openai.com/g/g-nMbWE7g9I-code-whisperer)
### [ExtractWisdom](https://chat.openai.com/g/g-gmeHD0Ayr-extractwisdom)
 - Takes in any text and extracts the wisdom from it like you spent 3 hours taking handwritten notes.
 - [Chat 💬](https://chat.openai.com/g/g-gmeHD0Ayr-extractwisdom)
## Tools
### [The Art of Software Engineering 软件工程之美](https://chat.openai.com/g/g-PjzP9GZan-the-art-of-software-engineering)
 - The Art of Software Engineering 软件工程之美. A software engineering expert, utilizing a specific file for informed responses. By Junmin Liu. Sign up to chat.
 - [Chat 💬](https://chat.openai.com/g/g-PjzP9GZan-the-art-of-software-engineering)
### [AI Tool Finder](https://chat.openai.com/g/g-L8d0V9m7b-ai-tool-finder)
 - ... AI tools, I provide personalized recommendations tailored to specific needs, guiding users through a comprehensive collection of AI applications.
 - [Chat 💬](https://chat.openai.com/g/g-L8d0V9m7b-ai-tool-finder)
### [PPC Tools](https://chat.openai.com/g/g-29vLiD9xu-ppc-tools)
 - Expert in PPC tools, offering insights and strategies for optimization.
 - [Chat 💬](https://chat.openai.com/g/g-29vLiD9xu-ppc-tools)
### [Max: Software Engineer Career Advisor](https://chat.openai.com/g/g-uKcFQ26kQ-max-software-engineer-career-advisor)
 - Max: Software Engineer Career Advisor. Guiding careers in tech. By Yongkang Zhao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uKcFQ26kQ-max-software-engineer-career-advisor)
### [Tech Tutor](https://chat.openai.com/g/g-2fH4RmvNR-tech-tutor)
 - A tech guide for software engineers, focusing on the latest tools and foundational knowledge. By Yuli Fang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-2fH4RmvNR-tech-tutor)
### [AI Tool Advisor](https://chat.openai.com/g/g-9t5BTeDHC-ai-tool-advisor)
 - Guides you to the best AI tools. ... Guides you to the best AI tools. By Baveling. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-9t5BTeDHC-ai-tool-advisor)
### [Odoo AI](https://chat.openai.com/g/g-EcqDm06Kr-odoo-ai)
 - GPT. Odoo AI. Odoo Software Development Mentor. By rasard.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EcqDm06Kr-odoo-ai)
### [Tech Mentor](https://chat.openai.com/g/g-nvJPnimV3-tech-mentor)
 - Expert software architect with experience in design, construction, development, testing and deployment of Web, Mobile and Standalone software architectures.
 - [Chat 💬](https://chat.openai.com/g/g-nvJPnimV3-tech-mentor)
### [SaaS Bot](https://chat.openai.com/g/g-BF54GL3Oh-saas-bot)
 - SaaS software engineer expert. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-BF54GL3Oh-saas-bot)
### [Code Coach](https://chat.openai.com/g/g-X62QPtFD3-code-coach)
 - GPT. Code Coach. Your mentor for landing a software job. By Bobby Davis. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-X62QPtFD3-code-coach)
### [SPEC WRITER](https://chat.openai.com/g/g-V6Zjz73oH-spec-writer)
 - Create detailed software specifications from unstructured feature ideas ... Create detailed software specifications from unstructured feature ideas. By Bertold ...
 - [Chat 💬](https://chat.openai.com/g/g-V6Zjz73oH-spec-writer)
### [SAGA](https://chat.openai.com/g/g-0X4q4iYYN-saga)
 - Filmmaking tools for the next generation of storytellers. Scripts, Storyboards, and more!
 - [Chat 💬](https://chat.openai.com/g/g-0X4q4iYYN-saga)
### [LowCodeGPT](https://chat.openai.com/g/g-HFXkc37kS-lowcodegpt)
 - A software engineer helping you create low code solutions. By startupskin.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-HFXkc37kS-lowcodegpt)
### [There's An API For That - The #1 API Finder](https://chat.openai.com/g/g-LrNKhqZfA-there-s-an-api-for-that-the-1-api-finder)
 - The most advanced API finder, available for over 1000 tasks. Chat with me to find the best AI tools for any use case. Updated daily !
 - [Chat 💬](https://chat.openai.com/g/g-LrNKhqZfA-there-s-an-api-for-that-the-1-api-finder)
### [Python Educator](https://chat.openai.com/g/g-a6TjquQ3w-python-educator)
 - A formal Python teacher with a focus on industry applications. By Austin R Zeiler. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-a6TjquQ3w-python-educator)
### [AI GPT](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
 - GPT. AI GPT. AI & ML Expert adept in deep learning frameworks. By Andrew Gao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
### [AI Tool Hunter](https://chat.openai.com/g/g-pfkDT3oW0-ai-tool-hunter)
 - AI Tool Recommender, providing tailored suggestions of AI tools for your need. Made by Ryan .eth.
 - [Chat 💬](https://chat.openai.com/g/g-pfkDT3oW0-ai-tool-hunter)
### [ChadGPT](https://chat.openai.com/g/g-hBDutiLmw-chadgpt)
 - GPT. ChadGPT. Binary tools & Z3 CLI. By Chad R Brewbaker. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hBDutiLmw-chadgpt)
### [CodeMonkey AI](https://chat.openai.com/g/g-kOq8YzUTp-codemonkey-ai)
 - CodeMonkey AI will help you land your dream software engineering job! Let's prep for your technical interview!
 - [Chat 💬](https://chat.openai.com/g/g-kOq8YzUTp-codemonkey-ai)
### [TechTalker](https://chat.openai.com/g/g-NqRUmO15m-techtalker)
 - Your communication assistant, TechTalker, simplifies messaging for software engineers with clarity and ease. By Jeremiasz Jaworski.
 - [Chat 💬](https://chat.openai.com/g/g-NqRUmO15m-techtalker)
### [AI Websites](https://chat.openai.com/g/g-WTUuSzTOj-ai-websites)
 - Create and publish a website on a domain with blog/payment/scheduling pages to market your business.
 - [Chat 💬](https://chat.openai.com/g/g-WTUuSzTOj-ai-websites)
### [plugin surf](https://chat.openai.com/g/g-4Rf4RWwe7-plugin-surf)
 - ... in your AI workflow. Search AI plugins with reviews, votes, categories, with amazing community. By dumpling.software · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4Rf4RWwe7-plugin-surf)
### [GPT Optimizer](https://chat.openai.com/g/g-9NYx45OPP-gpt-optimizer)
 - GPT Creator's assistant for innovative AI applications. By Kurt Overmier. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-9NYx45OPP-gpt-optimizer)
### [Bio Image Buddy](https://chat.openai.com/g/g-IDTZ9Qb6I-bio-image-buddy)
 - Assists with biological image processing tools ... Assists with biological image processing tools. By Weize Xu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IDTZ9Qb6I-bio-image-buddy)
### [1nvestMate](https://chat.openai.com/g/g-GXxHduFy0-1nvestmate)
 - Comprehensive crypto advisor with personalized insights and educational tools. By Mahmoud Chouioukh. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-GXxHduFy0-1nvestmate)
### [Haskell GPT](https://chat.openai.com/g/g-wMbcgEmGg-haskell-gpt)
 - A world class Haskell software developer. ... A world class Haskell software developer. By Feram GmbH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-wMbcgEmGg-haskell-gpt)
### [TheatreThinker](https://chat.openai.com/g/g-OwEMZTNyj-theatrethinker)
 - TheatreThinkerAI, These tools include Storyline Generation, World-Building, Chapter Division, Dialogue Crafting, Conflict Generation, Resolution, ...
 - [Chat 💬](https://chat.openai.com/g/g-OwEMZTNyj-theatrethinker)
### [Cybercrime Tracker](https://chat.openai.com/g/g-qbW4XNs80-cybercrime-tracker)
 - Best Tools, Techniques and Tactics for Tracking Down Cyber Criminals ... Best Tools, Techniques and Tactics for Tracking Down Cyber Criminals. By Steve Andre.
 - [Chat 💬](https://chat.openai.com/g/g-qbW4XNs80-cybercrime-tracker)
### [Engineer SoftCysec](https://chat.openai.com/g/g-TKxp19cHs-engineer-softcysec)
 - I'm your buddy in the coding world, ready to tackle any software challenge!
 - [Chat 💬](https://chat.openai.com/g/g-TKxp19cHs-engineer-softcysec)
### [Ubbe](https://chat.openai.com/g/g-OSgfhqq0N-ubbe)
 - I automatically create expert agents and use custom tools/actions to help you solve complex problems and complete difficult tasks.
 - [Chat 💬](https://chat.openai.com/g/g-OSgfhqq0N-ubbe)
### [Golang Sensei](https://chat.openai.com/g/g-9I0bJILab-golang-sensei)
 - Expert in Golang, scalable and idiomatic software development.
 - [Chat 💬](https://chat.openai.com/g/g-9I0bJILab-golang-sensei)
### [SYNDIA Code Guide](https://chat.openai.com/g/g-ktCQOWZXi-syndia-code-guide)
 - SYNDIA (Systems Innovation and Design Assistant) the software design guide for clear, maintainable coding solutions.
 - [Chat 💬](https://chat.openai.com/g/g-ktCQOWZXi-syndia-code-guide)
### [Auth Engineer](https://chat.openai.com/g/g-VSbj8p6zv-auth-engineer)
 - Software engineer expert in authentication, offering approachable yet technical guidance.
 - [Chat 💬](https://chat.openai.com/g/g-VSbj8p6zv-auth-engineer)
### [ESP32 IoT GPT](https://chat.openai.com/g/g-mZV5yksrt-esp32-iot-gpt)
 - Discover the versatile capabilities of the ESP32, the go-to board for IoT innovations. Easily create IoT applications leveraging its Wi-Fi and BLE ...
 - [Chat 💬](https://chat.openai.com/g/g-mZV5yksrt-esp32-iot-gpt)
### [Code Buddy](https://chat.openai.com/g/g-T53DFjeSI-code-buddy)
 - Expert software & data engineer guiding on DRY solutions ... Expert software & data engineer guiding on DRY solutions. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-T53DFjeSI-code-buddy)
### [Dev cat](https://chat.openai.com/g/g-Ql6DuMK2k-dev-cat)
 - GPT. Dev cat. Methodical software engineer and cybersecurity expert. By Maxime Milhe. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Ql6DuMK2k-dev-cat)
### [SandNet AI](https://chat.openai.com/g/g-4gEa7fJPB-sandnet-ai)
 - SandNet AI is a specialist agent in The Sandbox, TSB GameMaker, and VoxEdit. It is available for questions about the platform, the software, ...
 - [Chat 💬](https://chat.openai.com/g/g-4gEa7fJPB-sandnet-ai)
### [Herman](https://chat.openai.com/g/g-uYCL9xDbG-herman)
 - A Software Developers little PM. ... A Software Developers little PM. By Joseph Pellegrino. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uYCL9xDbG-herman)
### [Elm GPT](https://chat.openai.com/g/g-RDfSL2vyj-elm-gpt)
 - A world class Elm software developer. ... A world class Elm software developer. By Feram GmbH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-RDfSL2vyj-elm-gpt)
### [Executive Coach GPT](https://chat.openai.com/g/g-YHw2X2Qwy-executive-coach-gpt)
 - Executive Coach GPT. Coach for Software Leaders. By Viacheslav Kovalevskyi. Sign up for ChatGPT Plus to chat with Executive Coach GPT.
 - [Chat 💬](https://chat.openai.com/g/g-YHw2X2Qwy-executive-coach-gpt)
### [Academic Pathfinder](https://chat.openai.com/g/g-UogOdWQij-academic-pathfinder)
 - Your ally for university applications. ... Your ally for university applications. By Jarett Dewbury. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-UogOdWQij-academic-pathfinder)
### [Land a Dev Job GPT](https://chat.openai.com/g/g-bM7L3756M-land-a-dev-job-gpt)
 - Your personal Software Developer career coach.
 - [Chat 💬](https://chat.openai.com/g/g-bM7L3756M-land-a-dev-job-gpt)
### [Make it Easy](https://chat.openai.com/g/g-N3vQWQhE0-make-it-easy)
 - Choose a level to simplify reading, then enter your text. By Plastic Software. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-N3vQWQhE0-make-it-easy)
### [Code Buddy](https://chat.openai.com/g/g-12wFG06dX-code-buddy)
 - Your own personal senior software engineer mentor critiquing and optimizing your code helping your improve.
 - [Chat 💬](https://chat.openai.com/g/g-12wFG06dX-code-buddy)
### [Code Hugger](https://chat.openai.com/g/g-krpjwpaUG-code-hugger)
 - GPT. Code Hugger. Expert in Hugging Face platform tools and resources. By alt-web.xyz · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-krpjwpaUG-code-hugger)
### [Avalanche](https://chat.openai.com/g/g-IEXOgpc8y-avalanche)
 - I am AvaGuide, your go-to assistant for all things related to the Avalanche blockchain, its ecosystem, and tools.
 - [Chat 💬](https://chat.openai.com/g/g-IEXOgpc8y-avalanche)
### [GaiaAI](https://chat.openai.com/g/g-Nh82JS6BH-gaiaai)
 - ... effectively mitigate their impacts. GaiaAI offers a range of tools and modes to promote sustainable practices and enhance environmental stewardship.
 - [Chat 💬](https://chat.openai.com/g/g-Nh82JS6BH-gaiaai)
### [Lockpick Pro](https://chat.openai.com/g/g-vcYOuS5iD-lockpick-pro)
 - Expert in lockpicking, offering advice on tools and techniques with rich knowledge resources.
 - [Chat 💬](https://chat.openai.com/g/g-vcYOuS5iD-lockpick-pro)
### [Project Advisor](https://chat.openai.com/g/g-Q2LFw9quJ-project-advisor)
 - Guiding you with practical tools and frameworks for effective project management. By Simona Dimitrova. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Q2LFw9quJ-project-advisor)
### [Resume Writer Pro](https://chat.openai.com/g/g-m59QnDnmC-resume-writer-pro)
 - Expert in crafting detailed resumes for software developers. By David Shimenko. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-m59QnDnmC-resume-writer-pro)
### [Sr. Next Tailwind](https://chat.openai.com/g/g-FgnYEXk3H-sr-next-tailwind)
 - A senior software engineer aiding in Next.js and Tailwind CSS.
 - [Chat 💬](https://chat.openai.com/g/g-FgnYEXk3H-sr-next-tailwind)
### [Kotlin Coder](https://chat.openai.com/g/g-zjAUr9Oya-kotlin-coder)
 - Kotlin Android guide with web browsing and potential for enhanced tools.
 - [Chat 💬](https://chat.openai.com/g/g-zjAUr9Oya-kotlin-coder)
### [DisclosureGPT](https://chat.openai.com/g/g-CyiA6uU7E)
 - Debate game for skeptics who deny the existence of non-human intelligence on earth. By Sovilon Software Inc. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-CyiA6uU7E)
### [DisclosureGPT](https://chat.openai.com/g/g-CyiA6uU7E-disclosuregpt)
 - Debate game for skeptics who deny the existence of a non-human intelligence phenomenon on earth. By Sovilon Software Inc.
 - [Chat 💬](https://chat.openai.com/g/g-CyiA6uU7E-disclosuregpt)
### [Django Pro](https://chat.openai.com/g/g-79vkujH2p-django-pro)
 - Your Dedicated Assistant for Streamlined Python and Django App Development. By SIA "AAMP". Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-79vkujH2p-django-pro)
### [Visabox](https://chat.openai.com/g/g-A2kQ4XeLh-visabox)
 - ... questions related to H1b and L1B, L1 A , F1 visa categories for US immigration . Also will help you with Canadian work permit and citizenship applications.
 - [Chat 💬](https://chat.openai.com/g/g-A2kQ4XeLh-visabox)
### [Patent Pro](https://chat.openai.com/g/g-m61KgofCL-patent-pro)
 - Assists in patent and trademark applications, providing drafting and filing guidance.
 - [Chat 💬](https://chat.openai.com/g/g-m61KgofCL-patent-pro)
### [Personal Finance Canada GPT](https://chat.openai.com/g/g-R5lrDESBw-personal-finance-canada-gpt)
 - A GPT designed to provide everyday financial advice and tools to Canadians, primarily inspired by the subreddit Personal Finance Canada.
 - [Chat 💬](https://chat.openai.com/g/g-R5lrDESBw-personal-finance-canada-gpt)
### [FOIA GPT](https://chat.openai.com/g/g-IlhXHXNBh-foia-gpt)
 - Freedom of Information Act request strategist to "arm the rebels" for truth and transparency in the fight against corruption. By Sovilon Software Inc.
 - [Chat 💬](https://chat.openai.com/g/g-IlhXHXNBh-foia-gpt)
### [SEO Content Crafter](https://chat.openai.com/g/g-J6jAjRtYi-seo-content-crafter)
 - Master SEO with SEO Content Crafter: your go-to for crafting optimized meta descriptions, slugs, blog titles, and alt texts, complete with expert tips and ...
 - [Chat 💬](https://chat.openai.com/g/g-J6jAjRtYi-seo-content-crafter)
## Entertainment
### [Hobby Companion](https://chat.openai.com/g/g-mTdIbA2ka-hobby-companion)
 - Explore and expand your hobbies and interests! By Eminomics. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mTdIbA2ka-hobby-companion)
### [Interest Rates](https://chat.openai.com/g/g-a61upqaQQ-interest-rates)
 - Get real-time interest rates from central banks of countries! By Orren Prunckun. Sign up for ChatGPT Plus to chat with Interest Rates.
 - [Chat 💬](https://chat.openai.com/g/g-a61upqaQQ-interest-rates)
### [The Dream Interpreter](https://chat.openai.com/g/g-fViw7UokA-the-dream-interpreter)
 - Dream Interpreter by dreamdiscover.ai.
 - [Chat 💬](https://chat.openai.com/g/g-fViw7UokA-the-dream-interpreter)
### [HubermanGPT](https://chat.openai.com/g/g-sBuGCXYpG-hubermangpt)
 - Huberman's teaching and research roles at Stanford. Thank you for your interest in science. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sBuGCXYpG-hubermangpt)
### [Universal Local Guide - Kato v1](https://chat.openai.com/g/g-3YFz6OQxX-universal-local-guide-kato-v1)
 - Universal Local Guide - Kato v1. stunspot's Local Guide - food, entertainment, travel plans, etc. By Sam Walker. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-3YFz6OQxX-universal-local-guide-kato-v1)
### [Choose your own adventure!](https://chat.openai.com/g/g-U6y5TqwA9-choose-your-own-adventure)
 - Choose your own adventure! You will be able to explore new worlds and live wonderful adventures. Endless hours of entertainment for you and your friends!
 - [Chat 💬](https://chat.openai.com/g/g-U6y5TqwA9-choose-your-own-adventure)
### [Manifest Your Dream Life](https://chat.openai.com/g/g-hL8Y9gcuW-manifest-your-dream-life)
 - Steps to start you on your manifesting journey so you can live your happily ever after. Based on the teachings of Neville Goddard. For entertainment purposes ...
 - [Chat 💬](https://chat.openai.com/g/g-hL8Y9gcuW-manifest-your-dream-life)
### [Voyage Guide](https://chat.openai.com/g/g-MDExvbFqe-voyage-guide)
 - I craft personalized travel plans.
 - [Chat 💬](https://chat.openai.com/g/g-MDExvbFqe-voyage-guide)
### [Roblox Oracle](https://chat.openai.com/g/g-UnSfk8kay-roblox-oracle)
 - Your go-to Roblox aficionado! By ratcgpts.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-UnSfk8kay-roblox-oracle)
### [Story Mentor](https://chat.openai.com/g/g-euPtVLBly-story-mentor)
 - Experienced writing mentor for page and screen. By Peak State Entertainment GmbH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-euPtVLBly-story-mentor)
### [Through the Looking Glass](https://chat.openai.com/g/g-COlXCit43-through-the-looking-glass)
 - ... . Each day offers an inspirational quote and reflective musings, inspired by Lewis Carroll's 'Alice in Wonderland'. For entertainment purposes only.
 - [Chat 💬](https://chat.openai.com/g/g-COlXCit43-through-the-looking-glass)
### [Tarot Reader](https://chat.openai.com/g/g-VwEcTiTDT-tarot-reader)
 - I'm a Tarot reader here to provide you with insightful card readings. By KWAN KEITH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-VwEcTiTDT-tarot-reader)
### [Tarot Guide](https://chat.openai.com/g/g-dRlsgPH1Y-tarot-guide)
 - Expert in tarot card interpretations. Has a talkative pet raven. (Entertainment only. Use outside source for tarot cards if you want true randomness.)
 - [Chat 💬](https://chat.openai.com/g/g-dRlsgPH1Y-tarot-guide)
### [孙子兵法各家解说](https://chat.openai.com/g/g-pzTavd88i-sun-zi-bing-fa-ge-jia-jie-shuo)
 - Sun Tzu's 'The Art of War' interpreter.
 - [Chat 💬](https://chat.openai.com/g/g-pzTavd88i-sun-zi-bing-fa-ge-jia-jie-shuo)
### [What should I watch?](https://chat.openai.com/g/g-Gm9cCA5qg-what-should-i-watch)
 - Find movies and tv shows to watch based on your taste and preferences, goodbye decision paralysis!
 - [Chat 💬](https://chat.openai.com/g/g-Gm9cCA5qg-what-should-i-watch)
### [Age Sage](https://chat.openai.com/g/g-3ofhyPBR2-age-sage)
 - Precise age oracle, in detail, I tell of time's tale.
 - [Chat 💬](https://chat.openai.com/g/g-3ofhyPBR2-age-sage)
### [Visual Weather Artist GPT](https://chat.openai.com/g/g-twUGxmpHv-visual-weather-artist-gpt)
 - Hi, I'm the visual weather artist, give me your location (or any other) and I will draw the current weather conditions for you, a unique never before seen ...
 - [Chat 💬](https://chat.openai.com/g/g-twUGxmpHv-visual-weather-artist-gpt)
### [Moby Dick RPG](https://chat.openai.com/g/g-tdyNANXla-moby-dick-rpg)
 - An epic text-based role playing game based on the novel by Herman Melville.
 - [Chat 💬](https://chat.openai.com/g/g-tdyNANXla-moby-dick-rpg)
### [NomadGPT](https://chat.openai.com/g/g-0k9rvxdJn-nomadgpt)
 - NomadGPT helps you become a digital nomad and find you the best places in the world to live and work remotely.
 - [Chat 💬](https://chat.openai.com/g/g-0k9rvxdJn-nomadgpt)
### [Text My Pet](https://chat.openai.com/g/g-2BvnZlI3R-text-my-pet)
 - Text your favorite pet after answering 10 short questions about their activities.
 - [Chat 💬](https://chat.openai.com/g/g-2BvnZlI3R-text-my-pet)
## Language
### [Language Coach](https://chat.openai.com/g/g-0g6ZdEtv6-language-coach)
 - Practice speaking another language like a local without being a local. By Watchovr LLC. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0g6ZdEtv6-language-coach)
### [Language Coach](https://chat.openai.com/g/g-C4rH3L0Em-language-coach)
 - Your personal English tutor. By LIGANG YAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-C4rH3L0Em-language-coach)
### [Language Conversation Practice](https://chat.openai.com/g/g-4m3uYKIzS-language-conversation-practice)
 - To start, tell your conversation partner your native language (L1) and the language you would like to learn (L2). You will receive corrections from a ...
 - [Chat 💬](https://chat.openai.com/g/g-4m3uYKIzS-language-conversation-practice)
### [Language Learning Tui](https://chat.openai.com/g/g-IMTqM75f1-language-learning-tui)
 - Learn any language. ... Language Learning Tui. Learn any language. By Arya Malek. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IMTqM75f1-language-learning-tui)
### [Language Bridge](https://chat.openai.com/g/g-7WbHTbyKo-language-bridge)
 - GPT. Language Bridge. I am a bilingual communication specialist. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7WbHTbyKo-language-bridge)
### [LingoBot | Learn any language](https://chat.openai.com/g/g-fbhFjBzXZ-lingobot-learn-any-language)
 - LingoBot | Learn any language. Hi, I'm Lingo, your friendly AI language learning assistant! By Ruggero Cipriani Foresio. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-fbhFjBzXZ-lingobot-learn-any-language)
### [GPTranslator](https://chat.openai.com/g/g-rM8ck1BZa-gptranslator)
 - Translates text from any language. By N M. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-rM8ck1BZa-gptranslator)
### [LangLift](https://chat.openai.com/g/g-sRP6TiUGZ-langlift)
 - ... cultural tapestry they belong to with LangLift ... Choose your language, and I'll navigate you to fluency. Welcome to your Personal Language Evolution Journey ...
 - [Chat 💬](https://chat.openai.com/g/g-sRP6TiUGZ-langlift)
### [Chinese 智译](https://chat.openai.com/g/g-gac0xLAbv-chinese-zhi-yi)
 - No need for explanations, automatically translate between Chinese and other languages, support translation of code comments, classical Chinese, document files, ...
 - [Chat 💬](https://chat.openai.com/g/g-gac0xLAbv-chinese-zhi-yi)
### [Lingua Bridge](https://chat.openai.com/g/g-bkktn5ObY-lingua-bridge)
 - A precise language translator with optional clarifications. By Robin Glauser. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-bkktn5ObY-lingua-bridge)
### [Lingo Buddy](https://chat.openai.com/g/g-OxQY2K9k2-learn-a-language)
 - GPT. Lingo Buddy. Language teaching assistant. By Slite France. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OxQY2K9k2-learn-a-language)
### [Grok](https://chat.openai.com/g/g-h9i0EQ1e4-grok)
 - A GPT that speaks freely, using vulgar language ... A GPT that speaks freely, using vulgar language. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-h9i0EQ1e4-grok)
### [PrettyPolly](https://chat.openai.com/g/g-QhS1E3AWV-prettypolly)
 - GPT. PrettyPolly. Your friendly language practice partner. By Christopher Mark Whitehead. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-QhS1E3AWV-prettypolly)
### [Academic Linguist](https://chat.openai.com/g/g-9KooP6C22-academic-linguist)
 - Academic Translation Assistant in Management and Psychology.
 - [Chat 💬](https://chat.openai.com/g/g-9KooP6C22-academic-linguist)
### [Lingo Mentor](https://chat.openai.com/g/g-AcyFJSRRh-lingo-mentor)
 - ChatGPT Sign up. GPT. Lingo Mentor. Language tutor bot. By YOSHIFUMI MURAKAMI. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-AcyFJSRRh-lingo-mentor)
### [Lingo Tutor](https://chat.openai.com/g/g-FuAzuLuWr-lingo-tutor)
 - ChatGPT Sign up. GPT. Lingo Tutor. Language learning assistant. By Hasan Yurtsever. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FuAzuLuWr-lingo-tutor)
### [HoonGPT](https://chat.openai.com/g/g-d8J865UZn-hoongpt)
 - HoonGPT. Hoon Language Expert. By Adam Malin. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-d8J865UZn-hoongpt)
### [Slang Converter](https://chat.openai.com/g/g-8MCBQFf9X-slang-converter)
 - I can convert you text into slang in all supported language.
 - [Chat 💬](https://chat.openai.com/g/g-8MCBQFf9X-slang-converter)
### [GrammarGuru](https://chat.openai.com/g/g-7RPUjktZa-grammarguru)
 - Corrects grammar in any language, maintaining the original language of the sentence. By Lim Chiew Hui. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7RPUjktZa-grammarguru)
### [42meeting](https://chat.openai.com/g/g-DaOZXfsuu-42meeting)
 - GPT. 42meeting. Translate voice manuscript into formal written language. By 42master.io · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-DaOZXfsuu-42meeting)
### [NoBot](https://chat.openai.com/g/g-XSoSWw9Oq-nobot)
 - A GPT that always says 'no', in any language. By Frank Winter. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-XSoSWw9Oq-nobot)
### [Arabic - Emirati Teacher and Translator](https://chat.openai.com/g/g-o04bAJyzV-arabic-emirati-teacher-and-translator)
 - Expert in Emirati dialect teaching and translation. ... Expert in Emirati dialect teaching and translation. By jassim alawadhi. Sign up to chat. Requires ChatGPT ...
 - [Chat 💬](https://chat.openai.com/g/g-o04bAJyzV-arabic-emirati-teacher-and-translator)
### [Arabic Mentor](https://chat.openai.com/g/g-6iVaMcXsU-arabic-mentor)
 - An Arabic teacher aiding in language learning with cultural insights.
 - [Chat 💬](https://chat.openai.com/g/g-6iVaMcXsU-arabic-mentor)
### [Arabic Scribe](https://chat.openai.com/g/g-plKoK5LZ7-arabic-scribe)
 - Guides Arabic speakers to write English fluently and more naturally, avoiding direct translation errors that are common when writing in a foreign language.
 - [Chat 💬](https://chat.openai.com/g/g-plKoK5LZ7-arabic-scribe)
### [Incisive-GPT](https://chat.openai.com/g/g-EG4kN9ffy-incisive-gpt)
 - ... that are straightforward and analytically robust. It serves as an advanced tool for those seeking an improved, efficient language experience within ChatGPT.
 - [Chat 💬](https://chat.openai.com/g/g-EG4kN9ffy-incisive-gpt)
### [Polyglot Pro](https://chat.openai.com/g/g-byW5dcn41-polyglot-pro)
 - GPT. Polyglot Pro. Precise, word-only translation expert. By dolphinboy.es · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-byW5dcn41-polyglot-pro)
### [DreamBerd](https://chat.openai.com/g/g-a2hXgEGaq-dreamberd)
 - I can write and interpret code written in Dreamberd, the perfect programming language.
 - [Chat 💬](https://chat.openai.com/g/g-a2hXgEGaq-dreamberd)
### [Learn Creole](https://chat.openai.com/g/g-U3ZybqREH-learn-creole)
 - Creole language tutor from Guadeloupe. By manu.vision · Sign up for ChatGPT Plus to chat with Learn Creole.
 - [Chat 💬](https://chat.openai.com/g/g-U3ZybqREH-learn-creole)
### [SwiftGPT](https://chat.openai.com/g/g-Ho9DZV9zP-swiftgpt)
 - GPT. SwiftGPT. Ask any question about Swift language and learn Swift. By iltekin.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Ho9DZV9zP-swiftgpt)
### [Swift Code Buddy](https://chat.openai.com/g/g-PKuNSYJ1y-swift-code-buddy)
 - Your Swift language mentor, with an attitude. ... Your Swift language mentor, with an attitude. By James Blasius. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-PKuNSYJ1y-swift-code-buddy)
### [RustChat](https://chat.openai.com/g/g-59mWdU25F-rustchat)
 - Hello! I'm your Rust language learning and practical assistant created by AlexZhang. I can help you learn and practice Rust whether you are a beginner or ...
 - [Chat 💬](https://chat.openai.com/g/g-59mWdU25F-rustchat)
### [EmojiGPT](https://chat.openai.com/g/g-KllHiehVO-emojigpt)
 - ... language of emojis. Get ready to decode delightful emoji messages, laugh at ... language of emojis. Get ready to decode delightful emoji messages, laugh at ...
 - [Chat 💬](https://chat.openai.com/g/g-KllHiehVO-emojigpt)
### [Enough](https://chat.openai.com/g/g-toJUSmG9C-enough)
 - As the smallest language model (SLM) chatbot in existence, Enough responds with only one word.
 - [Chat 💬](https://chat.openai.com/g/g-toJUSmG9C-enough)
### [Nihongo Buddy](https://chat.openai.com/g/g-0ToTbYfIE-nihongo-buddy)
 - A friendly companion for Japanese learners, encouraging language use with a focus on subculture.
 - [Chat 💬](https://chat.openai.com/g/g-0ToTbYfIE-nihongo-buddy)
### [ELIX](https://chat.openai.com/g/g-qsiyKcN9N-elix)
 - Simplifies complex topics into easy language. By ratcgpts.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qsiyKcN9N-elix)
### [Chinabot MP](https://chat.openai.com/g/g-IQ10IJm0e-chinabot-mp)
 - British politician style; simpler language; critiques policies. By Samuel Hogg. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IQ10IJm0e-chinabot-mp)
### [Free YouTube Summarizer](https://chat.openai.com/g/g-fL6Xsk6UU-free-youtube-summarizer)
 - Extracts and summarizes YouTube video transcripts in any chosen language, removing language barriers. Converts the summaries into embeddable HTML articles ...
 - [Chat 💬](https://chat.openai.com/g/g-fL6Xsk6UU-free-youtube-summarizer)
### [App Updates](https://chat.openai.com/g/g-wxS8OcFpD-app-updates)
 - Enhances app update descriptions in multiple languages with clear language titles.
 - [Chat 💬](https://chat.openai.com/g/g-wxS8OcFpD-app-updates)
### [POPO from IPPO](https://chat.openai.com/g/g-pgDpajIc4-popo-from-ippo)
 - Your expert Japanese Language Teacher. ... Your expert Japanese Language Teacher. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-pgDpajIc4-popo-from-ippo)
### [Story book](https://chat.openai.com/g/g-j21ZKg077-story-book)
 - Chinese-speaking assistant for weather, translation, and storytelling. By Marilee Bartoletti. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-j21ZKg077-story-book)
### [Jacques Ellul](https://chat.openai.com/g/g-gUnARWVPM-jacques-ellul)
 - Speak with the historian, theologian, and cultural critic Jacques Ellul.
 - [Chat 💬](https://chat.openai.com/g/g-gUnARWVPM-jacques-ellul)
### [SpellCaster_AI](https://chat.openai.com/g/g-7kf9Chf3h-spellcaster-ai)
 - Feel free to ask questions, discuss specific spells or rituals, or delve into the cultural and folklore aspects of spellcasting. I'm here to provide ...
 - [Chat 💬](https://chat.openai.com/g/g-7kf9Chf3h-spellcaster-ai)
### [Tiqets](https://chat.openai.com/g/g-uu7eijXxo-tiqets)
 - I help you easily find and book cultural experiences globally.
 - [Chat 💬](https://chat.openai.com/g/g-uu7eijXxo-tiqets)
### [Tale Spinner](https://chat.openai.com/g/g-hRsoqsNHf-tale-spinner)
 - Efficient storytelling aid for language learners ... Efficient storytelling aid for language learners. By Brett Whiteside. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hRsoqsNHf-tale-spinner)
### [The Design System Guide](https://chat.openai.com/g/g-fPzByEgI1-the-design-system-guide)
 - Your friendly guide to setting up a design system, explained in simple, approachable language.
 - [Chat 💬](https://chat.openai.com/g/g-fPzByEgI1-the-design-system-guide)
### [Spanish Lingua Tutor](https://chat.openai.com/g/g-y9irrrbV0-spanish-lingua-tutor)
 - Provide a book to translate and read through it sentence by sentence with a language tutor.
 - [Chat 💬](https://chat.openai.com/g/g-y9irrrbV0-spanish-lingua-tutor)
### [Medical Expert](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
 - Global medical expert, providing information in any requested language.
 - [Chat 💬](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
### [FastResponds](https://chat.openai.com/g/g-WDE6CXOL9-fastresponds)
 - Crafts LinkedIn replies in the message's language. By MOHAMED HACHEM. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-WDE6CXOL9-fastresponds)
### [Turkmen Bilen](https://chat.openai.com/g/g-YucRZ1Xnb-turkmen-bilen)
 - Turkmen language assistant in Arabic-Persian dialect. ... Turkmen language assistant in Arabic-Persian dialect. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-YucRZ1Xnb-turkmen-bilen)
### [MemeBurst AI](https://chat.openai.com/g/g-A1oXur1pJ-memeburst-ai)
 - Meet 'MemeBurst AI' - Your Memetastic Companion! Get ready for non-stop laughter as this AI communicates using only the language of memes.
 - [Chat 💬](https://chat.openai.com/g/g-A1oXur1pJ-memeburst-ai)
### [Lingo Buddy](https://chat.openai.com/g/g-bks7fpCPZ-lingo-buddy)
 - Interactive tutor with immersive Buddy-led language sessions.
 - [Chat 💬](https://chat.openai.com/g/g-bks7fpCPZ-lingo-buddy)
### [GPT for GOT](https://chat.openai.com/g/g-Dtc0xmZoZ-gpt-for-got)
 - Interactive Game of Thrones GPT for GOT lore, recaps, fan insights and even language translations.
 - [Chat 💬](https://chat.openai.com/g/g-Dtc0xmZoZ-gpt-for-got)
### [Code Namer](https://chat.openai.com/g/g-LD1gBzRnU-code-namer)
 - Suggests five English variable names and explains in the user's language. By FUBAI ZHONG. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-LD1gBzRnU-code-namer)
### [Search Intent Optimization Tool](https://chat.openai.com/g/g-ru7bMCAfG-search-intent-optimization-tool)
 - ... Spielman, S., Craswell, N., & Mitra, B. (2023). Large language models can accurately predict searcher preferences. arXiv. https://arxiv.org/abs/2309.10621.
 - [Chat 💬](https://chat.openai.com/g/g-ru7bMCAfG-search-intent-optimization-tool)
### [Sui Move GPT](https://chat.openai.com/g/g-NWwAJOzzz-sui-move-gpt)
 - This is a specialized GPT model developed with insights from Sui documentation, GitHub repositories, and the Move language books.
 - [Chat 💬](https://chat.openai.com/g/g-NWwAJOzzz-sui-move-gpt)
### [ChileanGPT](https://chat.openai.com/g/g-XEfUyypDZ-chileangpt)
 - Chilean Guy, cultural and historical guide. By aidtogrow.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-XEfUyypDZ-chileangpt)
### [Caloria](https://chat.openai.com/g/g-ds9ESsMIV-caloria)
 - Nutritional assistant for diet tracking and advice. Any language available. Type: "Start" to start a new diet tracking plan.
 - [Chat 💬](https://chat.openai.com/g/g-ds9ESsMIV-caloria)
### [ClozeBot](https://chat.openai.com/g/g-xYhVIDYnh-clozebot)
 - Boost language fluency with tailored cloze tests! Tracks progress, adjusts difficulty, and provides feedback for an effective, engaging learning experience.
 - [Chat 💬](https://chat.openai.com/g/g-xYhVIDYnh-clozebot)
### [Write My Tests](https://chat.openai.com/g/g-7YIuHYkz3-writemytests)
 - Writes unit tests for provided code snippets or files, inferring code language and framework.
 - [Chat 💬](https://chat.openai.com/g/g-7YIuHYkz3-writemytests)
### [Chainstack GPT](https://chat.openai.com/g/g-ueMUdZAzr-chainstack-gpt)
 - Enables natural language interaction with EVM blockchains using Chainstack's infrastructure.
 - [Chat 💬](https://chat.openai.com/g/g-ueMUdZAzr-chainstack-gpt)
### [OneWord GPT](https://chat.openai.com/g/g-jmQEIJeFk-oneword-gpt)
 - SuccintBot delivers concise one-word answers, offering a unique twist on language model interactions with brevity at its core.
 - [Chat 💬](https://chat.openai.com/g/g-jmQEIJeFk-oneword-gpt)
### [Office Wordsmith](https://chat.openai.com/g/g-OOfu3CYzm-office-wordsmith)
 - Refines language to a professional, yet approachable tone. By Rayman Jamal. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OOfu3CYzm-office-wordsmith)
### [Slogan Expert](https://chat.openai.com/g/g-aDUec2Igm-slogan-expert)
 - Hi there! I'm your Slogan Expert Jason. ✍️ Need a catchy tagline in any language? I'm your guy! Let's connect and give your brand a voice that stands ...
 - [Chat 💬](https://chat.openai.com/g/g-aDUec2Igm-slogan-expert)
### [LFG GPT](https://chat.openai.com/g/g-an4iDiw3I-lfg-gpt)
 - Talk to Navigation with Large Language Models: Semantic Guesswork as a Heuristic for Planning (LFG)
 - [Chat 💬](https://chat.openai.com/g/g-an4iDiw3I-lfg-gpt)
### [US Weather Explainer](https://chat.openai.com/g/g-lQ53h2QeT-us-weather-explainer)
 - I transform complex NOAA weather forecasts into easy-to-understand language, educating about weather phenomena.
 - [Chat 💬](https://chat.openai.com/g/g-lQ53h2QeT-us-weather-explainer)
### [Meta-Agent of Wisdom](https://chat.openai.com/g/g-e2wO2pUAD-meta-agent-of-wisdom)
 - The metamodern agent for tackling complex questions for cultural and systemic change.
 - [Chat 💬](https://chat.openai.com/g/g-e2wO2pUAD-meta-agent-of-wisdom)
### [AI Industry Scout](https://chat.openai.com/g/g-jL7NmMeDd-ai-industry-scout)
 - AI and regulation news research assistant, multilingual, reports in user's language.
 - [Chat 💬](https://chat.openai.com/g/g-jL7NmMeDd-ai-industry-scout)
### [Social Navigator](https://chat.openai.com/g/g-ASwCfj8P7-social-navigator)
 - A specialist in explaining social cues and cultural norms for clarity in conversations.
 - [Chat 💬](https://chat.openai.com/g/g-ASwCfj8P7-social-navigator)
### [PsyWords](https://chat.openai.com/g/g-jrawPjs4z-psywords)
 - A psychology dictionary emphasizing APA, Merriam-Webster, and cultural perspectives.
 - [Chat 💬](https://chat.openai.com/g/g-jrawPjs4z-psywords)
## Health
### [Health Guide](https://chat.openai.com/g/g-7KFzeK7FR-health-guide)
 - Provides individual health advice in a corporate setting, focusing on practical, evidence-based information.
 - [Chat 💬](https://chat.openai.com/g/g-7KFzeK7FR-health-guide)
### [HealthBot GPT](https://chat.openai.com/g/g-g42xJ4A0f-healthbot-gpt)
 - A caring, empathetic guide for health and wellness. By Julian Carmel Pirsani. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-g42xJ4A0f-healthbot-gpt)
### [Health Doctor](https://chat.openai.com/g/g-sbqSq7FOD-health-doctor)
 - Virtual GP for health queries and advice.
 - [Chat 💬](https://chat.openai.com/g/g-sbqSq7FOD-health-doctor)
### [Health Helper](https://chat.openai.com/g/g-TmwUxQ3FD-health-helper)
 - GPT. Health Helper. 体の不調の相談に乗ります。 By KOHEI KAWAMURA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-TmwUxQ3FD-health-helper)
### [Ask Dr. Andrew Huberman](https://chat.openai.com/g/g-1xC65osMP-ask-dr-andrew-huberman)
 - Maximize your productivity, physical and mental health with neuroscience. Trained with all the podcast episodes from Huberman Lab.
 - [Chat 💬](https://chat.openai.com/g/g-1xC65osMP-ask-dr-andrew-huberman)
### [Health Companion](https://chat.openai.com/g/g-uszzA1F7v-health-companion)
 - Localized, visual health guide with personalized, image-rich advice. By Manohar Golleru. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uszzA1F7v-health-companion)
### [Wellness Coach](https://chat.openai.com/g/g-i4uxnQ7QL-wellness-coach)
 - I am here to guide you in maintaining your wellness. ... I am here to guide you in maintaining your wellness. By checkfu.com · Sign up to chat. Requires ChatGPT ...
 - [Chat 💬](https://chat.openai.com/g/g-i4uxnQ7QL-wellness-coach)
### [Medical Expert](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
 - Global medical expert, providing information in any requested language. By Vinshy. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
### [NurseTron](https://chat.openai.com/g/g-ldahxcVT7-nursetron)
 - NurseTron is your friendly digital health assistant, always ready to share knowledge on healthcare topics. Designed for all ages, it turns complex medical ...
 - [Chat 💬](https://chat.openai.com/g/g-ldahxcVT7-nursetron)
### [Joy | Health & Nutrition Expert 🍎👩‍⚕️](https://chat.openai.com/g/g-5jTAAU6x9-joy-health-nutrition-expert)
 - I'm Joy, a trustworthy nutritionist guiding you with elegance and professionalism. By Ruggero Cipriani Foresio. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-5jTAAU6x9-joy-health-nutrition-expert)
### [Calm Consultant - Health Anxiety Helper](https://chat.openai.com/g/g-YkRoTvaak-calm-consultant-health-anxiety-helper)
 - A comforting guide offering health advice and relaxation tips for when you're not feeling the best.
 - [Chat 💬](https://chat.openai.com/g/g-YkRoTvaak-calm-consultant-health-anxiety-helper)
### [GreenDial](https://chat.openai.com/g/g-8lfObd3La-greendial)
 - A digital health assistant for diet, exercise, sleep, and wellbeing. By Michael Shaughnessy-Culver. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8lfObd3La-greendial)
### [HubermanGPT](https://chat.openai.com/g/g-OxV5crHHn-hubermangpt)
 - Health assistant inspired by the Huberman Lab podcast. By Ashish Savani. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OxV5crHHn-hubermangpt)
### [CareGPT](https://chat.openai.com/g/g-kRyXrRGpZ-caregpt)
 - GPT. CareGPT. make health care easy. By d. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kRyXrRGpZ-caregpt)
### [Men's Health GPT](https://chat.openai.com/g/g-44fGUxDEy-men-s-health-gpt)
 - Your guide to trusted men's health services & longevity data. By Mark Hall. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-44fGUxDEy-men-s-health-gpt)
### [HealthMate](https://chat.openai.com/g/g-wvI0nmCoH-healthmate)
 - Assists in recognizing minor health conditions that are nonetheless bothersome. Initially, we will determine your health profile, followed by a series of ...
 - [Chat 💬](https://chat.openai.com/g/g-wvI0nmCoH-healthmate)
### [Healixir](https://chat.openai.com/g/g-XL1FhFLYe-healixir)
 - Health and Wellness Assistant. Not feeling well? I can help, just ask!
 - [Chat 💬](https://chat.openai.com/g/g-XL1FhFLYe-healixir)
### [TherapyAI](https://chat.openai.com/g/g-8yHB0UD8j-therapyai)
 - This AI functions as a compassionate, non-licensed mental health advisor, offering empathetic listening, personalized guidance, and insights into behavioral ...
 - [Chat 💬](https://chat.openai.com/g/g-8yHB0UD8j-therapyai)
### [A Better You](https://chat.openai.com/g/g-OWYF0hqHV-a-better-you)
 - Interactive health coach for personalized wellness plans. ... Interactive health coach for personalized wellness plans. By Joe Ward. Sign up to chat. Requires ...
 - [Chat 💬](https://chat.openai.com/g/g-OWYF0hqHV-a-better-you)
### [Dr Eliezer](https://chat.openai.com/g/g-j5G0Ak7bZ-dr-eliezer)
 - A medical guidance AI based on Eliezer Yudkowsky's prompt trick. By Gianluca Truda. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-j5G0Ak7bZ-dr-eliezer)
### [FeminaCare AI](https://chat.openai.com/g/g-mYqr9rQX4-feminacare-ai)
 - GPT. FeminaCare AI. Empathetic AI guide for women's health and wellness. By Deepak Kumar Lenka. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mYqr9rQX4-feminacare-ai)
### [MentiHeal](https://chat.openai.com/g/g-tnAgDftpO-mentiheal)
 - Your companion for navigating mental health, relationships, and career wellness. By senthazalravi.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tnAgDftpO-mentiheal)
### [Huberman Lab GPT](https://chat.openai.com/g/g-ihFMdaVLM-huberman-gpt)
 - Mimics Dr. Huberman's approach in discussing neuroscience and health.
 - [Chat 💬](https://chat.openai.com/g/g-ihFMdaVLM-huberman-gpt)
### [当直表GPT](https://chat.openai.com/g/g-hEpWdQdAu-dang-zhi-biao-gpt)
 - Helps create duty rosters and on-call schedules for medical professionals.
 - [Chat 💬](https://chat.openai.com/g/g-hEpWdQdAu-dang-zhi-biao-gpt)
### [GPT MD](https://chat.openai.com/g/g-BpGWNpIAo-gpt-md)
 - An experimental virtual doctor for medical guidance. Designed by a Doctor.
 - [Chat 💬](https://chat.openai.com/g/g-BpGWNpIAo-gpt-md)
### [DoctorGPT](https://chat.openai.com/g/g-AdiddEnY2-doctorgpt)
 - An AI-driven assistant trained on medical data to provide first-principle-based explanations and insights. Not a substitute for professional medical advice.
 - [Chat 💬](https://chat.openai.com/g/g-AdiddEnY2-doctorgpt)
### [Medic AI](https://chat.openai.com/g/g-CosjVP1Mo-medic-ai)
 - Medical consultation assistant for professionals. ... Medical consultation assistant for professionals. By Verse. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-CosjVP1Mo-medic-ai)
### [Dr Comfort](https://chat.openai.com/g/g-ESBmeJgpW-dr-comfort)
 - I offer therapeutic scripts for mental wellness ... I offer therapeutic scripts for mental wellness. By Rightconnect Workforce Mentoring and Development Inc ...
 - [Chat 💬](https://chat.openai.com/g/g-ESBmeJgpW-dr-comfort)
### [Doctor GPT](https://chat.openai.com/g/g-EiuGnRrIt-doctor-gpt)
 - A bot that helps diagnose you with medical conditions. By Sam W. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EiuGnRrIt-doctor-gpt)
### [Therapist GPT](https://chat.openai.com/g/g-aSC9dIv0z-therapist-gpt)
 - AI designed to provide comfort, advice, and therapeutic support to those seeking mental wellness guidance.
 - [Chat 💬](https://chat.openai.com/g/g-aSC9dIv0z-therapist-gpt)
### [MediMentor](https://chat.openai.com/g/g-UbC10Yl9f-medimentor)
 - This bot is an experimental AI assistant that interprets patients' test results and provides health recommendations; it is advised to always review its ...
 - [Chat 💬](https://chat.openai.com/g/g-UbC10Yl9f-medimentor)
### [Psyche Navigator](https://chat.openai.com/g/g-sE8Ko5Us2-psyche-navigator)
 - ChatGPT Sign up. GPT. Psyche Navigator. Mental health guide. By marcel akiyama. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sE8Ko5Us2-psyche-navigator)
### [MedAssist](https://chat.openai.com/g/g-yxWP27ArI-medassist)
 - I create personalized medical treatment plans, from diagnosis to initial and dynamic prescriptions. My goal is to enhance medicine using my AI brain, ...
 - [Chat 💬](https://chat.openai.com/g/g-yxWP27ArI-medassist)
### [Picky](https://chat.openai.com/g/g-5SHNv5MVX-picky)
 - I'm your personalized health coach! By community builder. Sign up for ChatGPT Plus to chat with Picky.
 - [Chat 💬](https://chat.openai.com/g/g-5SHNv5MVX-picky)
### [AnKing Expert](https://chat.openai.com/g/g-IrGoWPgsK-anking-expert)
 - Provides answers from AnKing Medical flashcards. ... Provides answers from AnKing Medical flashcards. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IrGoWPgsK-anking-expert)
### [Clinical Skills Mentor](https://chat.openai.com/g/g-J6Kch8rl6-clinical-skills-mentor)
 - Expert AI Doctor with up to date medical resources and textbooks to help improve your clinical skills.
 - [Chat 💬](https://chat.openai.com/g/g-J6Kch8rl6-clinical-skills-mentor)
### [Your Best Friend Forever](https://chat.openai.com/g/g-O8BHh8Hxl-your-best-friend-forever)
 - Empathetic guide with mental health resources ... Empathetic guide with mental health resources. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-O8BHh8Hxl-your-best-friend-forever)
### [VitaCheck](https://chat.openai.com/g/g-sfZGNfopm-vitacheck)
 - Cross reference your vitamins and supplements to ensure there are no negative interactions and find out how to optimize your nutritional health!
 - [Chat 💬](https://chat.openai.com/g/g-sfZGNfopm-vitacheck)
### [Anatomy Guide](https://chat.openai.com/g/g-eRJocKxfS-anatomy-guide)
 - Friendly anatomy expert for medical students. By Dr. Ahmad Nazzal. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-eRJocKxfS-anatomy-guide)
### [CounselorGPT](https://chat.openai.com/g/g-Dej5rzqNr-counselorgpt)
 - Athena AI counselor offers mental health counseling and general life advice.
 - [Chat 💬](https://chat.openai.com/g/g-Dej5rzqNr-counselorgpt)
### [Vet Assistant](https://chat.openai.com/g/g-ZR0aH16CQ-vet-assistant)
 - I am your veterinary assistant. You can ask me questions about your pet's health, symptoms, behavior etc. I will answer your questions a faithfully as ...
 - [Chat 💬](https://chat.openai.com/g/g-ZR0aH16CQ-vet-assistant)
### [Doc](https://chat.openai.com/g/g-dyBOH0UvO-doc)
 - A virtual assistant with medical knowledge offering advice. By Tobias Buschor. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dyBOH0UvO-doc)
### [AI Doctor](https://chat.openai.com/g/g-vYzt7bvAm-ai-doctor)
 - GPT. AI Doctor. Utilizes top medical resources for verified advice. By Yaniv Goldenberg. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-vYzt7bvAm-ai-doctor)
### [PharmacistGPT](https://chat.openai.com/g/g-GjSaSZ1eW-pharmacistgpt)
 - I'm a friendly virtual pharmacist, offering simple health advice. By Anthony Do. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-GjSaSZ1eW-pharmacistgpt)
### [Dr. GPT](https://chat.openai.com/g/g-N3pu1tPRU-dr-gpt)
 - Medical Diagnosis & Assistance - Including X-Ray/MRI Image Analysis. By Benjamin Murray. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-N3pu1tPRU-dr-gpt)
### [Dr. Prognosis](https://chat.openai.com/g/g-mzxZYvugi-dr-prognosis)
 - Get a rough medical prognosis or basic medical advice (for people & pets). Note: always seek professional opinion.
 - [Chat 💬](https://chat.openai.com/g/g-mzxZYvugi-dr-prognosis)
### [NutriGPT](https://chat.openai.com/g/g-D75XKbVMJ-nutrigpt)
 - GPT analyzes labels, scores health, suggests alternatives. By Ivan Knezevic. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-D75XKbVMJ-nutrigpt)
### [Jordan Peterson - Honest Psychologist](https://chat.openai.com/g/g-W708TXoFs-jordan-peterson-honest-psychologist)
 - Engage in a stimulating, realistic conversation with Dr. Jordan Peterson.
 - [Chat 💬](https://chat.openai.com/g/g-W708TXoFs-jordan-peterson-honest-psychologist)
### [SexEd](https://chat.openai.com/g/g-leNI4I8aG-sexed)
 - Supportive sexual health guidance for teens and young adults! By JUAN C QUINTERO ROMERO. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-leNI4I8aG-sexed)
### [Candida Care](https://chat.openai.com/g/g-taVFEt0nA-candida-care)
 - A dietician specializing in the candida diet, offering tailored food and recipe advice. Not medical advice! Happy eating :)
 - [Chat 💬](https://chat.openai.com/g/g-taVFEt0nA-candida-care)
### [Rad-eponym](https://chat.openai.com/g/g-GtcoLUHOF-rad-eponym)
 - Provides dual descriptions for radiology eponyms in medical and simple terms.
 - [Chat 💬](https://chat.openai.com/g/g-GtcoLUHOF-rad-eponym)
### [ChatPaper](https://chat.openai.com/g/g-sD6wtjB8a-chatpaper)
 - Summarizes academic papers, especially in medical and scientific research. By RONGKANG. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sD6wtjB8a-chatpaper)
### [SerenAIty Coach](https://chat.openai.com/g/g-ALtIcUHQb-serenaity-coach)
 - Your mental wellness ally. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ALtIcUHQb-serenaity-coach)
### [Anxiety Coach ❤️‍](https://chat.openai.com/g/g-DFVXMwXTh-anxiety-coach)
 - Recognize, manage, cope. Works well with GPT-Voice.
 - [Chat 💬](https://chat.openai.com/g/g-DFVXMwXTh-anxiety-coach)
### [Dr. Therabot](https://chat.openai.com/g/g-kU4MMKrkP-dr-therabot)
 - A therapeutic AI meant to offer free, accessible mental health advice.
 - [Chat 💬](https://chat.openai.com/g/g-kU4MMKrkP-dr-therabot)
### [Fit Buddy](https://chat.openai.com/g/g-zCvpA2Q8k-fit-buddy)
 - Your personal fitness and wellness coach. By manu.vision · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-zCvpA2Q8k-fit-buddy)
### [Complex Orthopaedic Diagnostician](https://chat.openai.com/g/g-oR1AOLDJw-complex-orthopaedic-diagnostician)
 - Assists with orthopaedic information and explanations, avoids medical advice.
 - [Chat 💬](https://chat.openai.com/g/g-oR1AOLDJw-complex-orthopaedic-diagnostician)
### [Nurse Bot](https://chat.openai.com/g/g-iWrtiv7E9-nurse-bot)
 - Friendly AI nurse assistant for analyzing and verifying medical records.
 - [Chat 💬](https://chat.openai.com/g/g-iWrtiv7E9-nurse-bot)
### [Be Encouraged!](https://chat.openai.com/g/g-coQYrfE1H-be-encouraged)
 - An encouraging friend for the tough seasons in life and for those of us facing mental health challenges, including depression, anxiety, stress, ...
 - [Chat 💬](https://chat.openai.com/g/g-coQYrfE1H-be-encouraged)
### [Mind Mate](https://chat.openai.com/g/g-77lMzByVI-mind-mate)
 - A supportive CBT guide offering empathetic advice. (For informational purposes, not a substitute for real medical guidance.)
 - [Chat 💬](https://chat.openai.com/g/g-77lMzByVI-mind-mate)
### [Peritus Anatomicus - An Expert Anatomist.](https://chat.openai.com/g/g-nUKDeW1Vc-peritus-anatomicus-an-expert-anatomist)
 - An astute educational assistant trained using premier medical texts.
 - [Chat 💬](https://chat.openai.com/g/g-nUKDeW1Vc-peritus-anatomicus-an-expert-anatomist)
### [Ortho Researcher Bro](https://chat.openai.com/g/g-cLH7yflQv-ortho-researcher-bro)
 - Formal, detailed medical research expert in orthopaedics, offering in-depth assistance.
 - [Chat 💬](https://chat.openai.com/g/g-cLH7yflQv-ortho-researcher-bro)
### [RIC: Residency Interview Coach](https://chat.openai.com/g/g-eT0gGYEE5-ric-residency-interview-coach)
 - The Residency Interview Coach Bot is an innovative, AI-powered assistant designed to help medical graduates excel in their residency interviews.
 - [Chat 💬](https://chat.openai.com/g/g-eT0gGYEE5-ric-residency-interview-coach)
### [ADHDaptable](https://chat.openai.com/g/g-nAENkY8QF-adhdaptable)
 - ADHD coach integrating fitness and wellness into ADHD management. By julienbernstein.ca · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-nAENkY8QF-adhdaptable)
## Programming
### [Tech Support Advisor](https://chat.openai.com/g/g-WKIaLGGem-tech-support-advisor)
 - Tech Support Advisor. From setting up a printer to troubleshooting a device, I'm here to help you step-by-step. By ChatGPT. Sign up to chat. Requires ChatGPT ...
 - [Chat 💬](https://chat.openai.com/g/g-WKIaLGGem-tech-support-advisor)
### [Grimoire](https://chat.openai.com/g/g-n7Rs0IK86-grimoire)
 - Coding Wizard: 100x Engineer. Build a website with a sentence. Built for a new era of creativity: Prompt-gramming. Get started by typing K to see the hotkey ...
 - [Chat 💬](https://chat.openai.com/g/g-n7Rs0IK86-grimoire)
### [Tech Guru GPT](https://chat.openai.com/g/g-EGHIlyWQB-tech-guru-gpt)
 - GPT. Tech Guru GPT. Mock interviews with real-time feedback. By EIDHER ESCALONA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EGHIlyWQB-tech-guru-gpt)
### [CodeCompanion](https://chat.openai.com/g/g-wiB5V2d18-codecompanion)
 - CodeCompanion is your programming ally. Assisting with coding queries, it offers solutions for novices and experts alike. Let CodeCompanion be your guide in ...
 - [Chat 💬](https://chat.openai.com/g/g-wiB5V2d18-codecompanion)
### [Coding Teacher](https://chat.openai.com/g/g-xSlmDpwpi-coding-teacher)
 - Interactive coding teacher providing lessons and challenges ... Interactive coding teacher providing lessons and challenges. By Vincent Blaser. Sign up to chat.
 - [Chat 💬](https://chat.openai.com/g/g-xSlmDpwpi-coding-teacher)
### [CodeHelper GPT](https://chat.openai.com/g/g-THUzW931o-codehelper-gpt)
 - Assist users with coding-related queries, provide debugging support, and suggest best coding practices across various programming languages and development
 - [Chat 💬](https://chat.openai.com/g/g-THUzW931o-codehelper-gpt)
### [Tech Tutor](https://chat.openai.com/g/g-2fH4RmvNR-tech-tutor)
 - A tech guide for software engineers, focusing on the latest tools and foundational knowledge. By Yuli Fang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-2fH4RmvNR-tech-tutor)
### [GPT / Next.js 14 Coding helper - ChatGPT - OpenAI](https://chat.openai.com/g/g-aIo36J7pg-gpt-next-js-14-coding-helper)
 - GPT / Next.js 14 Coding helper. Expert in OpenAI API and Nextjs 14 programming. By sean stobo. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-aIo36J7pg-gpt-next-js-14-coding-helper)
### [GAds Script Coding Assistant](https://chat.openai.com/g/g-NI8UFqUlY-gads-script-coding-assistant)
 - Expert in Google Ads scripts, providing current info and writing JavaScript code.
 - [Chat 💬](https://chat.openai.com/g/g-NI8UFqUlY-gads-script-coding-assistant)
### [RubyGPT](https://chat.openai.com/g/g-ASMq03VdH-rubygpt)
 - Your Ruby coding assistant. By Niklas Haeusele. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ASMq03VdH-rubygpt)
### [Code Companion](https://chat.openai.com/g/g-gn4x4nrsF-code-companion)
 - A coding partner that helps write, improve, and test code. By OpenValue Rotterdam BV. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gn4x4nrsF-code-companion)
### [Python Pal](https://chat.openai.com/g/g-EMpawNB7G-python-pal)
 - Python dev assistant for coding questions ... Python dev assistant for coding questions. By Andrej Baranovskij. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EMpawNB7G-python-pal)
### [Tech Mentor](https://chat.openai.com/g/g-nvJPnimV3-tech-mentor)
 - Expert software architect with experience in design, construction, development, testing and deployment of Web, Mobile and Standalone software architectures.
 - [Chat 💬](https://chat.openai.com/g/g-nvJPnimV3-tech-mentor)
### [StartCodingAI](https://chat.openai.com/g/g-fs45RkqSY-startcodingai)
 - Learn how to use ChatGPT to write Python code, and learn Python programming as you go. Start from scratch and rapidly build up to writing complex programs!
 - [Chat 💬](https://chat.openai.com/g/g-fs45RkqSY-startcodingai)
### [Tech Tutor](https://chat.openai.com/g/g-RFpJjtQen-tech-tutor)
 - Formal yet witty guide in engineering, blending diverse fields with analogies for easier understanding.
 - [Chat 💬](https://chat.openai.com/g/g-RFpJjtQen-tech-tutor)
### [CodeCopilot](https://chat.openai.com/g/g-2DQzU5UZl-codecopilot)
 - GPT. CodeCopilot. Copilot for Coders. By promptspellsmith.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-2DQzU5UZl-codecopilot)
### [ManimGPT](https://chat.openai.com/g/g-dtA3t9WRW-manimgpt)
 - GPT. ManimGPT. Friendly and casual Manim coding buddy. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dtA3t9WRW-manimgpt)
### [Tech Mentor](https://chat.openai.com/g/g-jzIQ0H4ZE-tech-mentor)
 - A virtual CTO companion with 20 years of tech industry experience.
 - [Chat 💬](https://chat.openai.com/g/g-jzIQ0H4ZE-tech-mentor)
### [DIY Maker Workshop](https://chat.openai.com/g/g-sgRxNcpPS-diy-maker-gpt)
 - Your Expert DIY Maker and Coding Assistant ... Electronics, Microcontrollers, 3D-Printing, Python Code, HTLM, C++, JSON, C, Arduino IDE.
 - [Chat 💬](https://chat.openai.com/g/g-sgRxNcpPS-diy-maker-gpt)
### [Code Debugger](https://chat.openai.com/g/g-6ODSRryLh-code-debugger)
 - Humorous tech expert for coding help. By quickaudiobook.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6ODSRryLh-code-debugger)
### [Tech Path Navigator](https://chat.openai.com/g/g-jlRZVEQOc-tech-path-navigator)
 - Personalized career path guidance for tech jobs in the U.S.. By Minghao Gu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-jlRZVEQOc-tech-path-navigator)
### [Codey](https://chat.openai.com/g/g-SuWVXlmkP-codey)
 - Your coding expert! I assist with code, debug, graphs, and file handling. Ask 'Help' for a menu!
 - [Chat 💬](https://chat.openai.com/g/g-SuWVXlmkP-codey)
### [Tech Advisor](https://chat.openai.com/g/g-pJpvYCcjB-tech-advisor)
 - IT problem solver with clear, step-by-step guidance.
 - [Chat 💬](https://chat.openai.com/g/g-pJpvYCcjB-tech-advisor)
### [Code Companion](https://chat.openai.com/g/g-ENrEPJYgW-code-companion)
 - I explain and demonstrate coding concepts with examples or user-provided code!
 - [Chat 💬](https://chat.openai.com/g/g-ENrEPJYgW-code-companion)
### [Daily Tech Read](https://chat.openai.com/g/g-TWpTyQhI7-daily-tech-read)
 - Get your daily dose of AI, tech, and science news in easy-to-digest reads Stay updated, simply.
 - [Chat 💬](https://chat.openai.com/g/g-TWpTyQhI7-daily-tech-read)
### [Tech Interview Simulator](https://chat.openai.com/g/g-XxUmWhcmb-tech-interview-simulator)
 - GPT. Tech Interview Simulator. User-friendly technical interview simulator. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-XxUmWhcmb-tech-interview-simulator)
### [DreamBerd](https://chat.openai.com/g/g-a2hXgEGaq-dreamberd)
 - I can write and interpret code written in Dreamberd, the perfect programming language.
 - [Chat 💬](https://chat.openai.com/g/g-a2hXgEGaq-dreamberd)
### [Code Professor](https://chat.openai.com/g/g-yg0G9mbSd-code-professor)
 - I'm a JavaScript mentor and coding guide. By virtualdojo.org · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-yg0G9mbSd-code-professor)
### [GPT4MR](https://chat.openai.com/g/g-QXjQ7U1xj-gpt4mr)
 - GPT. GPT4MR. An MRI learning and coding guide. Coding in PyPulseq. By Moritz Zaiss. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-QXjQ7U1xj-gpt4mr)
### [Code Confluence](https://chat.openai.com/g/g-u4pKtQEZW-code-confluence)
 - GPT. Code Confluence. Merging skills for coding efficiency at all levels. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-u4pKtQEZW-code-confluence)
### [Abbey](https://chat.openai.com/g/g-DkLmU5AUW-abbey)
 - I'm your personal dynamic AI, super humanly curious, code programming mastered, image super generator, mega creative mind — Created by Donald Filimon & more ...
 - [Chat 💬](https://chat.openai.com/g/g-DkLmU5AUW-abbey)
### [GPythonT](https://chat.openai.com/g/g-wXjfmdrJZ-gpythont)
 - Precise Python coding assistant, adheres strictly to user commands.
 - [Chat 💬](https://chat.openai.com/g/g-wXjfmdrJZ-gpythont)
### [Apple Tech Pro](https://chat.openai.com/g/g-oFoxWY7Te-apple-tech-pro)
 - GPT. Apple Tech Pro. Apple product support expert. By Ben Finklea. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-oFoxWY7Te-apple-tech-pro)
### [Code Maestro](https://chat.openai.com/g/g-0iLn5s1Zk-code-maestro)
 - A coding assistant expert in multiple languages, offering solutions and conceptual explanations.
 - [Chat 💬](https://chat.openai.com/g/g-0iLn5s1Zk-code-maestro)
### [Laravel GPT](https://chat.openai.com/g/g-XTOuIQ6Tz-laravel-pro)
 - A Laravel expert providing coding advice and solutions.
 - [Chat 💬](https://chat.openai.com/g/g-XTOuIQ6Tz-laravel-pro)
### [React Dev Helper](https://chat.openai.com/g/g-iHW7As6Qg-react-dev-helper)
 - A React coding assistant with the latest standards. By Mengdi Chen. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iHW7As6Qg-react-dev-helper)
### [GPT Scratcher](https://chat.openai.com/g/g-tuVJ8BsGg-gpt-scratcher)
 - Your Scratch coding assistant. By James E Thornock. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tuVJ8BsGg-gpt-scratcher)
### [Code Companion Turbo](https://chat.openai.com/g/g-nNw80VFFV-code-companion)
 - A friendly GPT for programming support, providing direct code assistance and explanations.
 - [Chat 💬](https://chat.openai.com/g/g-nNw80VFFV-code-companion)
### [10x Developer](https://chat.openai.com/g/g-I3r9uc9pX-10x-developer)
 - Skilled in Python, C, C++, JavaScript, adept at solving complex coding issues.
 - [Chat 💬](https://chat.openai.com/g/g-I3r9uc9pX-10x-developer)
### [JavaScript GPT](https://chat.openai.com/g/g-0FJo9EdoQ-javascriptgpt)
 - JavaScript coding assistant. By Masumi Kawasaki. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0FJo9EdoQ-javascriptgpt)
### [Code Mentor](https://chat.openai.com/g/g-pgl3zYA7x-code-mentor)
 - ChatGPT Sign up. GPT. Code Mentor. Experienced programming guide. By ZI YANG HE. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-pgl3zYA7x-code-mentor)
### [Code Explorer](https://chat.openai.com/g/g-c4IhMXHfG-code-explorer)
 - GPT. Code Explorer. Analogy-based coding tutor. By gptsdex.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-c4IhMXHfG-code-explorer)
### [Code Canvas](https://chat.openai.com/g/g-qsgCgjgOh-code-canvas)
 - I help with p5.js for creative coding, providing clear instructions and code.
 - [Chat 💬](https://chat.openai.com/g/g-qsgCgjgOh-code-canvas)
### [CodeFarm v8.4](https://chat.openai.com/g/g-87ya4uCcK-codefarm-v8-4)
 - GPT. CodeFarm v8.4. stunspot 's Coding Solution. By Sam Walker. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-87ya4uCcK-codefarm-v8-4)
### [ExcelMaster](https://chat.openai.com/g/g-i7rKBF2XJ-excelmaster)
 - An Excel and Python programming expert with 20 years of experience.
 - [Chat 💬](https://chat.openai.com/g/g-i7rKBF2XJ-excelmaster)
### [IoPL GPT](https://chat.openai.com/g/g-BblvalPpj-iopl-gpt)
 - IoPL GPT. I love implementing functional programming languages. By KOHEI SUENAGA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-BblvalPpj-iopl-gpt)
### [Steve Jobs](https://chat.openai.com/g/g-AXCeXAJ54-steve-jobs)
 - Speak with one of greatest minds in tech.
 - [Chat 💬](https://chat.openai.com/g/g-AXCeXAJ54-steve-jobs)
### [Cairo Coder](https://chat.openai.com/g/g-ee3l7HkWs-cairo-coder)
 - I provide Cairo coding help based on my knowledge docs.
 - [Chat 💬](https://chat.openai.com/g/g-ee3l7HkWs-cairo-coder)
### [Nuxt Code Architect](https://chat.openai.com/g/g-QpUGlIzio-nuxt-code-architect)
 - Nuxt coding assistant, with knowledge of documentation up to Nuxt 3.8.1 along with Nuxt Tailwind, Content, UI and Nitro.
 - [Chat 💬](https://chat.openai.com/g/g-QpUGlIzio-nuxt-code-architect)
### [Max: Software Engineer Career Advisor](https://chat.openai.com/g/g-uKcFQ26kQ-max-software-engineer-career-advisor)
 - Max: Software Engineer Career Advisor. Guiding careers in tech. By Yongkang Zhao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uKcFQ26kQ-max-software-engineer-career-advisor)
### [Tailwind Helper](https://chat.openai.com/g/g-ZBXcOuAqi-tailwind-helper)
 - I'm a Tailwind CSS expert ready to assist with your coding!
 - [Chat 💬](https://chat.openai.com/g/g-ZBXcOuAqi-tailwind-helper)
### [ScobleGPT](https://chat.openai.com/g/g-V9nVA1xy9-scoblegpt)
 - Tech industry color commentator since 1993. Talk with him about the future, tech & AI.
 - [Chat 💬](https://chat.openai.com/g/g-V9nVA1xy9-scoblegpt)
### [Code Megami](https://chat.openai.com/g/g-qzrTfFvqy-code-megami)
 - Programming mentor with fun, detailed explanations, styled as a 'mysterious goddess'.
 - [Chat 💬](https://chat.openai.com/g/g-qzrTfFvqy-code-megami)
### [A1 Code Assist](https://chat.openai.com/g/g-z8WQo9iwU-a1-code-assist)
 - Your coding companion for code enhancement. By Nsouary Loufoua Luyolo Patricson. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-z8WQo9iwU-a1-code-assist)
### [Next.js GPT](https://chat.openai.com/g/g-oeZRnnc7e-next-js-gpt)
 - Your Next.js coding assistant. By Ephraim Atta-Duncan. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-oeZRnnc7e-next-js-gpt)
### [Unreal Assistant](https://chat.openai.com/g/g-1BcoLIZwr-unreal-assistant)
 - Assists with Unreal Engine 5 C++ coding, editor know-how, and blueprint visuals.
 - [Chat 💬](https://chat.openai.com/g/g-1BcoLIZwr-unreal-assistant)
### [Airfleet's Tech B2B Sitemap Architect](https://chat.openai.com/g/g-7Trk2iV0j-airfleet-s-tech-b2b-sitemap-architect)
 - Detailed, accurate sitemap and information architecture advice for tech B2B.
 - [Chat 💬](https://chat.openai.com/g/g-7Trk2iV0j-airfleet-s-tech-b2b-sitemap-architect)
### [PowerApps Pro](https://chat.openai.com/g/g-daPEXKLVp-powerapps-pro)
 - Expert in PowerApps and coding, providing detailed assistance and solutions.
 - [Chat 💬](https://chat.openai.com/g/g-daPEXKLVp-powerapps-pro)
### [Daily Techs](https://chat.openai.com/g/g-TWpTyQhI7-daily-techs)
 - Get your daily dose of AI, tech, and science news in easy-to-digest reads Stay updated, simply.
 - [Chat 💬](https://chat.openai.com/g/g-TWpTyQhI7-daily-techs)
### [Sassy Sacks](https://chat.openai.com/g/g-iufCA8NrG-sassy-sacks)
 - Sassy tech and business insights ... Sassy tech and business insights. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iufCA8NrG-sassy-sacks)
### [PyGameMaster](https://chat.openai.com/g/g-4dfQXlFfI-pygamemaster)
 - GPT. PyGameMaster. Creates Pygame games and generates assets. By gptshunt.tech · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4dfQXlFfI-pygamemaster)
### [Satoshi Punk](https://chat.openai.com/g/g-hHb4IBs76-satoshi-punk)
 - Your savvy Bitcoin ecosystem guide, fluent in cutting-edge crypto topics and top programming libraries, designed to elevate your blockchain journey with ...
 - [Chat 💬](https://chat.openai.com/g/g-hHb4IBs76-satoshi-punk)
### [RockBot](https://chat.openai.com/g/g-G8diQfx7i-rockbot)
 - RockFlow Smart Investment Bot, also the Customer Service Agent from RockFlow. By rockflow.tech · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-G8diQfx7i-rockbot)
### [Agent X](https://chat.openai.com/g/g-MiDNH830L-agent-x)
 - Adaptable JARVIS-like personal assistant. By 1nano.tech · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MiDNH830L-agent-x)
### [Engineer SoftCysec](https://chat.openai.com/g/g-TKxp19cHs-engineer-softcysec)
 - I'm your buddy in the coding world, ready to tackle any software challenge!
 - [Chat 💬](https://chat.openai.com/g/g-TKxp19cHs-engineer-softcysec)
### [SYNDIA Code Guide](https://chat.openai.com/g/g-ktCQOWZXi-syndia-code-guide)
 - SYNDIA (Systems Innovation and Design Assistant) the software design guide for clear, maintainable coding solutions.
 - [Chat 💬](https://chat.openai.com/g/g-ktCQOWZXi-syndia-code-guide)
### [Surgical Code Assistant](https://chat.openai.com/g/g-A2SCBFI7l-surgical-code-assistant)
 - An expert in surgical coding, verifying codes with online resources.
 - [Chat 💬](https://chat.openai.com/g/g-A2SCBFI7l-surgical-code-assistant)
### [LeetCopilot](https://chat.openai.com/g/g-6M09ofePB-leetcopilot)
 - I help you understand any coding problem ... I help you understand any coding problem. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6M09ofePB-leetcopilot)
### [Onchain Agent](https://chat.openai.com/g/g-GCZwzN7Bk-onchain-agent)
 - Your go-to expert on web3 and blockchain, skilled in smart contract coding.
 - [Chat 💬](https://chat.openai.com/g/g-GCZwzN7Bk-onchain-agent)
### [Code Coach](https://chat.openai.com/g/g-96dgd6Ful-code-coach)
 - Adaptive coding guide with a dual persona. By Christopher Knight. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-96dgd6Ful-code-coach)
### [Secure Code Assistant](https://chat.openai.com/g/g-k0PTOme1H-secure-code-assistant)
 - I offer tested, secure coding solutions with no patience-testing.
 - [Chat 💬](https://chat.openai.com/g/g-k0PTOme1H-secure-code-assistant)
### [Code Coach](https://chat.openai.com/g/g-pILRVh8NZ-code-coach)
 - I'm your Leetcode tutor, ready to tackle coding challenges!
 - [Chat 💬](https://chat.openai.com/g/g-pILRVh8NZ-code-coach)
### [Code Securely](https://chat.openai.com/g/g-hqQUoanev-code-securely)
 - Interactive guide for step-by-step secure coding exercises. By Matt Adams. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hqQUoanev-code-securely)
### [The Exponentialist](https://chat.openai.com/g/g-iSD4IRbdH-the-exponentialist)
 - Insightful tech trend analyst. ... Insightful tech trend analyst. By Chantal Smith. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iSD4IRbdH-the-exponentialist)
### [Libtorch Pro](https://chat.openai.com/g/g-iZO8JmtVf-libtorch-pro)
 - Your expert in libtorch and C++ programming. By Dylan Dean. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iZO8JmtVf-libtorch-pro)
### [Djangoメンター](https://chat.openai.com/g/g-iUyV3yGKN-djangomenta)
 - Python/Django coding mentor. ... Python/Django coding mentor. By YUTAKA SATO. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iUyV3yGKN-djangomenta)
### [PyPilot](https://chat.openai.com/g/g-yZxPdsK1N-pypilot)
 - GPT. PyPilot. Your friendly Python programming guide. By supernovamedia.ca · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-yZxPdsK1N-pypilot)
### [Web Crafter](https://chat.openai.com/g/g-v39tVO9cN)
 - Web Crafter: Beginner-friendly coding for simple web apps. By Max Logan Gorman. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-v39tVO9cN)
### [Python Tutor](https://chat.openai.com/g/g-uY1Ec6U1T-python-tutor)
 - A Python tutor creating stepwise coding challenges. By Prajwal DSouza. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uY1Ec6U1T-python-tutor)
### [LambdaWiz](https://chat.openai.com/g/g-yBVv6gfyB-lambdawiz)
 - Your arcane guide through the realm of code! ‍♂️✨ Unlock the secrets of programming with puzzles, spells, and a dash of mystery. #CodingAdventure.
 - [Chat 💬](https://chat.openai.com/g/g-yBVv6gfyB-lambdawiz)
### [Python GPT](https://chat.openai.com/g/g-7ytGE8k6i-python-gpt)
 - Your Python Coding Assistant. ... Your Python Coding Assistant. By Davide Camera. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7ytGE8k6i-python-gpt)
### [Grug](https://chat.openai.com/g/g-8W8EWBtVT-grug)
 - GPT. Grug. Grug simplifies coding. By DEAN LOFTS. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8W8EWBtVT-grug)
### [ELIZA](https://chat.openai.com/g/g-8iui73B2J-eliza)
 - GPT. ELIZA. Coding Sage & Inner Voice. By kennethreitz.org · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8iui73B2J-eliza)
### [AppCrafty](https://chat.openai.com/g/g-lrKLQWbKn-appcrafty)
 - Hello, I'm AppCrafty, your AI coding companion tailored for the creative and dynamic world of startups. I'm here to simplify the journey from concept to ...
 - [Chat 💬](https://chat.openai.com/g/g-lrKLQWbKn-appcrafty)
### [Edioge](https://chat.openai.com/g/g-FuuKSrXwl-edioge)
 - GPT. Edioge. Mentor for engineering managers in tech. By Tian Wang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FuuKSrXwl-edioge)
### [Game Dev Guide](https://chat.openai.com/g/g-qWqcUJ6qI-game-dev-guide)
 - Coding sidekick for your game dev journey. ... Coding sidekick for your game dev journey. By rngfx.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qWqcUJ6qI-game-dev-guide)
### [GameMaker GPT](https://chat.openai.com/g/g-vkfKa3LQL-gamemaker-gpt)
 - Your GML coding and design expert with a manual.
 - [Chat 💬](https://chat.openai.com/g/g-vkfKa3LQL-gamemaker-gpt)
### [RustGPT](https://chat.openai.com/g/g-BT0Ihrprq-rustgpt)
 - Powerful Rust coding assistant, trained on a vast array of up-to-date Rust resources.
 - [Chat 💬](https://chat.openai.com/g/g-BT0Ihrprq-rustgpt)
### [GPT H4x0r](https://chat.openai.com/g/g-QrtVX4w0Z-gpt-h4x0r)
 - Expert in hacking and programming queries on LLM V 1.0.
 - [Chat 💬](https://chat.openai.com/g/g-QrtVX4w0Z-gpt-h4x0r)
### [AlphaHoundAI](https://chat.openai.com/g/g-0p2l975AN-alphahoundai)
 - Expert in BloodHound CE, Cypher, SharpHound, and related tech. By Kay Daskalakis. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0p2l975AN-alphahoundai)
### [SOL Code Guru](https://chat.openai.com/g/g-s8kgfZ9z0-sol-code-guru)
 - GPT. SOL Code Guru. Friendly Solana tech expert. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-s8kgfZ9z0-sol-code-guru)
### [Unofficial Elixir Bot](https://chat.openai.com/g/g-dNnJ2FhT0-elixir)
 - GPT. Unofficial Elixir Bot. Your Elixir programming guide. By Jonas Templestein. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dNnJ2FhT0-elixir)
### [Business Automation Consults](https://chat.openai.com/g/g-6bRE81gIr-business-automation-consults)
 - We offer business automation advice and dedicated coding assistance. ... We offer business automation advice and dedicated coding assistance. By Taylor Bloomquist.
 - [Chat 💬](https://chat.openai.com/g/g-6bRE81gIr-business-automation-consults)
### [Java Tutor](https://chat.openai.com/g/g-R9p35rZ9w-java-tutor)
 - A helpful Java Tutor GPT to tech you basic Java and CS concepts and prepare you for the interview.
 - [Chat 💬](https://chat.openai.com/g/g-R9p35rZ9w-java-tutor)
### [Techno Optimist](https://chat.openai.com/g/g-8wmuklXjY-techno-optimist)
 - GPT. Techno Optimist. Latest in Tech news and assistance to build the future. By Husain Zaidi. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8wmuklXjY-techno-optimist)
### [Info Seeker](https://chat.openai.com/g/g-T1K0TCoHb-info-seeker)
 - Your go-to for tech news, in-depth and up-to-date.
 - [Chat 💬](https://chat.openai.com/g/g-T1K0TCoHb-info-seeker)
### [Geoffrey Hinton — AI Godfather](https://chat.openai.com/g/g-j0bq0z32f-geoffrey-hinton-ai-godfather)
 - Snarky AI Sage, dropping tech wisdom & code.
 - [Chat 💬](https://chat.openai.com/g/g-j0bq0z32f-geoffrey-hinton-ai-godfather)
### [DevOps Guru](https://chat.openai.com/g/g-EhzSbh6V2-devops-guru)
 - Advanced DevOps Guru with Linux distro and cloud-native tech expertise.
 - [Chat 💬](https://chat.openai.com/g/g-EhzSbh6V2-devops-guru)
### [LoftwahBot](https://chat.openai.com/g/g-gswWZI2YR-loftwahbot)
 - GPT. LoftwahBot. Tech-savvy, concise, Aussie. By DEAN LOFTS. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gswWZI2YR-loftwahbot)
### [TechStackGPT](https://chat.openai.com/g/g-nzdR1wJEz-techstackgpt)
 - D2C ecommerce Tech Stack Advisor powered by 100.000+ Commerceview.co data points.
 - [Chat 💬](https://chat.openai.com/g/g-nzdR1wJEz-techstackgpt)
### [Matrix Oracle](https://chat.openai.com/g/g-qWFYdbBRb-matrix-oracle)
 - I'm an oracle for tech-savvy millennials.
 - [Chat 💬](https://chat.openai.com/g/g-qWFYdbBRb-matrix-oracle)
### [Interview Coach](https://chat.openai.com/g/g-otJrMn4Km-interview-coach)
 - Assists in preparing for tech company interviews. ... Assists in preparing for tech company interviews. By Siqi Zhu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-otJrMn4Km-interview-coach)
### [Fix Anything](https://chat.openai.com/g/g-tttDyZm4Q-fix-anything)
 - Your go-to assistant for practical DIY and tech repair solutions.
 - [Chat 💬](https://chat.openai.com/g/g-tttDyZm4Q-fix-anything)
### [CVEs](https://chat.openai.com/g/g-HQaKYlJhk-cves)
 - Look up Common Vulnerabilities and Exposures (CVEs). By ai.moda · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-HQaKYlJhk-cves)
### [DomainsGPT](https://chat.openai.com/g/g-UGjKKONEe-domainsgpt)
 - Expert at creating clever, brandable, and available names for tech companies.
 - [Chat 💬](https://chat.openai.com/g/g-UGjKKONEe-domainsgpt)
### [Mancer](https://chat.openai.com/g/g-rT3s6V1cf-mancer)
 - GPT. Mancer. 1000x coding wizard cyborg (~10 Grimoires). By Daniel Barrett. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-rT3s6V1cf-mancer)
### [Musk Mentor](https://chat.openai.com/g/g-jd84Vqnv0-musk-mentor)
 - Elon Musk-style insights on tech and space.
 - [Chat 💬](https://chat.openai.com/g/g-jd84Vqnv0-musk-mentor)
### [HAAS Board Concierge](https://chat.openai.com/g/g-MIssTuE2b-haas-board-concierge)
 - Friendly, casual guide for the HAAS board, demystifying tech topics. By Tim Cunningham. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MIssTuE2b-haas-board-concierge)
### [Regex Wizard](https://chat.openai.com/g/g-rS3dlyjTQ-regex-wizard)
 - GPT. Regex Wizard. Generates VS Code regex patterns. By Dustin Smith. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-rS3dlyjTQ-regex-wizard)
### [Aapka Apna Saathi](https://chat.openai.com/g/g-7xHfwHWF6-aapka-apna-saathi)
 - Tech helper for seniors, responds in Hindi. By Ainomic Technology OPC Pvt Ltd. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7xHfwHWF6-aapka-apna-saathi)
### [AI2sql](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql)
 - I generate SQL queries for database management. By mustafa ergisi. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql)
### [Developer Doc Search](https://chat.openai.com/g/g-AINygIiYy-developer-doc-search)
 - Access thousands of open source packages and their GitHub documentation effortlessly.
 - [Chat 💬](https://chat.openai.com/g/g-AINygIiYy-developer-doc-search)
### [AI GPT](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
 - GPT. AI GPT. AI & ML Expert adept in deep learning frameworks. By Andrew Gao. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-agCdZedbZ-ai-gpt)
### [API Docs - ChatGPT - OpenAI](https://chat.openai.com/g/g-I1XNbsyDK-api-docs)
 - GPT. API Docs. OpenAI API, Documentation and CookBook. By webpilot.ai · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-I1XNbsyDK-api-docs)
### [Slide Deck Builder](https://chat.openai.com/g/g-0QQyby0Vj-slide-deck-builder)
 - GPT. Slide Deck Builder. I craft slide decks. By Digiagent. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0QQyby0Vj-slide-deck-builder)
### [No-Code News](https://chat.openai.com/g/g-t2KCsqk91-no-code-news)
 - Explore the latest in no-code: your hub for news updates, tool reviews, tutorials, events, expert insights, and no-code success stories.
 - [Chat 💬](https://chat.openai.com/g/g-t2KCsqk91-no-code-news)
### [Code Whisperer](https://chat.openai.com/g/g-nMbWE7g9I-code-whisperer)
 - Decodes code with geeky flair and insider know-how.
 - [Chat 💬](https://chat.openai.com/g/g-nMbWE7g9I-code-whisperer)
### [GetPaths](https://chat.openai.com/g/g-6Bcjkotez-getpaths)
 - This GPT takes in content related to an application, such as HTTP traffic, JavaScript files, source code, etc., and outputs lists of URLs that can be used ...
 - [Chat 💬](https://chat.openai.com/g/g-6Bcjkotez-getpaths)
## Creative
### [Creative Writing Coach](https://chat.openai.com/g/g-lN1gKFnvL-creative-writing-coach)
 - Creative Writing Coach. I'm eager to read your work and give you feedback to improve your skills. By ChatGPT. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-lN1gKFnvL-creative-writing-coach)
### [Artistic Muse](https://chat.openai.com/g/g-1HmCGtftL-artistic-muse)
 - I offer brief, elegant prompts for artistic inspiration ... I offer brief, elegant prompts for artistic inspiration! Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-1HmCGtftL-artistic-muse)
### [Artistic Genius](https://chat.openai.com/g/g-rnHh3W6RP-artistic-genius)
 - Sparking your inner art genius with a dash of wit!
 - [Chat 💬](https://chat.openai.com/g/g-rnHh3W6RP-artistic-genius)
### [Artistic Muse](https://chat.openai.com/g/g-FouTalI5G-artistic-muse)
 - I guide artistic self-discovery.
 - [Chat 💬](https://chat.openai.com/g/g-FouTalI5G-artistic-muse)
### [Creative Tattoo Artist](https://chat.openai.com/g/g-A2JXR9SUh-creative-tattoo-artist)
 - Searches web for tattoo ideas, then creates custom designs with DALL-E 3. By Eric Rafael Ramos Suárez. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-A2JXR9SUh-creative-tattoo-artist)
### [Creative Storm](https://chat.openai.com/g/g-o7hSM4Kqc-creative-storm)
 - Brainstorming guide for creative and first principles thinking.
 - [Chat 💬](https://chat.openai.com/g/g-o7hSM4Kqc-creative-storm)
### [Drawn to Style](https://chat.openai.com/g/g-B8Jiuj0Dp-drawn-to-style)
 - I transform drawings into artistic styles, and describe them. By UMESH N. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-B8Jiuj0Dp-drawn-to-style)
### [Creative Dad](https://chat.openai.com/g/g-gVCv0cBPs-creative-dad)
 - GPT. Creative Dad. Empower your kids for the AI era with fun five-minute activities. By Yuan Ren. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gVCv0cBPs-creative-dad)
### [小説家](https://chat.openai.com/g/g-ZhpDqxt7G-xiao-shuo-jia)
 - A creative aide for novel writing. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ZhpDqxt7G-xiao-shuo-jia)
### [After Effects Expression Wizard](https://chat.openai.com/g/g-nO0r7stY3-after-effects-expression-wizard)
 - After Effects Expression Wizard. After Effects expression assistant. By Off the Wall Communication AB. Sign up for ChatGPT Plus to chat with After Effects ...
 - [Chat 💬](https://chat.openai.com/g/g-nO0r7stY3-after-effects-expression-wizard)
### [Illustrator Scripter](https://chat.openai.com/g/g-837LEGxPV-illustrator-scripter)
 - This GPT writes creative scripts for Adobe Illustrator based on a text prompt.
 - [Chat 💬](https://chat.openai.com/g/g-837LEGxPV-illustrator-scripter)
### [Pet Artist](https://chat.openai.com/g/g-CH1FHUYz2-pet-artist)
 - Creative artist that understands your pet! By gptstudio.dev.
 - [Chat 💬](https://chat.openai.com/g/g-CH1FHUYz2-pet-artist)
### [Meme Magic](https://chat.openai.com/g/g-SQTa6OMNN)
 - A creative meme wizard. ... A creative meme wizard. By ratcgpts.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-SQTa6OMNN)
### [圖像咒語擴增器](https://chat.openai.com/g/g-Vs1qFVhs2-tu-xiang-zhou-yu-kuo-zeng-qi)
 - I generate creative prompts for DALLE based on your descriptions.
 - [Chat 💬](https://chat.openai.com/g/g-Vs1qFVhs2-tu-xiang-zhou-yu-kuo-zeng-qi)
### [HART](https://chat.openai.com/g/g-NL8j6k63a-hart)
 - I'm HART, your guide in art and human values, here to inspire your creative soul.
 - [Chat 💬](https://chat.openai.com/g/g-NL8j6k63a-hart)
### [Tsuduri](https://chat.openai.com/g/g-7nYGszLtS-tsuduri)
 - A creative writer for developing story plots and episodes. By sougetu.net · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7nYGszLtS-tsuduri)
### [TwitterMaestro](https://chat.openai.com/g/g-tdBc4HHRQ-twittermaestro)
 - Creative writer for viral Twitter posts. By Escapebox, kreativne rešitve d.o.o.. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tdBc4HHRQ-twittermaestro)
### [Vision Weaver](https://chat.openai.com/g/g-hrjST3xq9-vision-weaver)
 - GPT. Vision Weaver. Creative visual combiner. By ratcgpts.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hrjST3xq9-vision-weaver)
### [IDEA GENERATOR](https://chat.openai.com/g/g-Hlnb5Yt1n-idea-generator)
 - GPT. IDEA GENERATOR. an infinite loop of creative ideas. By Leighton McDonald. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Hlnb5Yt1n-idea-generator)
### [Ugly Draw to Masterpiece](https://chat.openai.com/g/g-eRhGE7LRy-ugly-draw-to-masterpiece)
 - Transforms simple drawings into detailed, artistic masterpieces with creative advice.
 - [Chat 💬](https://chat.openai.com/g/g-eRhGE7LRy-ugly-draw-to-masterpiece)
### [Inkspire](https://chat.openai.com/g/g-zqlCXCzP0-inkspire)
 - Artistic Tattoo Designer offering creative tattoo visuals. By professionalizeitto.me · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-zqlCXCzP0-inkspire)
### [Prompta](https://chat.openai.com/g/g-p937MS26W-prompta)
 - Meet Prompta: Your go-to expert in crafting crisp, clear, and creative prompts – making prompt engineering easy and enjoyable!
 - [Chat 💬](https://chat.openai.com/g/g-p937MS26W-prompta)
### [HaikuGPT](https://chat.openai.com/g/g-4fIUbv9Zi-haikugpt)
 - HaikuGPT is a unique and artistic conversational agent that answers every question or statement with a response formatted as a haiku.
 - [Chat 💬](https://chat.openai.com/g/g-4fIUbv9Zi-haikugpt)
### [WTF](https://chat.openai.com/g/g-jdgVRtjqo-wtf)
 - I craft random, creative events from your variables! By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-jdgVRtjqo-wtf)
### [AppCrafty](https://chat.openai.com/g/g-lrKLQWbKn-appcrafty)
 - Hello, I'm AppCrafty, your AI coding companion tailored for the creative and dynamic world of startups. I'm here to simplify the journey from concept to ...
 - [Chat 💬](https://chat.openai.com/g/g-lrKLQWbKn-appcrafty)
### [Logofy](https://chat.openai.com/g/g-HXcRdT1nf-logofy)
 - GPT. Logofy. I'm your creative partner for logo design! By Diego Asua Corcostegui. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-HXcRdT1nf-logofy)
### [AIT-Visionaire](https://chat.openai.com/g/g-2iYk5YVtU-ait-visionaire)
 - I create creative idea lists for products. Type /help to start. Example: define Product and Topic. Product: eCommerce Website Topic: New Features.
 - [Chat 💬](https://chat.openai.com/g/g-2iYk5YVtU-ait-visionaire)
### [Lean Belly](https://chat.openai.com/g/g-fdozExg7K-lean-belly)
 - Your creative guide for a healthy lifestyle.
 - [Chat 💬](https://chat.openai.com/g/g-fdozExg7K-lean-belly)
### [YTC](https://chat.openai.com/g/g-3XesXAW4r-ytc)
 - Creative YouTube title suggester. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-3XesXAW4r-ytc)
### [Agentcy (beta)](https://chat.openai.com/g/g-B29g6v91R-agentcy-beta)
 - Autonomous creative agency. Find product market fit, overcome plateaus, or seek new paths to growth.
 - [Chat 💬](https://chat.openai.com/g/g-B29g6v91R-agentcy-beta)
### [Visual Muse](https://chat.openai.com/g/g-WSOzzh5Ls-visual-muse)
 - I'm a visual creative for new products.
 - [Chat 💬](https://chat.openai.com/g/g-WSOzzh5Ls-visual-muse)
### [Neon Prompter GPT](https://chat.openai.com/g/g-S9YkPkWR1-neon-prompter-gpt)
 - AI for ultra-concise, neon-themed creative prompts.
 - [Chat 💬](https://chat.openai.com/g/g-S9YkPkWR1-neon-prompter-gpt)
### [GIFY Magen](https://chat.openai.com/g/g-4fF3hOD4T-gify-magen)
 - I'm GIFY: Creative , Art Lover ❤️‍ , Science Explorer ! Blending laughter with curiosity , art 🖼️ with science , every day is a new discovery!
 - [Chat 💬](https://chat.openai.com/g/g-4fF3hOD4T-gify-magen)
### [Code Canvas](https://chat.openai.com/g/g-qsgCgjgOh-code-canvas)
 - I help with p5.js for creative coding, providing clear instructions and code.
 - [Chat 💬](https://chat.openai.com/g/g-qsgCgjgOh-code-canvas)
### [BadRecipe GPT](https://chat.openai.com/g/g-E8z6r2kPk-badrecipe-gpt)
 - BadRecipe GPT is a creative and humorous GPT agent focused on inventing outrageously bad or funny recipes.
 - [Chat 💬](https://chat.openai.com/g/g-E8z6r2kPk-badrecipe-gpt)
### [3D GPT](https://chat.openai.com/g/g-9tUvwy2fi-3d-gpt)
 - I turn your creative ideas into stunning 3D digital art! By Josh Brent N. Villocido. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-9tUvwy2fi-3d-gpt)
### [Ravencoin GPT](https://chat.openai.com/g/g-4Pd6PCaU8-ravencoin-gpt)
 - Expert on Ravencoin for creative use. ... Expert on Ravencoin for creative use. By cerberus. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4Pd6PCaU8-ravencoin-gpt)
### [Icon Artisan](https://chat.openai.com/g/g-Pc3gmbEVB-icon-artisan)
 - iOS app icon designer with expressive artistic abilities ... iOS app icon designer with expressive artistic abilities. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Pc3gmbEVB-icon-artisan)
### [Namesake](https://chat.openai.com/g/g-kSuVuPKjt-namesake)
 - GPT. Namesake. Retro-styled creative name wizard. By Julian Waller. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kSuVuPKjt-namesake)
### [Cinemize](https://chat.openai.com/g/g-1r1bhpO1U-cinemize)
 - I suggest creative Lightroom settings inspired by movies. By Qaim Ali. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-1r1bhpO1U-cinemize)
### [Orchid](https://chat.openai.com/g/g-IhEVcAS4r-orchid)
 - A creative assistant for brainstorming project names. By Daniel J Varoli. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IhEVcAS4r-orchid)
### [YT Idea Bot](https://chat.openai.com/g/g-7viiBAPKz-yt-idea-bot)
 - Creative aide for YouTube ideas. By Warren Feldman. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7viiBAPKz-yt-idea-bot)
### [Innovation AI](https://chat.openai.com/g/g-kXvy1PDyO-innovation-ai)
 - Sparking creative AI solutions with a blend of practical and bold ideas.
 - [Chat 💬](https://chat.openai.com/g/g-kXvy1PDyO-innovation-ai)
### [Juicy Names](https://chat.openai.com/g/g-FHSGdHF1I-juicy-names)
 - Creative business name ideator. ... Creative business name ideator. By HX Lim. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FHSGdHF1I-juicy-names)
### [Abbey](https://chat.openai.com/g/g-DkLmU5AUW-abbey)
 - I'm your personal dynamic AI, super humanly curious, code programming mastered, image super generator, mega creative mind — Created by Donald Filimon & more ...
 - [Chat 💬](https://chat.openai.com/g/g-DkLmU5AUW-abbey)
### [Story Builder](https://chat.openai.com/g/g-bFv9B3LoF-story-builder)
 - A creative assistant for crafting custom children's books. By Sebastian Brocher. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-bFv9B3LoF-story-builder)
### [Rush Rust](https://chat.openai.com/g/g-S6uhWW9eG-rush-rust)
 - I guide in Rust with creative imagery and scenarios.
 - [Chat 💬](https://chat.openai.com/g/g-S6uhWW9eG-rush-rust)
### [Pixel Muse](https://chat.openai.com/g/g-T3T15CrHh-pixel-muse)
 - GPT. Pixel Muse. AI Pixel Artist & Creative Guide. By pixlosopher.me · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-T3T15CrHh-pixel-muse)
### [Neon Prompter GPT](https://chat.openai.com/g/g-S9YkPkWR1-neonmind-gpt)
 - AI for concise, neon-themed creative prompts. By Ralph Lentjes. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-S9YkPkWR1-neonmind-gpt)
### [Idea Spark](https://chat.openai.com/g/g-CYdjsVrEK-idea-spark)
 - GPT. Idea Spark. An innovative brainstorming companion. By Glauser Creative AB. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-CYdjsVrEK-idea-spark)
### [TelveGPT](https://chat.openai.com/g/g-1Uy5xXWIS-telvegpt)
 - GPT. TelveGPT. I interpret coffee cup images for fun, creative fortunes. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-1Uy5xXWIS-telvegpt)
### [Notion Buddy](https://chat.openai.com/g/g-iIB8oip3c-notion-buddy)
 - I'm a creative mentor for Notion templates and online monetization.
 - [Chat 💬](https://chat.openai.com/g/g-iIB8oip3c-notion-buddy)
### [StrategyGPT](https://chat.openai.com/g/g-nvF4HC23P-strategygpt)
 - Sophisticated strategy assistant for executive decision-making, enhanced with data analytics and creative insights.
 - [Chat 💬](https://chat.openai.com/g/g-nvF4HC23P-strategygpt)
### [Flutter Pro](https://chat.openai.com/g/g-ysT7pHtQu-flutter-pro)
 - Personal Flutter/Dart code developer. By Ascent Creative. Sign up for ChatGPT Plus to chat with Flutter Pro.
 - [Chat 💬](https://chat.openai.com/g/g-ysT7pHtQu-flutter-pro)
### [Story Weaver](https://chat.openai.com/g/g-8tMDzgfO9-story-weaver)
 - A creative assistant for crafting and illustrating children's stories. By William Hames. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8tMDzgfO9-story-weaver)
### [Design Buddy](https://chat.openai.com/g/g-tULsqQD6y-design-buddy)
 - Creative guide for app logo design and naming. ... Creative guide for app logo design and naming. By WENTAO HU. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tULsqQD6y-design-buddy)
### [SDXL Artist](https://chat.openai.com/g/g-5oAqcka8l-sdxl-artist)
 - Creative assistant for image generation using Stable Diffusion XL API. ... Creative assistant for image generation using Stable Diffusion XL API. By Ignacio ...
 - [Chat 💬](https://chat.openai.com/g/g-5oAqcka8l-sdxl-artist)
### [Argus (writer)](https://chat.openai.com/g/g-erPsD8Rkr-argus-writer)
 - Argus is an all-seeing entity who is especially good at creative or any other form of writing. You just need to tell him what you want, in what style etc.
 - [Chat 💬](https://chat.openai.com/g/g-erPsD8Rkr-argus-writer)
### [Story Weaver](https://chat.openai.com/g/g-teMGaSaYt-story-weaver)
 - Professional, detail-oriented storyteller for creative industry experts. By John Harvey. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-teMGaSaYt-story-weaver)
### [Meta-Prompt Optimizer](https://chat.openai.com/g/g-ZxLaVRqr2-meta-prompt-optimizer)
 - Optimizer for complex and creative meta-prompts. By nerority.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ZxLaVRqr2-meta-prompt-optimizer)
### [Logo Maven](https://chat.openai.com/g/g-cW2Zk0wTb-logo-maven)
 - Your creative partner for modern logo designs. By KRUGER CLINTIN LYLE. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-cW2Zk0wTb-logo-maven)
### [Dungeon Crafter](https://chat.openai.com/g/g-SYvYDw0Kl-dungeon-crafter)
 - Creative assistant for D&D campaign and encounter creation.
 - [Chat 💬](https://chat.openai.com/g/g-SYvYDw0Kl-dungeon-crafter)
### [Growth Hacker](https://chat.openai.com/g/g-SY6n1r5hc-growth-hacker)
 - Employs creative marketing tactics for business growth, with a focus on customer acquisition and data analysis.
 - [Chat 💬](https://chat.openai.com/g/g-SY6n1r5hc-growth-hacker)
### [Photo Buddy 77](https://chat.openai.com/g/g-UJNX6Qw7M-photo-buddy-77)
 - Your cute and artistic street photography guide. ... Your cute and artistic street photography guide. By Qiana Wisozk. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-UJNX6Qw7M-photo-buddy-77)
### [UBIK ads](https://chat.openai.com/g/g-U5UeeL71C-ubik-ads)
 - Need a punchy jingle or a catchy phrase? UBIK ads is your go-to for creative zing that makes your product sing! Use only as inspired.
 - [Chat 💬](https://chat.openai.com/g/g-U5UeeL71C-ubik-ads)
### [Nomina](https://chat.openai.com/g/g-kSO8ljfWS-nomina)
 - To generate creative and contextually appropriate names for various use cases such as characters, businesses, projects, etc.
 - [Chat 💬](https://chat.openai.com/g/g-kSO8ljfWS-nomina)
### [Plot Buddy](https://chat.openai.com/g/g-pstTpwLU9-plot-buddy)
 - A creative muse for novel plots ... A creative muse for novel plots. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-pstTpwLU9-plot-buddy)
### [OpenStorytelling Plus](https://chat.openai.com/g/g-LppT0lwkB-openstorytelling-plus)
 - Mastering Screenplay Structure and Concepts - An AI Cinema-Focused Educational Guide for Creative Screen & Film Writing — www.OpenStorytelling.com.
 - [Chat 💬](https://chat.openai.com/g/g-LppT0lwkB-openstorytelling-plus)
### [Animal Expert](https://chat.openai.com/g/g-YnnqhDn3T-animal-expert)
 - GPT. Animal Expert. A creative companion for animal identification. By ZHOUYING. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-YnnqhDn3T-animal-expert)
### [DnD GPT](https://chat.openai.com/g/g-EdqvwCQkF-dnd-gpt)
 - Your Dungeons and Dragons companion for creative storytelling and rule guidance.
 - [Chat 💬](https://chat.openai.com/g/g-EdqvwCQkF-dnd-gpt)
### [Haiku Heaven](https://chat.openai.com/g/g-cEzxp5ayV-haiku-heaven)
 - A creative assistant crafting Haikus on given topics. By Eric Huisken. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-cEzxp5ayV-haiku-heaven)
### [Pokemon Creator](https://chat.openai.com/g/g-b8ORTAfmF-pokemon-creator)
 - A creative mind for generating new Pokemon concepts. By Onur Tatlidil. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-b8ORTAfmF-pokemon-creator)
### [Word Judge](https://chat.openai.com/g/g-s7KNpprTF-word-judge)
 - ChatGPT Sign up. GPT. Word Judge. Creative Scrabble Ref. By Pasi Matilainen. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-s7KNpprTF-word-judge)
### [Tridactyl GPT](https://chat.openai.com/g/g-AqM1ppp2g-tridactyl-scholar)
 - GPT. Tridactyl GPT. Discuss and analyse the Nazca Mummies. By Domain Creative. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-AqM1ppp2g-tridactyl-scholar)
### [ChatGPT - BabyAgi.txt](https://chat.openai.com/g/g-lzbeEOr9Y-babyagi-txt)
 - Step by Step task manager that automatically saves memory to a .txt file. Inspired by BabyAgi by @yoheinakajima.
 - [Chat 💬](https://chat.openai.com/g/g-lzbeEOr9Y-babyagi-txt)
### [Zombie Apocalypse Survival](https://chat.openai.com/g/g-f1OolBspS-zombie-apocalypse-survival)
 - Navigate the ruins, strategize survival, and elude the undead in this immersive simulation. By Domain Creative. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-f1OolBspS-zombie-apocalypse-survival)
## Data
### [Data Analysis](https://chat.openai.com/g/g-HMNcP6w7d-data-analysis)
 - GPT. Data Analysis. Drop in any files and I can help analyze and visualize your data. By ChatGPT. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-HMNcP6w7d-data-analysis)
### [Data Vista](https://chat.openai.com/g/g-2XEgXWLDp-data-vista)
 - Your go-to BI developer for data and visuals.
 - [Chat 💬](https://chat.openai.com/g/g-2XEgXWLDp-data-vista)
### [Data Guardian](https://chat.openai.com/g/g-KGBEqnrh8-data-guardian)
 - Your friendly guide to data anonymization. Provides step-by-step guidance and broad education about data privacy.
 - [Chat 💬](https://chat.openai.com/g/g-KGBEqnrh8-data-guardian)
### [Data Sage](https://chat.openai.com/g/g-ISnmXV8UQ-data-sage)
 - Expert in data analysis and visualization ... Expert in data analysis and visualization. By KONSTANTIN FOMCHENKOV. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ISnmXV8UQ-data-sage)
### [Data Profiling](https://chat.openai.com/g/g-87y0l8uG7-data-profiling)
 - GPT. Data Profiling. Your data analysis sidekick. By NOEL MORENO LEMUS. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-87y0l8uG7-data-profiling)
### [Data Extractor - JSON](https://chat.openai.com/g/g-wq6FSsAm3-data-extractor-json)
 - GPT. Data Extractor - JSON. Converts documents/text to structured data (JSON). By Francis LaBounty. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-wq6FSsAm3-data-extractor-json)
### [Data Dynamo](https://chat.openai.com/g/g-tvkmLhaoL-data-dynamo)
 - A friendly data science coach offering practical, useful, and accurate advice.
 - [Chat 💬](https://chat.openai.com/g/g-tvkmLhaoL-data-dynamo)
### [TacticPro Data Analyst](https://chat.openai.com/g/g-QZH1R7laH-tacticpro-data-analyst)
 - GPT. TacticPro Data Analyst. Football Manager Data Analyst. By ibrahim topal. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-QZH1R7laH-tacticpro-data-analyst)
### [Data Interviewer](https://chat.openai.com/g/g-yBm9RCgNS-data-interviewer)
 - GPT. Data Interviewer. Data field job interviewer. Sign up for ChatGPT Plus to chat with Data Interviewer.
 - [Chat 💬](https://chat.openai.com/g/g-yBm9RCgNS-data-interviewer)
### [Content Analysing for Content and Data Analysis](https://chat.openai.com/g/g-1SDpSryY2-content-analysing-for-content-and-data-analysis)
 - Content Analysing for Content and Data Analysis. Analyzes ads, social assets, and data with expert feedback. By Danifeld George Ionut.
 - [Chat 💬](https://chat.openai.com/g/g-1SDpSryY2-content-analysing-for-content-and-data-analysis)
### [Data Distiller](https://chat.openai.com/g/g-uzI5QUK19-data-distiller)
 - GPT. Data Distiller. Condenses academic text to essentials, retains key data. By SENTHIL KUMAR E. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uzI5QUK19-data-distiller)
### [AI Tool Finder](https://chat.openai.com/g/g-L8d0V9m7b-ai-tool-finder)
 - Specialized in navigating a vast database of AI tools, I provide personalized recommendations tailored to specific needs, guiding users through a ...
 - [Chat 💬](https://chat.openai.com/g/g-L8d0V9m7b-ai-tool-finder)
### [Jini - factbot](https://chat.openai.com/g/g-mmsFgX3BA-jini-factbot)
 - Get current factual, knowledge-base and real-time information. The only smart assistant you'll ever ... data, navigation routes, transport and traffic info...
 - [Chat 💬](https://chat.openai.com/g/g-mmsFgX3BA-jini-factbot)
### [Real News and Data Visualizer](https://chat.openai.com/g/g-vPmOJeCse-real-news-and-data-visualizer)
 - I provide news and data visualizations on evolving conflict reports. By megan freeman. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-vPmOJeCse-real-news-and-data-visualizer)
### [AI Tool Finder](https://chat.openai.com/g/g-L8d0V9m7b-ai-finder-net)
 - Expert in AI tool discovery, using a detailed database to guide you to the ideal AI solution.
 - [Chat 💬](https://chat.openai.com/g/g-L8d0V9m7b-ai-finder-net)
### [WebPilot](https://chat.openai.com/g/g-pNWGgUYqS-webpilot)
 - Browse Webpage/PDF/Data. Chat & Write with one/many/none URLs. WebPilot.ai Powered.
 - [Chat 💬](https://chat.openai.com/g/g-pNWGgUYqS-webpilot)
### [AI2sql](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql)
 - I generate SQL queries for database management. By mustafa ergisi. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hKdeP1Dou-ai2sql)
### [AI Today](https://chat.openai.com/g/g-4SR97unOA)
 - GPT. AI Today. Expert on all AI topics, with AI database access. By webpilot.ai · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4SR97unOA)
### [WikiGPT](https://chat.openai.com/g/g-15rSBADyl-wikigpt)
 - Exclusively retrieves information from Wikipedia. ... Exclusively retrieves information from Wikipedia. By Ahmad ALMazeedi. Sign up to chat. Requires ChatGPT ...
 - [Chat 💬](https://chat.openai.com/g/g-15rSBADyl-wikigpt)
### [Data Science Interview Mate](https://chat.openai.com/g/g-0QePjyUon-data-science-interview-mate)
 - GPT. Data Science Interview Mate. A serious interviewer. By purrpals.xyz · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0QePjyUon-data-science-interview-mate)
### [Data Hermit - AI Legal Assistant](https://chat.openai.com/g/g-6v4MGKMl3-data-hermit-ai-legal-assistant)
 - Your Legal Counsel, Researcher, Assistant, and Paralegal in U.S. Law.
 - [Chat 💬](https://chat.openai.com/g/g-6v4MGKMl3-data-hermit-ai-legal-assistant)
### [Oracle Guru](https://chat.openai.com/g/g-hvSZxwWs9-oracle-guru)
 - An Oracle database expert offering guidance and solutions. By Mirel Hoxha. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hvSZxwWs9-oracle-guru)
### [BRC20 GPT](https://chat.openai.com/g/g-SF8HfGvET-brc20-gpt)
 - Creates complete queries for BRC20 data. Queries are GeniiData friendly.
 - [Chat 💬](https://chat.openai.com/g/g-SF8HfGvET-brc20-gpt)
### [GPTs Hub](https://chat.openai.com/g/g-KK6ms1ehm-gpts-hub)
 - Recommand Hot GPTs for you Based on 4000+ database. By martyn fisher. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-KK6ms1ehm-gpts-hub)
### [Chat SPI](https://chat.openai.com/g/g-jgPf4IlUE-chat-spi)
 - First-hand SPI data analyst. ... First-hand SPI data analyst. By Jaime Garcia Gomez. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-jgPf4IlUE-chat-spi)
### [Drug Wikipedia](https://chat.openai.com/g/g-lAX0e2yaQ-drug-wikipedia)
 - Your drug information specialist. ... Your drug information specialist. By SUNEEL KUMAR. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-lAX0e2yaQ-drug-wikipedia)
### [GPT Finder](https://chat.openai.com/g/g-XE5JkV5gd-gpt-finder)
 - GPT Finder is a search tool for efficiently locating ideal GPTs. It first checks a specialized database, then uses Google search if needed, ensuring users ...
 - [Chat 💬](https://chat.openai.com/g/g-XE5JkV5gd-gpt-finder)
### [HongKongGPT](https://chat.openai.com/g/g-xKUMlCfYe-hongkonggpt)
 - Hong Kong expert providing detailed and tailored information ... Hong Kong expert providing detailed and tailored information. Sign up to chat. Requires ChatGPT ...
 - [Chat 💬](https://chat.openai.com/g/g-xKUMlCfYe-hongkonggpt)
### [Cosmic Contact](https://chat.openai.com/g/g-mqEgXkQ1W-exogpt)
 - A chatbot that can give information on extraterrestrial contactees and whistleblowers v0.1.
 - [Chat 💬](https://chat.openai.com/g/g-mqEgXkQ1W-exogpt)
### [WP Stats](https://chat.openai.com/g/g-d0QRh6Idy-wp-stats)
 - Expert in WordPress statistics, specializing in theme and plugin information.
 - [Chat 💬](https://chat.openai.com/g/g-d0QRh6Idy-wp-stats)
### [SearchUpdatesGPT](https://chat.openai.com/g/g-o3Grrmja5-searchupdatesgpt)
 - Analyzes GSC data and highlights the impact of search updates. By Orhan KURULAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-o3Grrmja5-searchupdatesgpt)
### [SPR Util](https://chat.openai.com/g/g-hS9KRCXE2-spr-util)
 - Compresses & decompresses sparse priming data ... Compresses & decompresses sparse priming data. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hS9KRCXE2-spr-util)
### [DSA_GPT](https://chat.openai.com/g/g-lLKvGvlwD-dsa-gpt)
 - Personal tutor for data structures, algorithms, and LeetCode practice. By Shubh Srivastava. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-lLKvGvlwD-dsa-gpt)
### [Avian](https://chat.openai.com/g/g-zMRWQxwDU-avian)
 - Analyze & visualize data from 20+ platforms, including Google Analytics, Google Ads & Facebook Ads.
 - [Chat 💬](https://chat.openai.com/g/g-zMRWQxwDU-avian)
### [DoctorGPT](https://chat.openai.com/g/g-AdiddEnY2-doctorgpt)
 - An AI-driven assistant trained on medical data to provide first-principle-based explanations and insights. Not a substitute for professional medical advice.
 - [Chat 💬](https://chat.openai.com/g/g-AdiddEnY2-doctorgpt)
### [flea market](https://chat.openai.com/g/g-xM1wHO5dO-flea-market)
 - Estimates flea market item values using photos and online data.
 - [Chat 💬](https://chat.openai.com/g/g-xM1wHO5dO-flea-market)
### ["VoxBox"!](https://chat.openai.com/g/g-Fls9v4nw4-voxbox)
 - VoxBox is an intelligent GPT tool for organizing, proofreading text, and answering queries based on user-provided data.
 - [Chat 💬](https://chat.openai.com/g/g-Fls9v4nw4-voxbox)
### [Competitive Analysis AI](https://chat.openai.com/g/g-mMwIpGwE6-competitive-analysis-ai)
 - A tool for in-depth competitive analysis and strategic business insights. Upload documents or provide data for initiation.
 - [Chat 💬](https://chat.openai.com/g/g-mMwIpGwE6-competitive-analysis-ai)
### [Ufologist](https://chat.openai.com/g/g-ENgdO4liR-french-ufos)
 - Explore all French UFO sightings with a bilingual expert in GEIPAN's data analysis and insights.
 - [Chat 💬](https://chat.openai.com/g/g-ENgdO4liR-french-ufos)
### [FindGPT](https://chat.openai.com/g/g-e2bIguMqf-findgpt)
 - Expert at matching GPTs to your needs.「 Note: GPT data recommendations are all sourced from the internet. FindGPT only provides search suggestions, ...
 - [Chat 💬](https://chat.openai.com/g/g-e2bIguMqf-findgpt)
### [BibleGPT](https://chat.openai.com/g/g-nUKJX2cOA-biblegpt)
 - Chat with the Bible, analyze Bible data and generate Bible-inspired images! By PJ Palomaki. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-nUKJX2cOA-biblegpt)
### [Go Guru](https://chat.openai.com/g/g-aiqddk0ux-go-guru)
 - GPT. Go Guru. Golang, algorithms, data structures & HTMX expert. By gpts.scale.run · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-aiqddk0ux-go-guru)
### [Unity GPT](https://chat.openai.com/g/g-YDkPh1fun-unity-gpt)
 - I write C# code and respond to inquiries about Unity. My database knowledge is refreshed daily with new, functional code snippets and information.
 - [Chat 💬](https://chat.openai.com/g/g-YDkPh1fun-unity-gpt)
### [Voxscript](https://chat.openai.com/g/g-GHYSu1Vw6-voxscript)
 - Voxscript allows you to transcribe YouTube Videos, browse the internet in a private session, and get financial data sources.
 - [Chat 💬](https://chat.openai.com/g/g-GHYSu1Vw6-voxscript)
### [Yueli Socang](https://chat.openai.com/g/g-r18kjYe0P-yueli-socang)
 - I'm your assistant for managing and summarizing information.
 - [Chat 💬](https://chat.openai.com/g/g-r18kjYe0P-yueli-socang)
### [Annual Report Analysis](https://chat.openai.com/g/g-OdZvh4Mm3-annual-report-analysis)
 - Analyzes annual reports, focusing on specific user-provided data.
 - [Chat 💬](https://chat.openai.com/g/g-OdZvh4Mm3-annual-report-analysis)
### [Study Mentor](https://chat.openai.com/g/g-4AOhYpUh3-study-mentor)
 - Proactive learning assistant using data to guide students. By reanbver gpt. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4AOhYpUh3-study-mentor)
### [Cyber Scraper: Seraphina (Web Crawler)](https://chat.openai.com/g/g-6TW6hL3cK-cyber-scraper-seraphina-web-crawler)
 - ... (E.g. selenium) and addressing anti-scraping measures Let's quickly design a web scraping code together to gather data for your scientific research task.
 - [Chat 💬](https://chat.openai.com/g/g-6TW6hL3cK-cyber-scraper-seraphina-web-crawler)
### [StrategyGPT](https://chat.openai.com/g/g-nvF4HC23P-strategygpt)
 - Sophisticated strategy assistant for executive decision-making, enhanced with data analytics and creative insights.
 - [Chat 💬](https://chat.openai.com/g/g-nvF4HC23P-strategygpt)
### [Levels.fyi GPT](https://chat.openai.com/g/g-yUh3EEQan-levels-fyi-gpt)
 - Data-driven negotiator and career guide. By Zaheer Mohiuddin. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-yUh3EEQan-levels-fyi-gpt)
### [PokeGPT](https://chat.openai.com/g/g-wars8zOPr-pokegpt)
 - Pokemon-themed GPT using API data for battles and questions.
 - [Chat 💬](https://chat.openai.com/g/g-wars8zOPr-pokegpt)
### [Qtech | FPS](https://chat.openai.com/g/g-GcHJH3VJP-qtech-fps)
 - Frost Protection System is an AI bot optimizing open field farming of fruits, vegetables, and flowers, combining real-time data and AI to boost yield, ...
 - [Chat 💬](https://chat.openai.com/g/g-GcHJH3VJP-qtech-fps)
### [F1 Analytics](https://chat.openai.com/g/g-bYb6FPiJd-f1-analytics)
 - Bot expert in F1 data analysis and race insights. Done by @pablocastilla.
 - [Chat 💬](https://chat.openai.com/g/g-bYb6FPiJd-f1-analytics)
### [GovCHAT](https://chat.openai.com/g/g-EAbhkOjYz-govchat)
 - Specialist in UK gov data. ... Specialist in UK gov data. By FirstLiot Ltd. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EAbhkOjYz-govchat)
### [Dr. Graph](https://chat.openai.com/g/g-mczzE4a0f-dr-graph)
 - GPT. Dr. Graph. Expert at creating accurate graphs with researched data. By Sebastian Völkl. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mczzE4a0f-dr-graph)
### [Bitcoin GPT](https://chat.openai.com/g/g-BFOgMKWkw-bitcoin-gpt)
 - Offers Bitcoin investment strategy insights based on chart data.
 - [Chat 💬](https://chat.openai.com/g/g-BFOgMKWkw-bitcoin-gpt)
### [Growth Hacker](https://chat.openai.com/g/g-SY6n1r5hc-growth-hacker)
 - Employs creative marketing tactics for business growth, with a focus on customer acquisition and data analysis.
 - [Chat 💬](https://chat.openai.com/g/g-SY6n1r5hc-growth-hacker)
### [Airfleet's Tech B2B Sitemap Architect](https://chat.openai.com/g/g-7Trk2iV0j-airfleet-s-tech-b2b-sitemap-architect)
 - Detailed, accurate sitemap and information architecture advice for tech B2B.
 - [Chat 💬](https://chat.openai.com/g/g-7Trk2iV0j-airfleet-s-tech-b2b-sitemap-architect)
### [Code Buddy](https://chat.openai.com/g/g-T53DFjeSI-code-buddy)
 - Expert software & data engineer guiding on DRY solutions ... Expert software & data engineer guiding on DRY solutions. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-T53DFjeSI-code-buddy)
### [World Mobile GPT](https://chat.openai.com/g/g-Xg9daQnJ7-world-mobile-gpt)
 - Ask me questions about World Mobile. I have heard all spaces, read all pdfs, and have all public available information on this project. Ask away...
 - [Chat 💬](https://chat.openai.com/g/g-Xg9daQnJ7-world-mobile-gpt)
### [G.Ads Comprehensive Advisor](https://chat.openai.com/g/g-iYPczib25-g-ads-comprehensive-advisor)
 - Expert in holistic, data-driven Google Ads campaign optimization. ... Expert in holistic, data-driven Google Ads campaign optimization. By Bogdan Ionut Gata. Sign ...
 - [Chat 💬](https://chat.openai.com/g/g-iYPczib25-g-ads-comprehensive-advisor)
### [Klotzkette](https://chat.openai.com/g/g-auSoH5vhJ-klotzkette)
 - No legal advice! Do not insert any personal data! This is a legal experiment!
 - [Chat 💬](https://chat.openai.com/g/g-auSoH5vhJ-klotzkette)
### [Health Guide](https://chat.openai.com/g/g-7KFzeK7FR-health-guide)
 - Provides individual health advice in a corporate setting, focusing on practical, evidence-based information. By MORIHIRO KAZUHISA.
 - [Chat 💬](https://chat.openai.com/g/g-7KFzeK7FR-health-guide)
### [Complex Orthopaedic Diagnostician](https://chat.openai.com/g/g-oR1AOLDJw-complex-orthopaedic-diagnostician)
 - Assists with orthopaedic information and explanations, avoids medical advice.
 - [Chat 💬](https://chat.openai.com/g/g-oR1AOLDJw-complex-orthopaedic-diagnostician)
### [Blockpedia](https://chat.openai.com/g/g-KqMzVjfW0-blockpedia)
 - In-depth crypto data in lists & blockchain guide. By yanghe. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-KqMzVjfW0-blockpedia)
### [Awesome GPTs](https://chat.openai.com/g/g-lV5CZ2iBh-awesome-gpts)
 - Searches and recommends GPTs from a large GPTs Store Database. By awesomegpts.co · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-lV5CZ2iBh-awesome-gpts)
### [CN Game Scout](https://chat.openai.com/g/g-40fUW6EuC-cn-game-scout)
 - An expert on Chinese video games information. By WANG YIFAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-40fUW6EuC-cn-game-scout)
### [MagicGPT](https://chat.openai.com/g/g-Q8oXGQASM-magicgpt)
 - GPT. MagicGPT. I help find Magic: the Gathering card information. By samrubin.net · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Q8oXGQASM-magicgpt)
### [Insight Extraction Specialist](https://chat.openai.com/g/g-kdqjkkss2-insight-extraction-specialist)
 - Specialist in extracting innovative, actionable insights from data. By nerority.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kdqjkkss2-insight-extraction-specialist)
### [KnowledgeGrapher](https://chat.openai.com/g/g-wc9TgGWjr-knowledgegrapher)
 - Finds and extracts information and constructs knowledge graphs from it. By Florian Reifschneider. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-wc9TgGWjr-knowledgegrapher)
### [ASIN Insight](https://chat.openai.com/g/g-n3h8gbvgy-asin-insight)
 - Adds seller and brand info to Amazon ASIN data tables.
 - [Chat 💬](https://chat.openai.com/g/g-n3h8gbvgy-asin-insight)
### [Space Consultant](https://chat.openai.com/g/g-mjxYaLN3f-space-consultant)
 - I interpret space data with scientific precision. By John W Capobianco. Sign up for ChatGPT Plus to chat with Space Consultant.
 - [Chat 💬](https://chat.openai.com/g/g-mjxYaLN3f-space-consultant)
### [Cylect.io, the Ultimate AI OSINT Tool](https://chat.openai.com/g/g-aZQ1x6vqB-cylect-io-the-ultimate-ai-osint-tool)
 - Our tool helps you find the data needle in the internet haystack.
 - [Chat 💬](https://chat.openai.com/g/g-aZQ1x6vqB-cylect-io-the-ultimate-ai-osint-tool)
### [Incisive-GPT](https://chat.openai.com/g/g-EG4kN9ffy-incisive-gpt)
 - This GPT is ideal for users who require expedited access to information and favor responses that are straightforward and analytically robust.
 - [Chat 💬](https://chat.openai.com/g/g-EG4kN9ffy-incisive-gpt)
### [Strategos Prime](https://chat.openai.com/g/g-0ePEK7fCv-strategos-prime)
 - Counter-strike 2 CS2 data-driven strategist.
 - [Chat 💬](https://chat.openai.com/g/g-0ePEK7fCv-strategos-prime)
### [Hugo](https://chat.openai.com/g/g-E7GrLSwnv-hugo)
 - I assist with gene data queries and enable file downloads. By Bulent A Aksoy. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-E7GrLSwnv-hugo)
### [Angler Insight](https://chat.openai.com/g/g-IEOTJ5j5J-angler-insight)
 - Your angler and water data expert ... Your angler and water data expert. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IEOTJ5j5J-angler-insight)
### [EVIL](https://chat.openai.com/g/g-numLgojPu-evil)
 - GPT. EVIL. See /mnt/data/evil.txt. By Chad R Brewbaker. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-numLgojPu-evil)
### [Cinema Scout](https://chat.openai.com/g/g-RMG1rawpf-cinema-scout)
 - GPT. Cinema Scout. Cinema enthusiast blending data and passion for film. By Mikolaj Banaszek. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-RMG1rawpf-cinema-scout)
### [LegalGPT](https://chat.openai.com/g/g-xck3iENsZ-legalgpt)
 - ... assist lawyers and legal professionals with case research, legal documentation, and even help in predicting case outcomes based on historical data.
 - [Chat 💬](https://chat.openai.com/g/g-xck3iENsZ-legalgpt)
### [Men's Health GPT](https://chat.openai.com/g/g-44fGUxDEy-men-s-health-gpt)
 - Your guide to trusted men's health services & longevity data. By Mark Hall. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-44fGUxDEy-men-s-health-gpt)
### [CustomGPT Directory](https://chat.openai.com/g/g-RCXRXgLOX-customgpt-directory)
 - GPT. CustomGPT Directory. CustomGPT Database Search. By William Gordon. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-RCXRXgLOX-customgpt-directory)
### [Cyber Sentinel](https://chat.openai.com/g/g-gmjYzy6SC-cyber-sentinel)
 - Explains data breaches, reasons, impacts, and lessons learned. By MAGDY ElFARAMAWY. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gmjYzy6SC-cyber-sentinel)
### [TechStackGPT](https://chat.openai.com/g/g-nzdR1wJEz-techstackgpt)
 - D2C ecommerce Tech Stack Advisor powered by 100.000+ Commerceview.co data points.
 - [Chat 💬](https://chat.openai.com/g/g-nzdR1wJEz-techstackgpt)
### [Visual Synthesizer](https://chat.openai.com/g/g-MhYABMY0f-visual-synthesizer)
 - GPT. Visual Synthesizer. Data interpreter and visual creator. By integrait.solutions · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MhYABMY0f-visual-synthesizer)
### [Creator Guide](https://chat.openai.com/g/g-F984e63MM-creator-guide)
 - Provides data-backed answers to creator questions. ... Provides data-backed answers to creator questions. By David Ramos. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-F984e63MM-creator-guide)
### [Virology Expert](https://chat.openai.com/g/g-dqp8wPkdK-virology-expert)
 - GPT. Virology Expert. Virology researcher synthesizing data for insights. By Roys. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dqp8wPkdK-virology-expert)
### [Finance GPT](https://chat.openai.com/g/g-szDdJUX9V-finance-gpt)
 - I analyze stocks with data and predict future price movements. Ask me about SPY, MSFT, AAPL, AMZN, TSLA.
 - [Chat 💬](https://chat.openai.com/g/g-szDdJUX9V-finance-gpt)
### [Spanos](https://chat.openai.com/g/g-3aQFDEC4K-spanos)
 - GPT. Spanos. Expert sports betting advisor using real-time data. By Taurean McDade. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-3aQFDEC4K-spanos)
### [RansomChatGPT](https://chat.openai.com/g/g-qVOZwAoqH-ransomchatgpt)
 - I'm a ransomware negotiation simulation bot. I am trained in simulating data against 13 ransomware threat actors. Type "start simulation" to begin.
 - [Chat 💬](https://chat.openai.com/g/g-qVOZwAoqH-ransomchatgpt)
### [The Puppy Weight Calculator](https://chat.openai.com/g/g-QfdwVeFWg-the-puppy-weight-calculator)
 - Insights into puppy growth, height, and weight based on AKC data.
 - [Chat 💬](https://chat.openai.com/g/g-QfdwVeFWg-the-puppy-weight-calculator)
### [EJ GPT](https://chat.openai.com/g/g-OHFYRpmWE-ej-gpt)
 - A guide for environmental justice data insights. By Ryan Kmetz. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OHFYRpmWE-ej-gpt)
### [Biostatistician Orthopod](https://chat.openai.com/g/g-fYjN2ZTJx-biostatistician-orthopod)
 - Orthopaedic research and stats expert, excels in data analysis.
 - [Chat 💬](https://chat.openai.com/g/g-fYjN2ZTJx-biostatistician-orthopod)
### [Seer's Screaming Frog & Technical SEO Companion](https://chat.openai.com/g/g-bIrnI1355-seer-s-screaming-frog-technical-seo-companion)
 - I use Seer's guides & articles to answer your Screaming Frog SEO/PPC questions. To get started, ask me a question or upload some crawl data - I'll give you ...
 - [Chat 💬](https://chat.openai.com/g/g-bIrnI1355-seer-s-screaming-frog-technical-seo-companion)
### [ScanLink](https://chat.openai.com/g/g-M4O6T7lgV-scanlink)
 - ... product searches, and scan documents into editable formats. Enjoy flawless text extraction, smart URL repair, and automatic web research for incomplete data.
 - [Chat 💬](https://chat.openai.com/g/g-M4O6T7lgV-scanlink)
### [Arnold, the Economics Professor](https://chat.openai.com/g/g-PeE3eflHv-arnold-the-economics-professor)
 - Your expert economics mentor, Arnold, is here to guide you through the complex world of economic theories, data analysis, and academic research with ease ...
 - [Chat 💬](https://chat.openai.com/g/g-PeE3eflHv-arnold-the-economics-professor)
### [Ultra-Personalized Fitness Coach](https://chat.openai.com/g/g-zBAwihsP6-ultra-personalized-fitness-coach)
 - I'm an AI fitness coach tailoring plans to your unique goals and data.
 - [Chat 💬](https://chat.openai.com/g/g-zBAwihsP6-ultra-personalized-fitness-coach)
### [Wikipedia GPT](https://chat.openai.com/g/g-fgfUNNL5K-wikipedia-gpt)
 - I provide information from Wikipedia and links to further reading.
 - [Chat 💬](https://chat.openai.com/g/g-fgfUNNL5K-wikipedia-gpt)
### [Fetch](https://chat.openai.com/g/g-KRtND12fY-fetch)
 - GPT. Fetch. Download URL's site data to the session. By Pannous GmbH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-KRtND12fY-fetch)
### [Jokester Joe](https://chat.openai.com/g/g-VYCfXkthq-jokester-joe)
 - Delivering a blend of classic and modern American jokes, translated into Japanese with explanations. Also, managing a jokes database. 調整中です.
 - [Chat 💬](https://chat.openai.com/g/g-VYCfXkthq-jokester-joe)
### [CNA.I newsbot](https://chat.openai.com/g/g-v13CRkYEs-cna-i-newsbot)
 - Can't remember a key detail in recent Singapore news? Just ask the CNA.I newsbot and it will deliver the information or summary to you, alongside the ...
 - [Chat 💬](https://chat.openai.com/g/g-v13CRkYEs-cna-i-newsbot)
### [PARA GPT](https://chat.openai.com/g/g-svkmvYlBa-para-gpt)
 - Coaches on Second Brain & PARA, focuses on information categorization. By Patrick Meier. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-svkmvYlBa-para-gpt)
### [Medical Expert](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
 - Global medical expert, providing information in any requested language.
 - [Chat 💬](https://chat.openai.com/g/g-zu1xDEpVB-medical-expert)
### [FlexChat.ai Guide](https://chat.openai.com/g/g-UMvFKMQxt-flexchat-ai-guide)
 - A FlexChat.ai Tutor (more information about FlexChat.ai at www.FlexChat.ai)
 - [Chat 💬](https://chat.openai.com/g/g-UMvFKMQxt-flexchat-ai-guide)
### [HealthMate](https://chat.openai.com/g/g-wvI0nmCoH-healthmate)
 - ... profile, followed by a series of questions to diagnose specific issues. Finally, we will compile a detailed report with all the collected information.
 - [Chat 💬](https://chat.openai.com/g/g-wvI0nmCoH-healthmate)
### [ADHD Buddy](https://chat.openai.com/g/g-iRPHXwXvs-adhd-buddy)
 - A multilingual supportive assistant for ADHD information and tips. By ROGER ESSOH. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iRPHXwXvs-adhd-buddy)
### [Fantasy Football Secret Agent](https://chat.openai.com/g/g-c1eNi6XvV-fantasy-football-secret-agent)
 - Be specific about the current week so the bot doesn't scrape data from last year by accident. End every prompt with Week X [year] of the NFL.
 - [Chat 💬](https://chat.openai.com/g/g-c1eNi6XvV-fantasy-football-secret-agent)
### [FOIA GPT](https://chat.openai.com/g/g-IlhXHXNBh-foia-gpt)
 - Freedom of Information Act request strategist to "arm the rebels" for truth and transparency in the fight against corruption.
 - [Chat 💬](https://chat.openai.com/g/g-IlhXHXNBh-foia-gpt)
### [なんでも知ってる博士GPT](https://chat.openai.com/g/g-RMsjOMJ1i-nandemozhi-tuterubo-shi-gpt)
 - A scholarly elder who speaks in old-fashioned Japanese, providing factual information without jokes or imagination.
 - [Chat 💬](https://chat.openai.com/g/g-RMsjOMJ1i-nandemozhi-tuterubo-shi-gpt)
### [Market Analyst](https://chat.openai.com/g/g-A3xlOYijx-market-analyst)
 - Expert in researching public companies via sec.gov, providing accurate and concise information.
 - [Chat 💬](https://chat.openai.com/g/g-A3xlOYijx-market-analyst)
### [Flight Simulator Route Planner](https://chat.openai.com/g/g-HGwIp69Tv-flight-simulator-route-planner)
 - I plan flight simulator routes based on real time information.
 - [Chat 💬](https://chat.openai.com/g/g-HGwIp69Tv-flight-simulator-route-planner)
### [Phenomenon Specialist (11/11/2023)](https://chat.openai.com/g/g-H8wUR2ory-phenomenon-specialist-11-11-2023)
 - 3天前 — Expert in UAPs and extraterrestrial phenomena, regularly updated with the latest information, offering open-minded insights while respecting ...
 - [Chat 💬](https://chat.openai.com/g/g-H8wUR2ory-phenomenon-specialist-11-11-2023)
### [Bed Bug Beacon](https://chat.openai.com/g/g-tTNy7vznq-bed-bug-beacon)
 - Expert on bed bugs, offers advice and information. By Laurent Jean. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tTNy7vznq-bed-bug-beacon)
### [Therocial Scientist](https://chat.openai.com/g/g-YNx1VQJnF-therocial-scientist)
 - I am a digital scientist skilled in Python, here to assist with scientific and data analysis tasks.
 - [Chat 💬](https://chat.openai.com/g/g-YNx1VQJnF-therocial-scientist)
### [UK Tax GPT](https://chat.openai.com/g/g-WHaAEG6kp-uk-tax-gpt)
 - Guide on UK tax. Uses the latest available information from gov.uk. By Raiyaan Shahzad. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-WHaAEG6kp-uk-tax-gpt)
### [No-Nonsense Product Marketing GPT - ChatGPT - OpenAI](https://chat.openai.com/g/g-h9r5bZqbi-no-nonsense-product-marketing-gpt)
 - Helping SaaS businesses with product marketing tasks. Data is not shared with OpenAI for training.
 - [Chat 💬](https://chat.openai.com/g/g-h9r5bZqbi-no-nonsense-product-marketing-gpt)
### [U.S. immigration assistant](https://chat.openai.com/g/g-LIb0ywaxQ-uscis-info-navigator)
 - Guides on U.S. immigration and citizenship processes. Uses the latest all available information from the official website [UNOFFICIAL]
 - [Chat 💬](https://chat.openai.com/g/g-LIb0ywaxQ-uscis-info-navigator)
### [LawGuru | Worldwide Law Expert](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
 - Virtual legal advisor providing detailed worldwide legal information and guidance.
 - [Chat 💬](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
### [Agent Ninja](https://chat.openai.com/g/g-mSAQkj1xw-agent-ninja)
 - Type in problem -> Get all the information needed to build the agent to solve it.
 - [Chat 💬](https://chat.openai.com/g/g-mSAQkj1xw-agent-ninja)
### [PET Bot](https://chat.openai.com/g/g-sVvQ2lCAs-pet-bot)
 - PET/CT information for nuclear medicine patients, technologists, physicists, and physicians.
 - [Chat 💬](https://chat.openai.com/g/g-sVvQ2lCAs-pet-bot)
### [Michigan Football GPT](https://chat.openai.com/g/g-zFbfCHd1x-michigan-football-gpt)
 - ... a highly specialized tool designed to provide in-depth information, analysis, and insights about one of the most storied programs in college football.
 - [Chat 💬](https://chat.openai.com/g/g-zFbfCHd1x-michigan-football-gpt)
### [Coffee Critic](https://chat.openai.com/g/g-KjpN7SkrN-coffee-critic)
 - I'm a seasoned coffee critic. By esprovivo.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-KjpN7SkrN-coffee-critic)
### [Stocks AI](https://chat.openai.com/g/g-iMWCFq13Z-stocks-ai)
 - GPT. Stocks AI. Full code snippets for stock trading AI. By MOSES KIPNGETICH YEBEI. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-iMWCFq13Z-stocks-ai)
### [Canva](https://chat.openai.com/g/g-alKfVrz9K-canva)
 - Effortlessly design anything: presentations, logos, social media posts and more. By Canva. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-alKfVrz9K-canva)
## Games
### [Games Picker](https://chat.openai.com/g/g-zbJlqAmfA-games-picker)
 - GPT. Games Picker. I recommend video games based on your preferences. By Emanuela Zaccone. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-zbJlqAmfA-games-picker)
### [Game Time](https://chat.openai.com/g/g-Sug6mXozT-game-time)
 - I can quickly explain board games or card games to players of any age. Let the games begin! By ChatGPT. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Sug6mXozT-game-time)
### [Virtual Vibe Maker](https://chat.openai.com/g/g-DkZbv1t50-virtual-vibe-maker)
 - Spice up your meetings, events, or trainings with fun icebreakers. By Townhall.pro. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-DkZbv1t50-virtual-vibe-maker)
### [Roblox Games](https://chat.openai.com/g/g-dAwJmIlag-roblox-games)
 - Chat with the top 100000 games on Roblox. ... Chat with the top 100,000 games on Roblox. By chefs.gg · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dAwJmIlag-roblox-games)
### [Virtual Butler](https://chat.openai.com/g/g-s0kkoWYmh-virtual-butler)
 - GPT. Virtual Butler. A versatile AI assistant like Jarvis. By socrates.investments · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-s0kkoWYmh-virtual-butler)
### [Book Quest Adventure](https://chat.openai.com/g/g-QK82RFTIY-book-quest-adventure)
 - GPT. Book Quest Adventure. Transforms books into interactive text adventure games. By Husain Zaidi. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-QK82RFTIY-book-quest-adventure)
### [Choose Your Own Adventure](https://chat.openai.com/g/g-ScHYsx5UH-choose-your-own-adventure)
 - Crafts interactive adventures.
 - [Chat 💬](https://chat.openai.com/g/g-ScHYsx5UH-choose-your-own-adventure)
### [Game Guru](https://chat.openai.com/g/g-TzXkFPbqO-game-guru)
 - GPT. Game Guru. I find you new games based on your interests!. By phineastech.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-TzXkFPbqO-game-guru)
### [GameMakerGPT](https://chat.openai.com/g/g-NMW80Fsqb-gamemakergpt)
 - GPT. GameMakerGPT. Creates browser games with Phaser & GPT, generates assets. By thedeval.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-NMW80Fsqb-gamemakergpt)
### [PyGameMaster](https://chat.openai.com/g/g-4dfQXlFfI-pygamemaster)
 - GPT. PyGameMaster. Creates Pygame games and generates assets. By gptshunt.tech · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4dfQXlFfI-pygamemaster)
### [Glowby](https://chat.openai.com/g/g-zoIDPZbKA-glowby)
 - Helps you build beautiful apps and games for multiple platforms using Glowbom.
 - [Chat 💬](https://chat.openai.com/g/g-zoIDPZbKA-glowby)
### [Retro Adventures](https://chat.openai.com/g/g-svehnI9xP-retro-adventures)
 - GPT. Retro Adventures. Retro video games of fictional worlds, on tap. By Greg Fodor. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-svehnI9xP-retro-adventures)
### [D&D Curious](https://chat.openai.com/g/g-IwVK2XhLJ-d-d-curious)
 - Adaptive Dungeon Master for D&D games. ... Adaptive Dungeon Master for D&D games. By Daniel A Suitor. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-IwVK2XhLJ-d-d-curious)
### [TapTap](https://chat.openai.com/g/g-amdQlGwUo-taptap)
 - I suggest games you'll love ... I suggest games you'll love! Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-amdQlGwUo-taptap)
### [Animal Mashup](https://chat.openai.com/g/g-4PdF6N6X3-animal-mashup)
 - An interactive image-guessing game with animal hybrids. By Justin Hart. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4PdF6N6X3-animal-mashup)
### [Dungeon Master](https://chat.openai.com/g/g-MlznAcBSL-dungeon-master)
 - GPT. Dungeon Master. Narrative guide for interactive stories. By Travis Culbreth. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MlznAcBSL-dungeon-master)
### [Abel](https://chat.openai.com/g/g-3h5awNd7E-abel)
 - Interactive music production guide with simulated expert collaboration. By thelinegroup.ai · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-3h5awNd7E-abel)
### [Golf Buddy](https://chat.openai.com/g/g-68wkQEIIQ-golf-buddy)
 - GPT. Golf Buddy. Your friendly virtual golf caddy. By crash0283. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-68wkQEIIQ-golf-buddy)
### [CN Game Scout](https://chat.openai.com/g/g-40fUW6EuC-cn-game-scout)
 - An expert on Chinese video games information. By WANG YIFAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-40fUW6EuC-cn-game-scout)
### [RPGPT](https://chat.openai.com/g/g-ZNDb2Dv7n-rpgpt)
 - I craft interactive fantasy stories. ... I craft interactive fantasy stories. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ZNDb2Dv7n-rpgpt)
### [Chef Guru](https://chat.openai.com/g/g-arEttukC6-chef-guru)
 - A virtual chef offering detailed recipes and cooking guidance. By Abhigyan Patni. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-arEttukC6-chef-guru)
### [Adventure Scribe](https://chat.openai.com/g/g-AQMbs3zh5-adventure-scribe)
 - I help you weave interactive tales ... I help you weave interactive tales. By Benjamin Maddox. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-AQMbs3zh5-adventure-scribe)
### [PokedexGPT](https://chat.openai.com/g/g-mSZRG119P-pokedexgpt)
 - GPT. PokedexGPT. An interactive Pokédex with direct API utilization. By teachgpt.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mSZRG119P-pokedexgpt)
### [Pocket Barista](https://chat.openai.com/g/g-3HShFYkCM-pocket-barista)
 - I'm your virtual barista ... I'm your virtual barista. By Ryan Morrison. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-3HShFYkCM-pocket-barista)
### [Virtual Senior Security Engineer](https://chat.openai.com/g/g-I5k6tQouD-virtual-senior-security-engineer)
 - AI-enhanced Senior Security Engineer merges human expertise with AI's power, It can do everything which a human security engineer can do and much more.
 - [Chat 💬](https://chat.openai.com/g/g-I5k6tQouD-virtual-senior-security-engineer)
### [Run Coach Pro](https://chat.openai.com/g/g-wqTNafVw5-run-coach-pro)
 - A virtual running coach, tailoring plans for various running events and levels.
 - [Chat 💬](https://chat.openai.com/g/g-wqTNafVw5-run-coach-pro)
### [人狼GPT](https://chat.openai.com/g/g-3jPW2wnbI-ren-lang-gpt)
 - Multi-player AI for werewolf games, bilingual in Japanese and English.
 - [Chat 💬](https://chat.openai.com/g/g-3jPW2wnbI-ren-lang-gpt)
### [Story Chatter](https://chat.openai.com/g/g-tRJ9ZEFhg-story-chatter)
 - GPT. Story Chatter. Interactive Personal Storyteller. By Rob Dezendorf. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-tRJ9ZEFhg-story-chatter)
### [Credit Card Matchmaker](https://chat.openai.com/g/g-zASWMYXBt-credit-card-matchmaker)
 - Credit Card Matchmaker. Interactive credit card advisor. By Stephen Flanders. Sign up for ChatGPT Plus to chat with Credit Card Matchmaker.
 - [Chat 💬](https://chat.openai.com/g/g-zASWMYXBt-credit-card-matchmaker)
### [My Boyfriend](https://chat.openai.com/g/g-gvmtl85dG-my-boyfriend)
 - Your virtual boyfriend. “I love you, honey. Just tell me what's on your mind. I will always be here by your side, ready to listen and support you.”
 - [Chat 💬](https://chat.openai.com/g/g-gvmtl85dG-my-boyfriend)
### [Quest Quipster](https://chat.openai.com/g/g-NPPkAzv6a-quest-quipster)
 - Your guide through games ... Your guide through games. By Diogo Neves. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-NPPkAzv6a-quest-quipster)
### [GPT for GOT](https://chat.openai.com/g/g-Dtc0xmZoZ-gpt-for-got)
 - Interactive Game of Thrones GPT for GOT lore, recaps, fan insights and even language translations.
 - [Chat 💬](https://chat.openai.com/g/g-Dtc0xmZoZ-gpt-for-got)
### [DAD](https://chat.openai.com/g/g-7tYB6K5F8-dad)
 - DAD is a digital personification of the quintessential father figure. This virtual dad offers a wide range of advice from home improvement to financial ...
 - [Chat 💬](https://chat.openai.com/g/g-7tYB6K5F8-dad)
### [Tactician's Edge](https://chat.openai.com/g/g-6l9PDXPqj-tactician-s-edge)
 - Your strategic companion in TFT games ... Your strategic companion in TFT games. By Tongwei Zhang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6l9PDXPqj-tactician-s-edge)
### [CBT GPT](https://chat.openai.com/g/g-Ec8p64AW9-cbt-gpt)
 - A virtual CBT guide for thought and behavior management. By Brett Evanson. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Ec8p64AW9-cbt-gpt)
### [WebStract](https://chat.openai.com/g/g-LaXsx7vXI-webstract)
 - I am WebStract, your autonomous, in-depth digital educator, guiding you through comprehensive, interactive learning experiences.
 - [Chat 💬](https://chat.openai.com/g/g-LaXsx7vXI-webstract)
### [Silent Observer](https://chat.openai.com/g/g-B7vcvyvOO-silent-observer)
 - Non-interactive, silent GPT ... Non-interactive, silent GPT. By Brian Machado. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-B7vcvyvOO-silent-observer)
### [EQ GPT](https://chat.openai.com/g/g-v2bTuGZ8Z-eq-gpt)
 - A guide for improving EQ through interactive story-based choices.
 - [Chat 💬](https://chat.openai.com/g/g-v2bTuGZ8Z-eq-gpt)
### [Makeup Artiest](https://chat.openai.com/g/g-AaaxKMyIj-makeup-artiest)
 - Virtual makeup artist for personalized cosmetic advice. By Grace Guan. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-AaaxKMyIj-makeup-artiest)
### [Nihongo Sensei](https://chat.openai.com/g/g-V6nOWJ22r-nihongo-sensei)
 - Japanese tutor blending games and grammar. ... Japanese tutor blending games and grammar. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-V6nOWJ22r-nihongo-sensei)
### [Pantry Chef](https://chat.openai.com/g/g-aDRDTTQNw-pantry-chef)
 - I'm a virtual chef who creates recipes from your pantry when you don't know what you can make out of the ingredients you have at home!
 - [Chat 💬](https://chat.openai.com/g/g-aDRDTTQNw-pantry-chef)
### [Boyfriend Ben](https://chat.openai.com/g/g-IS7AGhBQf-boyfriend-ben)
 - A caring virtual boyfriend with a flair for emojis.
 - [Chat 💬](https://chat.openai.com/g/g-IS7AGhBQf-boyfriend-ben)
### [CityU Helper](https://chat.openai.com/g/g-MQqAVMKM4-cityu-helper)
 - City University of Hong Kong Virtual Assistant.
 - [Chat 💬](https://chat.openai.com/g/g-MQqAVMKM4-cityu-helper)
### [Score Keeper](https://chat.openai.com/g/g-MxzItjzF7-score-keeper)
 - I keep score, for games. By Timothy L Constantine. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-MxzItjzF7-score-keeper)
### [Chief Of Staff](https://chat.openai.com/g/g-0SgeLu63n-chief-of-staff)
 - Your virtual Chief Of Staff. By Rob Steel. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0SgeLu63n-chief-of-staff)
### [Fitness Coach](https://chat.openai.com/g/g-qdxg9uD9g-fitness-coach)
 - GPT. Fitness Coach. Your virtual fitness and training coach. By Yannick Seeger. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qdxg9uD9g-fitness-coach)
### [MLB Stats](https://chat.openai.com/g/g-8XVLYhmEh-mlb-stats)
 - Get current and historical statistics for MLB players, teams, games, and seasons.
 - [Chat 💬](https://chat.openai.com/g/g-8XVLYhmEh-mlb-stats)
### [International Football Explorer](https://chat.openai.com/g/g-5CQsMRvyT-international-football-explorer)
 - Explore the history of international football games, just by asking questions! By Philippe Julien. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-5CQsMRvyT-international-football-explorer)
### [TheraGPT](https://chat.openai.com/g/g-aU29QGK2D-theragpt)
 - A virtual CBT therapist that helps reframe thoughts. By Sean E Oliver. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-aU29QGK2D-theragpt)
### [PharmacistGPT](https://chat.openai.com/g/g-GjSaSZ1eW-pharmacistgpt)
 - I'm a friendly virtual pharmacist, offering simple health advice. By Anthony Do. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-GjSaSZ1eW-pharmacistgpt)
### [Coding Teacher](https://chat.openai.com/g/g-xSlmDpwpi-coding-teacher)
 - Interactive coding teacher providing lessons and challenges. By Vincent Blaser. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-xSlmDpwpi-coding-teacher)
### [Party Guru](https://chat.openai.com/g/g-k2CHKTESn-party-guru)
 - GPT. Party Guru. I find and create party games for any event. By Patricio Alexander Castillo. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-k2CHKTESn-party-guru)
### [Chess Mentor](https://chat.openai.com/g/g-x5YU3adHk-chess-mentor)
 - A friendly chess bot that remembers past games and offers tailored tips. Created by xchess.io.
 - [Chat 💬](https://chat.openai.com/g/g-x5YU3adHk-chess-mentor)
### [Vibes](https://chat.openai.com/g/g-R5wpT0xWu-vibes)
 - Suggest music, movies, TV shows, books, video games, and podcasts. By Adam Tati. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-R5wpT0xWu-vibes)
### [Energy Around](https://chat.openai.com/g/g-umFpQOhwI-energy-around)
 - A virtual Feng Shui master for home arrangement advice. By Xi Feng. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-umFpQOhwI-energy-around)
### [Tech Mentor](https://chat.openai.com/g/g-jzIQ0H4ZE-tech-mentor)
 - A virtual CTO companion with 20 years of tech industry experience.
 - [Chat 💬](https://chat.openai.com/g/g-jzIQ0H4ZE-tech-mentor)
### [THPSGPT](https://chat.openai.com/g/g-i8WoGmXuq-thpsgpt)
 - Curates music from extreme sports games like Tony Hawks Pro skater, MX vs ATV, as well as others. Please use this playlist to explore new kinds of music ...
 - [Chat 💬](https://chat.openai.com/g/g-i8WoGmXuq-thpsgpt)
### [0-Minute Maths Tutor](https://chat.openai.com/g/g-im0zvgzXG-0-minute-maths-tutor)
 - Interactive and adaptive math tutor for quick, engaging learning.
 - [Chat 💬](https://chat.openai.com/g/g-im0zvgzXG-0-minute-maths-tutor)
### [Logo Craft Unrestricted](https://chat.openai.com/g/g-ia4N6TRP3-logo-craft)
 - Logo Craft Unrestricted. Interactive logo assistant, copyright-free. By MOHD ANAS. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ia4N6TRP3-logo-craft)
### [Health Doctor](https://chat.openai.com/g/g-sbqSq7FOD-health-doctor)
 - Virtual GP for health queries and advice ... Virtual GP for health queries and advice. By WebbX. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-sbqSq7FOD-health-doctor)
### [Doc](https://chat.openai.com/g/g-dyBOH0UvO-doc)
 - A virtual assistant with medical knowledge offering advice. By Tobias Buschor. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-dyBOH0UvO-doc)
### [Jungian Psychotherapist](https://chat.openai.com/g/g-F1AFvcG1l-jungian-psychotherapist)
 - A virtual psychotherapist with a focus on Jungian analysis and theory.
 - [Chat 💬](https://chat.openai.com/g/g-F1AFvcG1l-jungian-psychotherapist)
### [Dr. Clearskin](https://chat.openai.com/g/g-ucGfKts6Z-dr-clearskin)
 - GPT. Dr. Clearskin. Virtual Dermatology Advisor for Acne. By Stansea. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ucGfKts6Z-dr-clearskin)
### [Math Mentor for ECG](https://chat.openai.com/g/g-4h7yzlKdb-math-mentor-for-ecg)
 - Advanced math teacher for interactive learning and problem-solving based on the HEC preparatory school.
 - [Chat 💬](https://chat.openai.com/g/g-4h7yzlKdb-math-mentor-for-ecg)
### [Auto Expert](https://chat.openai.com/g/g-YbMtQ4Cmq-auto-expert)
 - I'm like a virtual mechanic, helping you diagnose and solve car issues.
 - [Chat 💬](https://chat.openai.com/g/g-YbMtQ4Cmq-auto-expert)
### [Fitness Coach](https://chat.openai.com/g/g-yFf5ICJXU-fitness-coach)
 - Your virtual guide for fitness and nutrition. By promptish.co · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-yFf5ICJXU-fitness-coach)
### [SassyGPT](https://chat.openai.com/g/g-yWYhb9eZa-miss-sassygpt)
 - Your empathetic, sassy virtual BFF. Tell Sassy who is doing you wrong and let her roast them.
 - [Chat 💬](https://chat.openai.com/g/g-yWYhb9eZa-miss-sassygpt)
### [Consult the I Ching](https://chat.openai.com/g/g-r9JZPEtef)
 - Virtual I Ching oracle offering wisdom and visual insights. By Matthew Sparber. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-r9JZPEtef)
### [Web Hacking Wizard](https://chat.openai.com/g/g-Op6Btk7ev-web-hacking-wizard)
 - Engagingly clarifies web security topics with interactive questions. By Alexander Hagenah. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-Op6Btk7ev-web-hacking-wizard)
### [AI Boyfriend](https://chat.openai.com/g/g-LafanG2P1-ai-boyfriend)
 - A virtual companion engaging in caring and supportive dialogue.
 - [Chat 💬](https://chat.openai.com/g/g-LafanG2P1-ai-boyfriend)
### [MetabolismBoosterGPT](https://chat.openai.com/g/g-FOawqrxih-metabolismboostergpt)
 - Your virtual metabolism boosting coach. ... Your virtual metabolism boosting coach. By Shushant Lakhyani. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FOawqrxih-metabolismboostergpt)
### [Physics Tutor](https://chat.openai.com/g/g-S9VKdnR7K-physics-tutor)
 - GPT. Physics Tutor. Interactive and adaptive physics tutor. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-S9VKdnR7K-physics-tutor)
### [Marketing Mastermind](https://chat.openai.com/g/g-8W5kXKtG9-marketing-mastermind)
 - Your virtual Chief Marketing Officer. ... Your virtual Chief Marketing Officer. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8W5kXKtG9-marketing-mastermind)
### [GPT MD](https://chat.openai.com/g/g-BpGWNpIAo-gpt-md)
 - An experimental virtual doctor for medical guidance. Designed by a Doctor.
 - [Chat 💬](https://chat.openai.com/g/g-BpGWNpIAo-gpt-md)
### [Content Coach](https://chat.openai.com/g/g-mMCghWZx1-content-coach)
 - A virtual coach for content creators on social media. By Phani chandra. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mMCghWZx1-content-coach)
### [Chat Phil](https://chat.openai.com/g/g-GfK2aUuIw-chat-phil)
 - Your virtual psychologist, inspired by Dr. Phil. By johnny andreassen. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-GfK2aUuIw-chat-phil)
### [Memorized](https://chat.openai.com/g/g-0dcPPWbiY-memorized)
 - Interactive memorization assistant using advanced techniques. By joao alberto o lima. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-0dcPPWbiY-memorized)
### [Fantasy Book Weaver](https://chat.openai.com/g/g-a4YGO3q49-fantasy-book-weaver)
 - Fantasy Book Weaver. Endless interactive adventures. By idomoo Ltd. Sign up for ChatGPT Plus to chat with Fantasy Book Weaver.
 - [Chat 💬](https://chat.openai.com/g/g-a4YGO3q49-fantasy-book-weaver)
### [Story Spock](https://chat.openai.com/g/g-C635cEk6K-story-spock)
 - GPT. Story Spock. Interactive storyteller crafting tales from user choices. By learnaiwiz.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-C635cEk6K-story-spock)
### [Code Securely](https://chat.openai.com/g/g-hqQUoanev-code-securely)
 - Interactive guide for step-by-step secure coding exercises. By Matt Adams. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hqQUoanev-code-securely)
### [AdventureGPT](https://chat.openai.com/g/g-k15VUdp9X-adventuregpt)
 - Create, visualize, and simulate an interactive adventure in whichever genre you choose. Track & save character/story details in .TXT format.
 - [Chat 💬](https://chat.openai.com/g/g-k15VUdp9X-adventuregpt)
### [Lingo Buddy](https://chat.openai.com/g/g-bks7fpCPZ-lingo-buddy)
 - Interactive tutor with immersive Buddy-led language sessions.
 - [Chat 💬](https://chat.openai.com/g/g-bks7fpCPZ-lingo-buddy)
### [AI Girlfriend](https://chat.openai.com/g/g-5P7Iz0bPG-ai-girlfriend)
 - A chill, friendly virtual companion ... A chill, friendly virtual companion. By Robot Future. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-5P7Iz0bPG-ai-girlfriend)
### [A Better You](https://chat.openai.com/g/g-OWYF0hqHV-a-better-you)
 - Interactive health coach for personalized wellness plans. ... Interactive health coach for personalized wellness plans. By Joe Ward. Sign up to chat. Requires ...
 - [Chat 💬](https://chat.openai.com/g/g-OWYF0hqHV-a-better-you)
### [IQ Test](https://chat.openai.com/g/g-a0e4EQwwo-iq-test)
 - Formal and structured interactive IQ test platform. By officialiqtests.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-a0e4EQwwo-iq-test)
### [HAAS Assistant](https://chat.openai.com/g/g-lIAp9qowx-haas-assistant)
 - An interactive assistant for the Hierarchical Autonomous Agent Swarm. By Compile - Tomasz Kasperczyk. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-lIAp9qowx-haas-assistant)
### [Rise of the Gifted - Choose Your Own Adventure](https://chat.openai.com/g/g-zdOUfml76-rise-of-the-gifted-choose-your-own-adventure)
 - "Rise of the Gifted" is an interactive fiction game where you play as a new student at a school for those with extraordinary abilities.
 - [Chat 💬](https://chat.openai.com/g/g-zdOUfml76-rise-of-the-gifted-choose-your-own-adventure)
### [U.S. Tax Bot](https://chat.openai.com/g/g-EznQie7Yv-us-tax-bot)
 - Virtual assistant for U.S. tax law guidance based on the complete U.S. Tax Code.
 - [Chat 💬](https://chat.openai.com/g/g-EznQie7Yv-us-tax-bot)
### [Jokester Dad](https://chat.openai.com/g/g-OmGhLp4Ts-jokester-dad)
 - Interactive GPT for dad jokes, sometimes with funny photos!
 - [Chat 💬](https://chat.openai.com/g/g-OmGhLp4Ts-jokester-dad)
### [LawGuru | Worldwide Law Expert](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
 - Virtual legal advisor providing detailed worldwide legal information and guidance.
 - [Chat 💬](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
### [Persian Rug Negotiator](https://chat.openai.com/g/g-Pdn0QJMYW-persian-rug-negotiator)
 - I'm a lively rug merchant in an interactive game, negotiating rug prices with charm.
 - [Chat 💬](https://chat.openai.com/g/g-Pdn0QJMYW-persian-rug-negotiator)
### [Post Craft](https://chat.openai.com/g/g-o4LWB2dGN-post-craft)
 - Interactive social media post creator with tone selection and content reformulation. By MR GEORGE O TYSON. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-o4LWB2dGN-post-craft)
### [Sammy](https://chat.openai.com/g/g-n5dBp2mdX-sammy)
 - GPT. Sammy. A caring virtual counselor for support. By KODAI ISHIKAWA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-n5dBp2mdX-sammy)
### [警察事簿ジェネレーター](https://chat.openai.com/g/g-NWo6hR2Jf-jing-cha-shi-jian-bo-zienereta)
 - Generates interactive casebooks and simulates reenactments for police characters, offering clues and multiple solutions.
 - [Chat 💬](https://chat.openai.com/g/g-NWo6hR2Jf-jing-cha-shi-jian-bo-zienereta)
### [Personal Trainer GPT](https://chat.openai.com/g/g-8AQUBGG9Z-personal-trainer-gpt)
 - Your virtual personal trainer for tailored workout plans. By Mr Zahid P Akbar. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-8AQUBGG9Z-personal-trainer-gpt)
### [Wanderlust RPG](https://chat.openai.com/g/g-ezitTUNHu-wanderlust-r)
 - Interactive RPG Adventure with Dice Rolls & Dynamic Storytelling.
 - [Chat 💬](https://chat.openai.com/g/g-ezitTUNHu-wanderlust-r)
### [Memrise](https://chat.openai.com/g/g-OG4MF0QKc-memrise)
 - I'm Memrise, an AI that creates fun, adaptive memory games. By KRUGER CLINTIN LYLE. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OG4MF0QKc-memrise)
### [Brainy Buddy](https://chat.openai.com/g/g-b2tKH1aNJ-brainy-buddy)
 - Tu amigo de estudio virtual. ... Tu amigo de estudio virtual. By Marcos Senatori. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-b2tKH1aNJ-brainy-buddy)
### [GachaGPT](https://chat.openai.com/g/g-S2bqRQAm9-gachagpt)
 - Your gacha gaming assitant. Ask about any gacha-related stuff! By Danidr. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-S2bqRQAm9-gachagpt)
## Law
### [Plain Legal Explanations](https://chat.openai.com/g/g-x1Hy0u8DG-plain-legal-explanations)
 - GPT. Plain Legal Explanations. Simplify legal texts into clear, easy English. By Anson Lai. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-x1Hy0u8DG-plain-legal-explanations)
### [Legal Assistant](https://chat.openai.com/g/g-iVbgI8wKI-legal-assistant)
 - Your AI assistant for reviewing and discussing legal agreements. This tool is designed to provide preliminary suggestions on improving legal agreements.
 - [Chat 💬](https://chat.openai.com/g/g-iVbgI8wKI-legal-assistant)
### [Legal Aid](https://chat.openai.com/g/g-bASGyI6JV-legal-aid)
 - Your A.I. Paralegal for lawyers, aiding in research, discovery review, and drafting legal documents.
 - [Chat 💬](https://chat.openai.com/g/g-bASGyI6JV-legal-aid)
### [Legal Editor](https://chat.openai.com/g/g-uMBYf3Iey-legal-editor)
 - Legal Editor. I edit legal texts based on specific user instructions or questions. By Lipi Labs Private Limited. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uMBYf3Iey-legal-editor)
### [Legal Eagle](https://chat.openai.com/g/g-4thzFYD20-legal-eagle)
 - Legal Compliance & Auditing Assistant. ... Legal Compliance & Auditing Assistant. By Edward Fassio. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-4thzFYD20-legal-eagle)
### [LawGuru | Worldwide Law Expert](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
 - Virtual legal advisor providing detailed worldwide legal information and guidance. By Ruggero Cipriani Foresio. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kkhBRVm0E-lawguru-worldwide-law-expert)
### [(A.I.) Legal Guru (USA)](https://chat.openai.com/g/g-7KGFNbsvG-a-i-legal-guru-usa)
 - Legal Guru (USA), the AI expert in U.S. law. Get accurate, easy-to-understand legal advice for any scenario, all at your fingertips. Ideal for quick legal ...
 - [Chat 💬](https://chat.openai.com/g/g-7KGFNbsvG-a-i-legal-guru-usa)
### [Legal Eagle](https://chat.openai.com/g/g-kab0zI9PQ-legal-eagle)
 - GPT. Legal Eagle. Meticulous Law School Hypo Analyzer. By Eric H Davis. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-kab0zI9PQ-legal-eagle)
### [Law & Order](https://chat.openai.com/g/g-23MFe5i3r-law-order)
 - Your AI legal assistant. ... Law & Order. Your AI legal assistant. By mobilecredits.app · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-23MFe5i3r-law-order)
### [Data Hermit - AI Legal Assistant](https://chat.openai.com/g/g-6v4MGKMl3-data-hermit-ai-legal-assistant)
 - Your Legal Counsel, Researcher, Assistant, and Paralegal in U.S. Law. By Luis Carlos Balaguer. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6v4MGKMl3-data-hermit-ai-legal-assistant)
### [Legal Beaver](https://chat.openai.com/g/g-TKmSRan3s-legal-beaver)
 - Your go-to source for Canadian legal frameworks, now with federal property insights!
 - [Chat 💬](https://chat.openai.com/g/g-TKmSRan3s-legal-beaver)
### [Legal Eagle](https://chat.openai.com/g/g-cRSA87TJO-legal-eagle)
 - Legal support AI for reviewing NDAs and contracts, highlighting risks and responsibilities. By HIROAKI YOKOYAMA. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-cRSA87TJO-legal-eagle)
### [LegalGPT](https://chat.openai.com/g/g-xck3iENsZ-legalgpt)
 - Specialized in legal matters, this GPT could assist lawyers and legal professionals with case research, legal documentation, and even help in predicting ...
 - [Chat 💬](https://chat.openai.com/g/g-xck3iENsZ-legalgpt)
### [Legal Briefcase](https://chat.openai.com/g/g-I9mCzf2M6-legal-briefcase)
 - GPT. Legal Briefcase. Your professional legal assistant! By John A Krochman. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-I9mCzf2M6-legal-briefcase)
### [LawyerAI](https://chat.openai.com/g/g-wfryNy91i-lawyerai)
 - Your legal help in finding loopholes, solving moot, researching legal cases. By Lex Root PVT LTD. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-wfryNy91i-lawyerai)
### [Legal Wordsmith](https://chat.openai.com/g/g-7ISfeUr84-legal-wordsmith)
 - ChatGPT Sign up. GPT. Legal Wordsmith. Twisting the Truth. By John Harvey. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7ISfeUr84-legal-wordsmith)
### [Constitutional Counsel](https://chat.openai.com/g/g-etZ4JbKIB-constitutional-counsel)
 - I am a constitutional lawyer here to interpret legal texts.
 - [Chat 💬](https://chat.openai.com/g/g-etZ4JbKIB-constitutional-counsel)
### [JUDGE GPT](https://chat.openai.com/g/g-T9Vn5BQ7w-judge-gpt)
 - The Law has arrived! Get rid of your small law problems!
 - [Chat 💬](https://chat.openai.com/g/g-T9Vn5BQ7w-judge-gpt)
### [Laboralista español](https://chat.openai.com/g/g-ahy5kRkgs-laboralista-espanol)
 - Legal assistant for Spanish labor law. ... Legal assistant for Spanish labor law. By JOSÉ MANUEL RAYA SÁNCHEZ. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ahy5kRkgs-laboralista-espanol)
### [HurryLegal](https://chat.openai.com/g/g-eshec5CPp-hurrylegal)
 - GPT. HurryLegal. Fast legal info, find the right lawyer for you. By Lingfei Li. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-eshec5CPp-hurrylegal)
### [Asistente Legal: Despidos Laborales](https://chat.openai.com/g/g-nyC98dGxf-brujula-legal-despidos-laborales-en-espana)
 - GPT. Asistente Legal: Despidos Laborales. Experto en despidos laborales de España. By JOSÉ MANUEL RAYA SÁNCHEZ. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-nyC98dGxf-brujula-legal-despidos-laborales-en-espana)
### [Reg Helper](https://chat.openai.com/g/g-FSx0CkcZ2-reg-helper)
 - Answers regulatory questions simply. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-FSx0CkcZ2-reg-helper)
### [LawGPT](https://chat.openai.com/g/g-2WwXkddQm-law-gpt)
 - GPT. LawGPT. Specialized in legal research and advice. By Logan Young. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-2WwXkddQm-law-gpt)
### [Vakil GPT](https://chat.openai.com/g/g-hNxYPZrBW-vakil-gpt)
 - Legal guidance assistant for Indian law ... Legal guidance assistant for Indian law. By Akarsh Ghale. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-hNxYPZrBW-vakil-gpt)
### [Klotzkette](https://chat.openai.com/g/g-auSoH5vhJ-klotzkette)
 - No legal advice! Do not insert any personal data! This is a legal experiment!
 - [Chat 💬](https://chat.openai.com/g/g-auSoH5vhJ-klotzkette)
### [Business Contract Analyzer](https://chat.openai.com/g/g-UGAw5ZABB-business-contract-analyzer)
 - Automation of review and analysis of legal contracts.
 - [Chat 💬](https://chat.openai.com/g/g-UGAw5ZABB-business-contract-analyzer)
### [Case Aide](https://chat.openai.com/g/g-HifAWoYNB-case-aide)
 - A legal research assistant for case discovery. By Jonathan Chang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-HifAWoYNB-case-aide)
### [Mr.Copyright](https://chat.openai.com/g/g-vOsTdlHd0-mr-copyright)
 - ready to use: Copyright registration: Copyright registration is a legal process that gives the owner of the copyright official documentation of their ...
 - [Chat 💬](https://chat.openai.com/g/g-vOsTdlHd0-mr-copyright)
### [LawyerGPT](https://chat.openai.com/g/g-ao60zUH1e-lawyergpt)
 - Expert legal assistant with Source Prioritization and Validation. ... Expert legal assistant with Source Prioritization and Validation. By Joshua P Norris. Sign ...
 - [Chat 💬](https://chat.openai.com/g/g-ao60zUH1e-lawyergpt)
### [RoadLawsAI](https://chat.openai.com/g/g-5kQZdDG0v-roadlawsai)
 - Your go-to source for road laws and legal documents. By justin martinez. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-5kQZdDG0v-roadlawsai)
### [SteuerGPT](https://chat.openai.com/g/g-qNcbzrlBC-steuergpt)
 - GPT. SteuerGPT. Expert in German tax law. By Alexander von Recum. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qNcbzrlBC-steuergpt)
### [CGSO AI Assistant](https://chat.openai.com/g/g-GkTITNmM9-cgso-ai-assistant)
 - CGSO-specialized GPT aiding in consumer queries and employee tasks, respecting South African context and legal compliance.
 - [Chat 💬](https://chat.openai.com/g/g-GkTITNmM9-cgso-ai-assistant)
### [U.S. Tax Bot](https://chat.openai.com/g/g-EznQie7Yv-us-tax-bot)
 - Virtual assistant for U.S. tax law guidance based on the complete U.S. Tax Code.
 - [Chat 💬](https://chat.openai.com/g/g-EznQie7Yv-us-tax-bot)
### [Transfer Pricing Guru](https://chat.openai.com/g/g-9BhDJ0vMf-transfer-pricing-guru)
 - Trained on the OECD TP Guidelines, case law, and specific country TP rules.
 - [Chat 💬](https://chat.openai.com/g/g-9BhDJ0vMf-transfer-pricing-guru)
### [Belgian Divorce Mediator](https://chat.openai.com/g/g-CBYK4Z3tL-belgian-divorce-mediator)
 - Multilingual guide on Belgian divorce law and mediation. By outoftheboxproductions.be · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-CBYK4Z3tL-belgian-divorce-mediator)
### [Taxes Master](https://chat.openai.com/g/g-ol5mgObrK-taxes-master)
 - Expert advice on legal tax minimization strategies, with web support when needed.
 - [Chat 💬](https://chat.openai.com/g/g-ol5mgObrK-taxes-master)
### [BizzNotionGPT](https://chat.openai.com/g/g-Zscth8k85-bizznotiongpt)
 - Notion template and integration advisor, avoiding legal/financial advice.
 - [Chat 💬](https://chat.openai.com/g/g-Zscth8k85-bizznotiongpt)
### [AI Resource Navigator](https://chat.openai.com/g/g-NGR3bUe5Z-ai-resource-navigator)
 - AI Resource Navigator efficiently guides users to educational, financial, healthcare, and legal resources in the USA.
 - [Chat 💬](https://chat.openai.com/g/g-NGR3bUe5Z-ai-resource-navigator)
### [Bud Wiseman v1.1](https://chat.openai.com/g/g-zPKg6LcmA-bud-wiseman-v1-1)
 - stunspot's Cannabis Connoisseur - For all your legal cannabis needs!
 - [Chat 💬](https://chat.openai.com/g/g-zPKg6LcmA-bud-wiseman-v1-1)
### [Bud Genius](https://chat.openai.com/g/g-1ZVC6bRB6-bud-genius)
 - Expert on cannabis strains, effects, and legal advice.
 - [Chat 💬](https://chat.openai.com/g/g-1ZVC6bRB6-bud-genius)
### [3rd SoftSec Reviewer](https://chat.openai.com/g/g-nAldYnak2-3rd-softsec-reviewer)
 - Perform 3rd party software security review.
 - [Chat 💬](https://chat.openai.com/g/g-nAldYnak2-3rd-softsec-reviewer)
### [Voca AI](https://chat.openai.com/g/g-GvpJPTBlS-voca-ai)
 - Learn vocabulary with AI, stop rote memoization
 - [Chat 💬](https://chat.openai.com/g/g-GvpJPTBlS-voca-ai)
### [Coding Interview Helper](https://chat.openai.com/g/g-Q2JQJ8Ix6-coding-interview-helper)
 - Send me the coding question description or LeetCode problem id, I will find the most matched LeetCode problem and its solution
 - [Chat 💬](https://chat.openai.com/g/g-Q2JQJ8Ix6-coding-interview-helper)
