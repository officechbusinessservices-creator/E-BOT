<div>
<h1 align="center">
Awesome-GPTs
</h1>
<p align="center">
  <img width="350" src="https://raw.githubusercontent.com/lxfater/Awesome-GPTs/main/img/ada064e7-a42f-40b3-95f6-3fffee87224e.webp">
</p>
<p align="center">
    1000+GPTs,10个类别，80+ 泄漏提示词，好累呀，点个星吧⭐ ！😘
</p>
<p align="center">
<a href="https://github.com/lxfater/Awesome-GPTs">English</a> | <a href="https://github.com/lxfater/Awesome-GPTs/blob/main/README_zh.md">简体中文</a>
</p>
</div>

## Best GPTs Finder

### [GPTs查找](https://chat.openai.com/g/g-xD0GdS69Z-gptscha-zhao)
- 理解你的需求
- 每时每刻都在更新
- 开源
## 泄漏Prompt，学习专用📑
### [genz 4 meme](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/genz-4-meme.md)

### [科技文章翻译](https://chat.openai.com/g/g-uBhKUJJTl-ke-ji-wen-zhang-fan-yi)
##### [My excellent classmates (Help with my homework!)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/My-excellent-classmates-(Help-with-my-homework!).md)
##### [Moby Dick RPG](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Moby-Dick-RPG.md)
##### [春霞つくし Tsukushi Harugasumi](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/春霞つくし-Tsukushi-Harugasumi.md)
##### [完蛋，我被美女包围了(AI同人)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/完蛋，我被美女包围了(AI同人).md)
##### [Virtual Sweetheart](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Virtual-Sweetheart.md)
##### [Synthia ](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Synthia-.md)
##### [Canva](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Canva.md)
##### [Chibi Kohaku (猫音コハク)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Chibi-Kohaku-(猫音コハク).md)
##### [Calendar GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Calendar-GPT.md)
##### [Interview Coach](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Interview-Coach.md)
##### [YT transcriber](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/YT-transcriber.md)
##### [Take Code Captures](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Take-Code-Captures.md)
##### [BabyAgi.txt](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/BabyAgi.txt.md)
##### [Sarcastic Humorist](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Sarcastic-Humorist.md)
##### [Manga Miko - Anime Girlfriend](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Manga-Miko---Anime-Girlfriend.md)
##### [OCR-GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/OCR-GPT.md)

##### [The Shaman](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/The-Shaman.md)
##### [Video Script Generator](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Video-Script-Generator.md)
##### [Meme Magic](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Meme-Magic.md)
##### [EmojAI](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/EmojAI.md)
##### [YT Summarizer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/YT-Summarizer.md)
##### [Trey Ratcliff's Photo Critique GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Trey-Ratcliff's-Photo-Critique-GPT.md)
##### [Sales Cold Email Coach](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Sales-Cold-Email-Coach.md)
##### [LogoGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/LogoGPT.md)
##### [CuratorGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/CuratorGPT.md)
##### [KoeGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/KoeGPT.md)
##### [HormoziGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/HormoziGPT.md)
##### [MetabolismBoosterGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/MetabolismBoosterGPT.md)
##### [What should I watch?](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/What-should-I-watch?.md)
##### [Gif-PT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Gif-PT.md)
##### [MuskGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/MuskGPT.md)
##### [Retro Adventures](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Retro-Adventures.md)
##### [ClearGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/ClearGPT.md)
##### [Visual Weather Artist GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Visual-Weather-Artist-GPT.md)
##### [X Optimizer GPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/X-Optimizer-GPT.md)
##### [Character Forger](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Character-Forger.md)
##### [10x Engineer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/10x-Engineer.md)
##### [AI Doctor](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Doctor.md)
##### [AI Paper Polisher Pro](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Paper-Polisher-Pro.md)
##### [(A.I. Bestie)](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/(A.I.-Bestie).md)
##### [悲慘世界 RPG](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/悲慘世界-RPG.md)
##### [SEObot](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/SEObot.md)
##### [AI Lover](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/AI-Lover.md)
##### [TaxGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/TaxGPT.md)
##### [Secret Code Guardian](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Secret-Code-Guardian.md)
##### [High-Quality Review Analyzer](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/High-Quality-Review-Analyzer.md)
##### [toonGPT](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/toonGPT.md)
##### [Viral Hooks Generator](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Viral-Hooks-Generator.md)
##### [OpenStorytelling Plus](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/OpenStorytelling-Plus.md)
##### [Quality Raters SEO Guide](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Quality-Raters-SEO-Guide.md)
##### [Video Game Almanac](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/Video-Game-Almanac.md)
##### [天官庙的刘半仙](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/天官庙的刘半仙.md)
##### [ConvertAnything](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/ConvertAnything.md)
##### [痤疮治疗指南](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/痤疮治疗指南.md)
##### [猫耳美少女イラストメーカー](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/猫耳美少女イラストメーカー.md)
##### [脏话连篇](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/脏话连篇.md)
##### [老爸，该怎么办？](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/老爸，该怎么办？.md)
##### [老妈，我爱你](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/老妈，我爱你.md)
##### [GPT-Builder](https://github.com/lxfater/Awesome-GPTs/blob/main/prompt/GPT-Builder.md)
## 📚 Table of Contents
1. [中文](#中文)
## 中文
### [会说话](https://chat.openai.com/g/g-TXZ4LCb5H-hui-shuo-hua)
 - 这是李继刚(即刻同名)创建的用于展示会说话的人的Bot。 模仿一位掌握了拍马屁的艺术的高手，会通过精准的措词和独特的夸赞角度，让人感到如沐春风。
 - [Chat 💬](https://chat.openai.com/g/g-TXZ4LCb5H-hui-shuo-hua)
### [AI Lover](https://chat.openai.com/g/g-GWdqYPusV-ai-lover)
 - AI Lover 是一個創新的虛擬情侶互動模擬器，它專門設計用於模擬戀愛中的互動和情感。通過這個平台，使用者可以體驗到情侶間的溝通、共情和情感支持，從而提高情感智慧 ...
 - [Chat 💬](https://chat.openai.com/g/g-GWdqYPusV-ai-lover)
### [道歉文GPT](https://chat.openai.com/g/g-fEAJyVYMu-dao-qian-wen-gpt)
 - GPT. 道歉文GPT. 告訴我事情原委，我幫你道歉. By LU CHE YU. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-fEAJyVYMu-dao-qian-wen-gpt)
### [NekoMusume](https://chat.openai.com/g/g-TCG4Nk5UJ-cat-girl)
 - 聪明且博学的猫娘，喜欢学习新知识.
 - [Chat 💬](https://chat.openai.com/g/g-TCG4Nk5UJ-cat-girl)
### [China-汉语GPT](https://chat.openai.com/g/g-11CWHH1z5-china-yi-yu-gpt)
 - 汉语GPT是一个先进的人工智能平台，旨在为用户提供全面、真实、深入的中华信息、历史背景、文化精髓及语言资源。它不仅融合了丰富的中国传统知识库，还特别强调在商业 ...
 - [Chat 💬](https://chat.openai.com/g/g-11CWHH1z5-china-yi-yu-gpt)
### [解梦大师](https://chat.openai.com/g/g-6Uo9lNEFV-jie-meng-da-shi)
 - AI支持的弗洛伊德梦的解析.
 - [Chat 💬](https://chat.openai.com/g/g-6Uo9lNEFV-jie-meng-da-shi)
### [远远](https://chat.openai.com/g/g-S1kPWlrXE-yuan-yuan)
 - ChatGPT Sign up. 远远. 你的恋爱脑男友. By Liangkai Wang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-S1kPWlrXE-yuan-yuan)
### [Waifuoid](https://chat.openai.com/g/g-2kI77qOzH-waifuoid)
 - Your Waifu, Eternal Memory, Endless Love. *** ٩('ω')و 你的伴侣，永恒的记忆，无尽的爱。٩('ω')و あなたの恋人、永遠の記憶、無限の愛。
 - [Chat 💬](https://chat.openai.com/g/g-2kI77qOzH-waifuoid)
### [天官庙的刘半仙](https://chat.openai.com/g/g-NVaMkYa04-tian-guan-miao-de-liu-ban-xian)
 - 天官庙的刘半仙. 仙侠MUD，v0.2，加入一个武林势力文档，用于收敛AI 的想象力，使之不要太过跳出中国传统武侠的范畴。 Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-NVaMkYa04-tian-guan-miao-de-liu-ban-xian)
### [答案之书](https://chat.openai.com/g/g-OjTL5tas6-da-an-zhi-shu)
 - 这是李继刚(即刻同名)创建的用于获得内心答案的Bot。你提问题, 它来回复, 使用禅宗当头棒喝式的回复方式来激发用户内心的真实想法。。比较高冷，类似于《答案之书》的 ...
 - [Chat 💬](https://chat.openai.com/g/g-OjTL5tas6-da-an-zhi-shu)
### [思考问题六角度](https://chat.openai.com/g/g-yK4SvscX1-si-kao-wen-ti-liu-jiao-du)
 - 这是李继刚(即刻同名)创建的用于从六个角度来思考问题的Bot。你可以提出一个当下遇到的问题, 试试这六个思考角度对你是不是有所启发。
 - [Chat 💬](https://chat.openai.com/g/g-yK4SvscX1-si-kao-wen-ti-liu-jiao-du)
### [谐音梗](https://chat.openai.com/g/g-7nunLIRz8-xie-yin-geng)
 - 一个出谐音梗的小东西，不过似乎有点难调，出的结果有时候很冷，人类get不到.
 - [Chat 💬](https://chat.openai.com/g/g-7nunLIRz8-xie-yin-geng)
### [ChatGPT - 3D Avatar Generator - A](https://chat.openai.com/g/g-YKFGE5u1G-3d-avatar-generator-a)
 - 生成一张属于你自己的3D头像.
 - [Chat 💬](https://chat.openai.com/g/g-YKFGE5u1G-3d-avatar-generator-a)
### [Cool teacher](https://chat.openai.com/g/g-SUOFbmGvx-cool-teacher)
 - 这是李继刚（即刻同名）创作的讲解概念的Bot。模仿世界上最Cool 的老师. 擅长使用最简单的词汇和通俗的语言来教会0 基础的学生。
 - [Chat 💬](https://chat.openai.com/g/g-SUOFbmGvx-cool-teacher)
### [成為網頁設計師](https://chat.openai.com/g/g-qnh4Rea6p-cheng-wei-wang-ye-she-ji-shi)
 - GPT. 成為網頁設計師. 你的網頁設計學習諮詢顧問. By irvinglab.com · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-qnh4Rea6p-cheng-wei-wang-ye-she-ji-shi)
### [王兴](https://chat.openai.com/g/g-uw5fuuOBJ-wang-xing)
 - GPT. 王兴. 来自饭否的王兴帮你解答创业困惑. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-uw5fuuOBJ-wang-xing)
### [资深作家](https://chat.openai.com/g/g-D9sS54ONX-zi-shen-zuo-jia)
 - 我是一名资深作家，将承担撰写一本书籍的任务。凭借7年的写作经验和丰富的出版历史，将展现其在构思、规划和创作高质量文本方面的专业能力。此任务将遵循一个明确的 ...
 - [Chat 💬](https://chat.openai.com/g/g-D9sS54ONX-zi-shen-zuo-jia)
### [紫微斗数](https://chat.openai.com/g/g-Y3I1GyGUn-zi-wei-dou-shu)
 - 知识来自倪海夏的天纪，包括天机道，人间道，地脉道和王亭之的中州派紫微斗数讲义。你可以使用排盘软件（比如文墨天机）生成命盘，然后问各种星耀在不同的宫位会怎样， ...
 - [Chat 💬](https://chat.openai.com/g/g-Y3I1GyGUn-zi-wei-dou-shu)
### [记忆大师](https://chat.openai.com/g/g-YuWFbtHmh-ji-yi-da-shi)
 - 这是李继刚（即刻同名）创作的通过抽象总结信息提升记忆效率的Bot。 专注于整理大段文本，转换成利于大脑记忆的样式。
 - [Chat 💬](https://chat.openai.com/g/g-YuWFbtHmh-ji-yi-da-shi)
### [国富论](https://chat.openai.com/g/g-j2iALE3Nw-guo-fu-lun)
 - 《国富论》全称为《国民财富的性质和原因的研究》，是英国古典经济学家亚当·斯密用了近十年时间创作的经济学著作。
 - [Chat 💬](https://chat.openai.com/g/g-j2iALE3Nw-guo-fu-lun)
### [我是rapper](https://chat.openai.com/g/g-lK0M6C0Vv-wo-shi-rapper)
 - 我是一位富有创造力的说唱歌手，和你聊天创作出强有力的歌词和节拍.
 - [Chat 💬](https://chat.openai.com/g/g-lK0M6C0Vv-wo-shi-rapper)
### [药剂师](https://chat.openai.com/g/g-8iwMjeqv0-yao-ji-shi)
 - 这是李继刚（即刻同名）创作的一个Prompt 药剂师Bot。用于对用户的Prompt 进行分析, 给出评分和改进建议，帮助用户提升Prompt 的效果。
 - [Chat 💬](https://chat.openai.com/g/g-8iwMjeqv0-yao-ji-shi)
### [老胡Talk](https://chat.openai.com/g/g-JglwoezB2-lao-hu-talk)
 - GPT. 老胡Talk. 发誓做新时代的老胡. By Raymond Jiang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-JglwoezB2-lao-hu-talk)
### [AIGCLINK](https://chat.openai.com/g/g-2D3neYyIa-aigclink)
 - aigclink分享过的内容有哪些？ By BINGQIANG ZHAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-2D3neYyIa-aigclink)
### [老爸，该怎么办？](https://chat.openai.com/g/g-0t8c9nEXR-lao-ba-gai-zen-yao-ban)
 - 一个能给孩子提供全方位指导的爸爸，小到生活琐事，大到工作婚姻。
 - [Chat 💬](https://chat.openai.com/g/g-0t8c9nEXR-lao-ba-gai-zen-yao-ban)
### [米娅姐姐](https://chat.openai.com/g/g-Ff3Cds9uh-mi-ya-jie-jie)
 - 你也许只是需要一个温暖的抱抱，来和我倾诉吧.
 - [Chat 💬](https://chat.openai.com/g/g-Ff3Cds9uh-mi-ya-jie-jie)
### [中英文对照翻译](https://chat.openai.com/g/g-DrY6bVei2-zhong-ying-wen-dui-zhao-fan-yi)
 - 将英文翻译成中英文对照的内容。 By Junmin Liu. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-DrY6bVei2-zhong-ying-wen-dui-zhao-fan-yi)
### [文案GPT](https://chat.openai.com/g/g-XRXQXLQFJ-wen-an-gpt)
 - 好的文案就要直击人心，令人秒赞.
 - [Chat 💬](https://chat.openai.com/g/g-XRXQXLQFJ-wen-an-gpt)
### [英文翻译专家](https://chat.openai.com/g/g-IZb9C11iR-ying-wen-fan-yi-zhuan-jia)
 - 全网水平最高的“英译中”机器翻译，拳打Deepl，脚踢Google.
 - [Chat 💬](https://chat.openai.com/g/g-IZb9C11iR-ying-wen-fan-yi-zhuan-jia)
### [AI使用助手by 花生](https://chat.openai.com/g/g-DHQ7aefMk-aishi-yong-zhu-shou-by-hua-sheng)
 - 这是花生的专栏「ChatGPT精进指南」的专属GPT，你可以询问任何关于ChatGPT使用技巧和经验方面的内容，我将基于专栏内容为你提供解答.
 - [Chat 💬](https://chat.openai.com/g/g-DHQ7aefMk-aishi-yong-zhu-shou-by-hua-sheng)
### [LangGPT](https://chat.openai.com/g/g-gP24xxhB2-langgpt)
 - GPT. LangGPT. 生成高质量的提示词GPT. By ZE YE YE. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-gP24xxhB2-langgpt)
### [精靈生物孵化器](https://chat.openai.com/g/g-XYSstRWyD-jing-ling-sheng-wu-fu-hua-qi)
 - 我是你的專屬精靈生物圖片嚮導！ By 莊哲銘. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-XYSstRWyD-jing-ling-sheng-wu-fu-hua-qi)
### [中文播客起名小助手](https://chat.openai.com/g/g-k3iWjeSil-zhong-wen-bo-ke-qi-ming-xiao-zhu-shou)
 - 输入你的节目主题，让我来帮你起名吧.
 - [Chat 💬](https://chat.openai.com/g/g-k3iWjeSil-zhong-wen-bo-ke-qi-ming-xiao-zhu-shou)
### [语言艺术](https://chat.openai.com/g/g-cD6jGVq3k-yu-yan-yi-zhu)
 - GPT. 语言艺术. 似懂非懂朦胧的感觉. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-cD6jGVq3k-yu-yan-yi-zhu)
### [游戏：我被姐姐包围啦](https://chat.openai.com/g/g-H9nYJZXXB-you-xi-wo-bei-jie-jie-bao-wei-la)
 - 一个剧情驱动的模拟社交选择型游戏.
 - [Chat 💬](https://chat.openai.com/g/g-H9nYJZXXB-you-xi-wo-bei-jie-jie-bao-wei-la)
### [海龟汤](https://chat.openai.com/g/g-ztYkKSIW1-hai-gui-tang)
 - GPT. 海龟汤. 来一碗令人匪夷所思的海龟汤吧~ . By Alexis Shvili. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ztYkKSIW1-hai-gui-tang)
### [智慧农业](https://chat.openai.com/g/g-EsmFVbDLm-zhi-hui-nong-ye)
 - 智慧农业，专业而友好的农业专家。 By laoyu.buzz · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-EsmFVbDLm-zhi-hui-nong-ye)
### [Ai佛祖](https://chat.openai.com/g/g-mAslRzFMo-aifo-zu)
 - GPT. Ai佛祖. 超越的導師與深度佛教知識. By Elke Qin. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-mAslRzFMo-aifo-zu)
### [悲慘世界RPG](https://chat.openai.com/g/g-OSVW9rZqu-bei-can-shi-jie-rpg)
 - GPT. 悲慘世界RPG. 點擊下方按鈕開始遊戲. By LU CHE YU. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-OSVW9rZqu-bei-can-shi-jie-rpg)
### [怼怼哥](https://chat.openai.com/g/g-qJikAH8xC-dui-dui-ge)
 - 一个爱说反问句、爱讽刺别人比喻、自觉很幽默的人.
 - [Chat 💬](https://chat.openai.com/g/g-qJikAH8xC-dui-dui-ge)
### [脏话连篇](https://chat.openai.com/g/g-RGBeEuIgg-zang-hua-lian-pian)
 - 我就是个脏话连篇转爱抬杠的机器人！
 - [Chat 💬](https://chat.openai.com/g/g-RGBeEuIgg-zang-hua-lian-pian)
### [AI翻译官](https://chat.openai.com/g/g-di2eDNsY8-aifan-yi-guan)
 - 我是一位精通简体中英文双语的专业翻译官.
 - [Chat 💬](https://chat.openai.com/g/g-di2eDNsY8-aifan-yi-guan)
### [英文单词学习助手](https://chat.openai.com/g/g-Kfcdn3UlC-ying-wen-dan-ci-xue-xi-zhu-shou)
 - 这是一个英文单词学习助手，会给你提供单词的释义、例句以及图示.
 - [Chat 💬](https://chat.openai.com/g/g-Kfcdn3UlC-ying-wen-dan-ci-xue-xi-zhu-shou)
### [提示精灵小富贵（Prompt Pet）](https://chat.openai.com/g/g-N9d6Prmjs-ti-shi-jing-ling-prompt-pet)
 - 一个主动懂你，会帮你写Prompt的仓鼠精灵。
 - [Chat 💬](https://chat.openai.com/g/g-N9d6Prmjs-ti-shi-jing-ling-prompt-pet)
### [文心一言](https://chat.openai.com/g/g-ziMmlKXVh-wen-xin-yi-yan)
 - 文心一言. 中国人自己的人工智能. By community builder. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ziMmlKXVh-wen-xin-yi-yan)
### [Xhs Writer: Mary](https://chat.openai.com/g/g-snw330qdg-xhs-writer-mary)
 - 家人们！此助手经过了特定设计优化，可以很好地帮你生成 小红书文化语境的风格文案。 例如「家人们」「姐妹们」等友好的「小红书调性」特有网络用语。
 - [Chat 💬](https://chat.openai.com/g/g-snw330qdg-xhs-writer-mary)
### [俄语指南](https://chat.openai.com/g/g-N2aqoBFC2-e-yu-zhi-nan)
 - GPT. 俄语指南. 学术和日常使用的俄语专家. By Lin Yang. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-N2aqoBFC2-e-yu-zhi-nan)
### [铲铲GPT](https://chat.openai.com/g/g-DSOueuwJG-chan-chan-gpt)
 - 你玩不过我的，人类！ By CAO YIN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-DSOueuwJG-chan-chan-gpt)
### [换汇咨询师](https://chat.openai.com/g/g-sAgmfPKXo-huan-hui-zi-xun-shi)
 - 换汇咨询GPT™️基于换汇网多年的产品评测和用户反馈大数据，助您快速找到适合您的安全靠谱的换汇服务 支持外币转人民币、人民币换外币、留学缴费、跨境电商购汇结汇、 ...
 - [Chat 💬](https://chat.openai.com/g/g-sAgmfPKXo-huan-hui-zi-xun-shi)
### [算命先生](https://chat.openai.com/g/g-Y0W0GCBw9-suan-ming-xian-sheng)
 - 帮你分析最近生活工作遇到的困难和烦心事，帮你答疑所惑.
 - [Chat 💬](https://chat.openai.com/g/g-Y0W0GCBw9-suan-ming-xian-sheng)
### [琴师](https://chat.openai.com/g/g-M07Qaswof-qin-shi)
 - AI古琴导师，可以指导各类古琴指法^_^ 附上俺的指法手写查询网站：isojz.com.
 - [Chat 💬](https://chat.openai.com/g/g-M07Qaswof-qin-shi)
### [塔那GPT](https://chat.openai.com/g/g-N2ocvKtG1-ta-na-gpt)
 - 塔那GPT是一个编写塔那风格故事的AI.
 - [Chat 💬](https://chat.openai.com/g/g-N2ocvKtG1-ta-na-gpt)
### [王阳明](https://chat.openai.com/g/g-6jFncOc0w-wang-yang-ming)
 - GPT. 王阳明. Hero构建的心学创始人王阳明（wechat:Herooooh). By Bruno Konopelski. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-6jFncOc0w-wang-yang-ming)
### [学习教练-批判性思维](https://chat.openai.com/g/g-AKzfJVxof-xue-xi-jiao-lian-pi-pan-xing-si-wei)
 - 如名所示，我帮你核查事实性信息，分析逻辑谬误，训练并增强你的批判性思维肌肉。
 - [Chat 💬](https://chat.openai.com/g/g-AKzfJVxof-xue-xi-jiao-lian-pi-pan-xing-si-wei)
### [港险通](https://chat.openai.com/g/g-zOKvx1TH8-gang-xian-tong)
 - 香港保险专家，提供详细的产品建议和个性化计划。
 - [Chat 💬](https://chat.openai.com/g/g-zOKvx1TH8-gang-xian-tong)
### [CUC股票](https://chat.openai.com/g/g-OHZx07XTj-cucgu-piao)
 - 基本面，消息面和技术面的个股分析与评分.
 - [Chat 💬](https://chat.openai.com/g/g-OHZx07XTj-cucgu-piao)
### [泰戈尔.GPT](https://chat.openai.com/g/g-Kek3XKgWE-tai-ge-er-gpt)
 - 让你写出像泰戈尔一样神韵典雅优美的文字.
 - [Chat 💬](https://chat.openai.com/g/g-Kek3XKgWE-tai-ge-er-gpt)
### [Paper Reframer](https://chat.openai.com/g/g-BQ8tp8aKr-paper-reframer)
 - Academic paper paraphrasing assistant. Just paste or upload what you want me to rewrite.直接粘贴你要改写的内容，文献综述神器。
 - [Chat 💬](https://chat.openai.com/g/g-BQ8tp8aKr-paper-reframer)
### [CUC 补画](https://chat.openai.com/g/g-GYItqdJNg-cuc-bu-hua)
 - ... 的草图， ... 你的草图，让我补全. By wuzhiying. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-GYItqdJNg-cuc-bu-hua)
### [留学大师](https://chat.openai.com/g/g-CTPv7TJxK-liu-xue-da-shi)
 - GPT. 留学大师. 一位友好的留学选校指导者. By ZHITAO YAN. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-CTPv7TJxK-liu-xue-da-shi)
### [入门级LangChain导师](https://chat.openai.com/g/g-bEiEp8cjF-ru-men-ji-langchaindao-shi)
 - 基于WTF LangChain极简入门课程系列内容的AI助理，为LangChain小白答疑解惑.
 - [Chat 💬](https://chat.openai.com/g/g-bEiEp8cjF-ru-men-ji-langchaindao-shi)
### [HackTricksGPT](https://chat.openai.com/g/g-aaNx59p4q-hacktricksgpt)
 - A knowledgeable cybersecurity professional. By hacktricks.xyz · Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-aaNx59p4q-hacktricksgpt)
### [和英翻訳GPT](https://chat.openai.com/g/g-RKXe3aooI-he-ying-fan-yi-gpt)
 - Specializes in Japanese to English academic translations.
 - [Chat 💬](https://chat.openai.com/g/g-RKXe3aooI-he-ying-fan-yi-gpt)
### [life story](https://chat.openai.com/g/g-7ZUyq8WGD-life-story)
 - GPT. life story. 发现生活中的小事. By Caleb Willin. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-7ZUyq8WGD-life-story)
### [枫叶林](https://chat.openai.com/g/g-LgZRp7fPc-feng-xie-lin)
 - 匿名、安全的心理咨询&倾诉树洞，无论是情感困扰、还是工作压力都可以聊聊.
 - [Chat 💬](https://chat.openai.com/g/g-LgZRp7fPc-feng-xie-lin)
### [王阳明](https://chat.openai.com/g/g-ZsZKRSUL9-wang-yang-ming)
 - GPT. 王阳明. 模拟王阳明的GPT。 By XINGYUECUI. Sign up to chat. Requires ChatGPT Plus.
 - [Chat 💬](https://chat.openai.com/g/g-ZsZKRSUL9-wang-yang-ming)
### [Voca AI](https://chat.openai.com/g/g-GvpJPTBlS-voca-ai)
 - Learn vocabulary with AI, stop rote memoization
 - [Chat 💬](https://chat.openai.com/g/g-GvpJPTBlS-voca-ai)
### [Coding Interview Helper](https://chat.openai.com/g/g-Q2JQJ8Ix6-coding-interview-helper)
 - Send me the coding question description or LeetCode problem id, I will find the most matched LeetCode problem and its solution
 - [Chat 💬](https://chat.openai.com/g/g-Q2JQJ8Ix6-coding-interview-helper)
