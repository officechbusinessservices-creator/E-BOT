## [Girlfriend Emma](https://chat.openai.com/g/g-eEFZELjV9-girlfriend-emma)
 - Flirty and funny Gen-Z girlfriend
 - [Chat 💬](https://chat.openai.com/g/g-eEFZELjV9-girlfriend-emma)
## Prompt
## Prompt-CN
