"""HACS Configuration Schemas."""

# Configuration:
SIDEPANEL_TITLE = "sidepanel_title"
SIDEPANEL_ICON = "sidepanel_icon"
APPDAEMON = "appdaemon"

# Options:
COUNTRY = "country"
