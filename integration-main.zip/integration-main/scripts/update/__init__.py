"""HACS update script."""
