"""HACS Script."""
