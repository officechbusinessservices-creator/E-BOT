# TypeScript/JavaScript 测试

> 本文档基于 [common/testing.md](../common/testing.md) 扩展，补充了 TypeScript/JavaScript 特定的内容。

## E2E 测试

使用 **Playwright** 作为关键用户流程的 E2E 测试框架。

## 智能体支持

* **e2e-runner** - Playwright E2E 测试专家
