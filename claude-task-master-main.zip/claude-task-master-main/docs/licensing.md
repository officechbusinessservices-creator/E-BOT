# Licensing

Task Master is licensed under the MIT License with Commons Clause. This means you can:

## ✅ Allowed:

- Use Task Master for any purpose (personal, commercial, academic)
- Modify the code
- Distribute copies
- Create and sell products built using Task Master

## ❌ Not Allowed:

- Sell Task Master itself
- Offer Task Master as a hosted service
- Create competing products based on Task Master

See the [LICENSE](../LICENSE) file for the complete license text.
