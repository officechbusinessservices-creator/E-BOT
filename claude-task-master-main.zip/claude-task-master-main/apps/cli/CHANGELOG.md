# @tm/cli

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- [#1396](https://github.com/eyaltoledano/claude-task-master/pull/1396) [`9883e83`](https://github.com/eyaltoledano/claude-task-master/commit/9883e83b78306e55003e960ea072a11048d89ec9) Thanks [@bjcoombs](https://github.com/bjcoombs)! - Fix box title alignment by adding emoji variant selector to warning sign

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- [#1305](https://github.com/eyaltoledano/claude-task-master/pull/1305) [`a98d96e`](https://github.com/eyaltoledano/claude-task-master/commit/a98d96ef0414833b948672f86da4acc11f700ebb) Thanks [@bjcoombs](https://github.com/bjcoombs)! - Fix warning message box width to match dashboard box width for consistent UI alignment

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## null

### Patch Changes

- Updated dependencies []:
  - @tm/core@null

## 0.27.0

### Patch Changes

- Updated dependencies []:
  - @tm/core@0.26.1

## 0.27.0-rc.0

### Minor Changes

- [#1213](https://github.com/eyaltoledano/claude-task-master/pull/1213) [`137ef36`](https://github.com/eyaltoledano/claude-task-master/commit/137ef362789a9cdfdb1925e35e0438c1fa6c69ee) Thanks [@Crunchyman-ralph](https://github.com/Crunchyman-ralph)! - testing this stuff out to see how the release candidate works with monorepo

## 1.1.0-rc.0

### Minor Changes

- [#1213](https://github.com/eyaltoledano/claude-task-master/pull/1213) [`cd90b4d`](https://github.com/eyaltoledano/claude-task-master/commit/cd90b4d65fc2f04bdad9fb73aba320b58a124240) Thanks [@Crunchyman-ralph](https://github.com/Crunchyman-ralph)! - testing this stuff out to see how the release candidate works with monorepo
